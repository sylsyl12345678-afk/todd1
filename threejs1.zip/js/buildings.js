/*!
 * js/buildings.js — 湖北国土资源职业学院 · 三维校园「建筑生成模块」
 * ==========================================================================
 * 纯经典脚本（非 ES Module），依赖全局 THREE（three.js r159 UMD）。
 * 所有纹理均由 canvas 程序化生成并在模块内缓存，无任何外部图片/模型资源。
 *
 * 引入顺序：
 *   <script src="vendor/three.min.js"></script>
 *   <script src="js/buildings.js"></script>
 *
 * 用法：
 *   const g = window.CampusBuildings.create({
 *     id: 'lib', name: '图文信息中心', style: 'library',
 *     w: 120, d: 90, h: 52, floors: 12, rot: 0, seed: 3,
 *     entrance: 'south', sign: true, accent: '#b6604f',
 *     parts: [ { w: 60, d: 30, h: 14, floors: 3, ox: 0, oz: -46, oy: 0, style: 'teaching' } ]
 *   });
 *   g.position.set(px, 0, pz);      // 世界放置由主场景负责
 *   scene.add(g);
 *   g.userData.setNight(1);         // 0 = 白天, 1 = 夜晚, 支持 0~1 过渡
 *   window.CampusBuildings.dispose(g);  // 从场景移除并释放几何体/材质
 *
 * 坐标约定：
 *   - create() 返回一个以原点为平面中心、底面在 y = 0 的 THREE.Group；
 *   - 长边默认沿局部 X 轴；spec.rot 会写入 group.rotation.y；
 *   - 主入口 south = 局部 +Z 面, north = 局部 -Z 面；
 *   - 所有尺寸单位为米（主场景负责像素→米换算与摆放）。
 *
 * 导出的接口：
 *   window.CampusBuildings = {
 *     create(spec)                     -> THREE.Group,
 *     createBuildingLabelTexture(name) -> THREE.CanvasTexture,  // 建筑名牌
 *     dispose(group)                   -> void,
 *     styles                           -> string[],             // 支持的风格列表
 *     version                          -> '1.0.0'
 *   };
 *   另有附加调试接口：disposeCache()（清理模块级 canvas 纹理缓存）。
 *
 * group.userData：
 *   { poi, footprint:{w,d,h}, setNight(ratio), nightWindows:[mat...],
 *     style, name, id, entrance, triangles, bounds:{min,max}, actualHeight }
 *
 * 支持风格（style）：
 *   library  图文信息中心   —— 12 层地标塔楼 + 弧形玻璃中庭 + 白色竖向遮阳肋 + 顶部构架
 *   teaching 教学大楼       —— 5~6 层长条体量 + 横向窗带 + 砖红基座 + 入口门斗
 *   lab      实验大楼       —— 6 层竖向窗列 + 玻璃楼梯间 + 屋顶排风设备
 *   dorm     学生宿舍       —— 6 层板式 + 阳台/空调机位 + 屋顶水箱/晾衣架
 *   gym      体育馆         —— 大跨度拱形屋面 + 蓝玻璃幕墙 + 拱肋
 *   canteen  食堂           —— 2~3 层大玻璃 + 暖色墙面 + 屋顶烟道/平台
 *   hall     多功能厅       —— 圆形体量 + 金属穹顶 + 环向玻璃
 *   exchange 学术交流中心   —— 退台体量 + 酒店式窗格 + 顶部构架/露台
 *   apartment教师公寓       —— 4~5 层错落阳台 + 坡屋顶
 *   utility  锅炉房/浴室    —— 低层设备感体量 + 烟囱/管线
 *   pavilion 门卫/小亭      —— 小体量坡屋顶
 */
(function (root) {
  'use strict';

  var THREE = root.THREE;

  function ensureLib() {
    if (!THREE) { THREE = root.THREE; }
    if (!THREE) { throw new Error('[CampusBuildings] 未找到全局 THREE，请先加载 vendor/three.min.js'); }
    return THREE;
  }

  /* ======================================================================
   * 0. 基础工具
   * ==================================================================== */
  var PI = Math.PI;
  var DEG = PI / 180;
  var VERSION = '1.0.0';

  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function toNum(v, dft) {
    if (isNum(v)) { return v; }
    if (typeof v === 'string') {
      var f = parseFloat(v);
      if (isFinite(f)) { return f; }
    }
    return dft;
  }
  function round(v) { return Math.round(v); }
  function lerp(a, b, t) { return a + (b - a) * t; }

  /** FNV-1a 32bit 字符串哈希 */
  function hash32(str) {
    str = String(str);
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  /** mulberry32 伪随机数（同一 seed 结果确定，用于同风格内的变化） */
  function makeRng(seed) {
    var a = (seed >>> 0) || 0x9e3779b9;
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function extend(target, src) {
    if (!src) { return target; }
    for (var k in src) {
      if (Object.prototype.hasOwnProperty.call(src, k)) { target[k] = src[k]; }
    }
    return target;
  }

  /** 十六进制/颜色值 → THREE.Color（可乘亮度系数） */
  function colorOf(hex, mul) {
    var c = new THREE.Color(hex);
    if (mul !== undefined && mul !== 1) { c.multiplyScalar(mul); }
    return c;
  }

  /* ======================================================================
   * 1. canvas 程序化纹理
   * ==================================================================== */
  var TEX_CACHE = {};
  var LABEL_CACHE = {};

  function newCanvas(w, h) {
    var doc = root.document;
    if (!doc || typeof doc.createElement !== 'function') {
      throw new Error('[CampusBuildings] 需要浏览器 document 环境来生成 canvas 纹理');
    }
    var c = doc.createElement('canvas');
    c.width = w; c.height = h;
    return c;
  }

  function canvasTexture(canvas) {
    ensureLib();
    var tex = new THREE.CanvasTexture(canvas);
    if ('colorSpace' in tex) { tex.colorSpace = THREE.SRGBColorSpace; }
    else if ('encoding' in tex) { tex.encoding = 3001; /* sRGBEncoding */ }
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.needsUpdate = true;
    return tex;
  }

  /* ---------- 1.1 通用绘制小工具 ---------- */
  function fillWall(ctx, W, H, base, rng, n) {
    ctx.fillStyle = base;
    ctx.fillRect(0, 0, W, H);
    n = n || 22;
    for (var i = 0; i < n; i++) {
      var light = rng() > 0.5;
      ctx.fillStyle = light ? 'rgba(255,255,255,0.055)' : 'rgba(62,58,52,0.045)';
      var w = 8 + rng() * 46, h = 4 + rng() * 15;
      ctx.fillRect(rng() * W * 0.94, rng() * H * 0.94, w, h);
    }
  }

  function glassGrad(ctx, x, y, w, h, top, bottom) {
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    g.addColorStop(0, top);
    g.addColorStop(1, bottom);
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
  }

  function nightBg(ctx, W, H) {
    ctx.fillStyle = '#04060a';
    ctx.fillRect(0, 0, W, H);
  }

  /** 夜景发光窗格（画在 emissiveMap 上：黑底 + 暖/冷色亮窗） */
  function litPane(ctx, x, y, w, h, rng, prob, cool) {
    if (rng() > prob) {
      ctx.fillStyle = 'rgba(7,10,15,1)';
      ctx.fillRect(x, y, w, h);
      return;
    }
    var g = ctx.createLinearGradient(0, y, 0, y + h);
    if (cool) {
      g.addColorStop(0, '#eef6ff');
      g.addColorStop(1, '#a6c7ee');
    } else {
      g.addColorStop(0, '#ffedc8');
      g.addColorStop(1, '#cf9a58');
    }
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    ctx.fillStyle = cool ? 'rgba(150,190,255,0.10)' : 'rgba(255,204,140,0.12)';
    ctx.fillRect(x - 2, y - 2, w + 4, h + 4);
  }

  /* ---------- 1.2 立面贴图（1 个 tile = 4 开间 × 1 层） ---------- */
  var FACADES = {};

  /** 教学大楼：横向连续窗带 + 窗下墙 + 楼层线 */
  FACADES.teachBand = function (ctx, W, H, v, night, rng) {
    var bay = W / 4;
    var y0 = H * (0.18 + v * 0.015);
    var y1 = H * (0.64 + v * 0.02);
    var mull = v === 2 ? 8 : 4;
    var i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < mull; i++) {
        litPane(ctx, i * W / mull + 2, y0 + 2, W / mull - 4, y1 - y0 - 4, rng, 0.55, rng() > 0.88);
      }
      return;
    }
    fillWall(ctx, W, H, '#f8f5ef', rng, 16);
    glassGrad(ctx, 0, y0, W, y1 - y0, '#7e9db3', '#2e4659');
    for (i = 0; i < 4; i++) {
      ctx.fillStyle = 'rgba(255,255,255,0.09)';
      ctx.fillRect(i * bay + bay * 0.1, y0 + 2, bay * 0.14, y1 - y0 - 4);
    }
    ctx.fillStyle = '#4a5057';
    for (i = 0; i <= mull; i++) { ctx.fillRect(i * W / mull - 1, y0 - 1, 2, y1 - y0 + 2); }
    ctx.fillRect(0, y0 - 3, W, 3);
    ctx.fillRect(0, y1, W, 3);
    ctx.fillStyle = '#d2cdc3';
    ctx.fillRect(0, y1 + 3, W, H * 0.085);
    ctx.fillStyle = 'rgba(70,66,60,0.20)';
    ctx.fillRect(0, H - 2, W, 2);
  };

  /** 实验大楼：竖向窗列 + 楼层梁带 */
  FACADES.labSlit = function (ctx, W, H, v, night, rng) {
    var bay = W / 4;
    var y0 = H * 0.13, y1 = H * 0.74;
    var off = bay * (0.16 + v * 0.02);
    var ww = bay * (0.19 + v * 0.015);
    var i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        litPane(ctx, i * bay + off, y0 + 2, ww, y1 - y0 - 4, rng, 0.62, false);
        litPane(ctx, i * bay + off + bay * 0.33, y0 + 2, ww, y1 - y0 - 4, rng, 0.62, false);
      }
      return;
    }
    fillWall(ctx, W, H, '#f3f4f1', rng, 14);
    ctx.fillStyle = '#c2c6c5';
    ctx.fillRect(0, H * 0.78, W, H * 0.1);
    ctx.fillStyle = 'rgba(58,62,64,0.24)';
    ctx.fillRect(0, H * 0.775, W, 2);
    for (i = 0; i < 4; i++) {
      var x = i * bay + off;
      var k;
      for (k = 0; k < 2; k++) {
        var xx = x + k * bay * 0.33;
        glassGrad(ctx, xx, y0, ww, y1 - y0, '#93aeba', '#2b4050');
        ctx.fillStyle = '#3b4147';
        ctx.fillRect(xx - 1, y0, 2, y1 - y0);
        ctx.fillRect(xx + ww - 1, y0, 2, y1 - y0);
        ctx.fillRect(xx, y0 + (y1 - y0) * 0.47, ww, 2);
      }
      ctx.fillStyle = '#dcdedb';
      ctx.fillRect(i * bay + bay * 0.58, H * 0.1, bay * 0.05, H * 0.62);
    }
  };

  /** 学生宿舍：规则小窗 + 窗楣/窗台 */
  FACADES.dormPunch = function (ctx, W, H, v, night, rng) {
    var bay = W / 4;
    var y0 = H * (0.2 + v * 0.015);
    var y1 = H * (0.66 + v * 0.02);
    var i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        litPane(ctx, i * bay + bay * 0.22, y0, bay * 0.56, y1 - y0, rng, 0.62, rng() > 0.82);
      }
      return;
    }
    fillWall(ctx, W, H, '#f7f3eb', rng, 14);
    for (i = 0; i < 4; i++) {
      var x = i * bay + bay * 0.22, ww = bay * 0.56;
      glassGrad(ctx, x, y0, ww, y1 - y0, '#7796a8', '#31485a');
      ctx.fillStyle = '#fbfbf7';
      ctx.fillRect(x - 3, y0 - 3, ww + 6, 3);
      ctx.fillRect(x - 3, y1, ww + 6, 4);
      ctx.fillRect(x + ww * 0.5 - 1, y0, 2, y1 - y0);
      ctx.fillStyle = 'rgba(255,255,255,0.10)';
      ctx.fillRect(x + 3, y0 + 3, ww * 0.16, y1 - y0 - 6);
    }
    ctx.fillStyle = '#cdc6ba';
    ctx.fillRect(0, H * 0.7, W, H * 0.045);
    ctx.fillStyle = 'rgba(90,84,76,0.16)';
    ctx.fillRect(0, H - 3, W, 3);
  };

  /** 蓝玻璃幕墙：整片幕墙 + 竖梃/横梃 + 层间铝板 */
  FACADES.curtain = function (ctx, W, H, v, night, rng) {
    var bay = W / 4, half = H / 2, i, j;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        for (j = 0; j < 2; j++) {
          litPane(ctx, i * bay + 3, j * half + 3, bay - 6, half - 6, rng, 0.46, rng() > 0.75);
        }
      }
      return;
    }
    glassGrad(ctx, 0, 0, W, H, '#8fb2ca', '#2b4257');
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 2; j++) {
        ctx.fillStyle = rng() > 0.5 ? 'rgba(255,255,255,0.075)' : 'rgba(10,20,32,0.10)';
        ctx.fillRect(i * bay, j * half, bay, half);
      }
    }
    ctx.fillStyle = '#5c6873';
    for (i = 0; i <= 4; i++) { ctx.fillRect(i * bay - 1, 0, 2, H); }
    ctx.fillRect(0, half - 1, W, 3);
    ctx.fillStyle = '#c7ccd0';
    ctx.fillRect(0, H * 0.93, W, H * 0.07);
    if (v === 1) {
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.fillRect(0, 0, W, H * 0.12);
    }
  };

  /** 学术交流中心：酒店式方窗 + 白色窗框 */
  FACADES.hotelPunch = function (ctx, W, H, v, night, rng) {
    var bay = W / 4;
    var y0 = H * (0.22 + v * 0.01), y1 = H * (0.68 + v * 0.01);
    var wRatio = v === 2 ? 0.4 : 0.47;
    var i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        litPane(ctx, i * bay + bay * 0.26, y0, bay * wRatio, y1 - y0, rng, 0.5, rng() > 0.86);
      }
      return;
    }
    fillWall(ctx, W, H, '#f6f2ea', rng, 12);
    ctx.fillStyle = '#d7d1c5';
    ctx.fillRect(0, H * 0.78, W, 3);
    for (i = 0; i < 4; i++) {
      var x = i * bay + bay * 0.26, ww = bay * wRatio;
      glassGrad(ctx, x, y0, ww, y1 - y0, '#7f9aa9', '#354c5c');
      ctx.strokeStyle = '#faf8f2';
      ctx.lineWidth = 3;
      ctx.strokeRect(x - 2, y0 - 2, ww + 4, y1 - y0 + 4);
      ctx.strokeStyle = 'rgba(250,250,246,0.85)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x + ww * 0.5, y0);
      ctx.lineTo(x + ww * 0.5, y1);
      ctx.stroke();
      ctx.fillStyle = '#9aa3a6';
      ctx.fillRect(x + ww + 5, y1 + 7, bay * 0.13, H * 0.09);
    }
  };

  /** 体育馆：深蓝玻璃幕墙 + 粗竖梃 */
  FACADES.gymGlass = function (ctx, W, H, v, night, rng) {
    var bay = W / 4, half = H / 2, i, j;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        for (j = 0; j < 2; j++) {
          litPane(ctx, i * bay + 4, j * half + 4, bay - 8, half - 8, rng, 0.4, rng() > 0.66);
        }
      }
      return;
    }
    glassGrad(ctx, 0, 0, W, H, '#7fa6bf', '#263f51');
    for (i = 0; i < 4; i++) {
      ctx.fillStyle = 'rgba(255,255,255,0.075)';
      ctx.fillRect(i * bay + 8, 8, bay * 0.2, H * 0.42);
    }
    ctx.fillStyle = '#33424c';
    for (i = 0; i <= 4; i++) { ctx.fillRect(i * bay - 2, 0, 4, H); }
    ctx.fillRect(0, half - 2, W, 4);
    ctx.fillStyle = '#dfe2e0';
    ctx.fillRect(0, 0, W, H * 0.07);
    ctx.fillStyle = '#c3c8c8';
    ctx.fillRect(0, H * 0.94, W, H * 0.06);
  };

  /** 食堂：大玻璃 + 暖色装饰带 */
  FACADES.canteenGl = function (ctx, W, H, v, night, rng) {
    var y0 = H * 0.11, y1 = H * 0.86, i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        litPane(ctx, i * W / 4 + 3, y0 + 3, W / 4 - 6, (y1 - y0) * 0.48, rng, 0.66, false);
        litPane(ctx, i * W / 4 + 3, y0 + (y1 - y0) * 0.52, W / 4 - 6, (y1 - y0) * 0.45 - 3, rng, 0.6, false);
      }
      return;
    }
    fillWall(ctx, W, H, '#f8f1e4', rng, 12);
    glassGrad(ctx, 0, y0, W, y1 - y0, '#8cabbe', '#314c5d');
    ctx.fillStyle = '#636b71';
    for (i = 0; i <= 4; i++) { ctx.fillRect(i * W / 4 - 2, y0, 4, y1 - y0); }
    ctx.fillRect(0, H * 0.47, W, 3);
    ctx.fillRect(0, y0 - 3, W, 3);
    ctx.fillRect(0, y1, W, 3);
    ctx.fillStyle = '#c88f5a';
    ctx.fillRect(0, H * 0.9, W, 5);
  };

  /** 多功能厅：环向玻璃 */
  FACADES.hallRing = function (ctx, W, H, v, night, rng) {
    var y0 = H * 0.1, y1 = H * 0.82, i;
    var mull = 8;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < mull; i++) {
        litPane(ctx, i * W / mull + 2, y0 + 2, W / mull - 4, y1 - y0 - 4, rng, 0.5, rng() > 0.86);
      }
      return;
    }
    glassGrad(ctx, 0, y0, W, y1 - y0, '#86a5b7', '#2f4758');
    for (i = 0; i < 4; i++) {
      ctx.fillStyle = 'rgba(255,255,255,0.07)';
      ctx.fillRect(i * W / 4 + 6, y0 + 2, 14, y1 - y0 - 4);
    }
    ctx.fillStyle = '#4d565c';
    for (i = 0; i <= mull; i++) { ctx.fillRect(i * W / mull - 1, y0, 2, y1 - y0); }
    ctx.fillRect(0, y0 - 3, W, 3);
    ctx.fillRect(0, y1, W, 3);
    ctx.fillStyle = '#d9d5cb';
    ctx.fillRect(0, H * 0.9, W, H * 0.06);
  };

  /** 锅炉房/浴室：波纹金属板 + 高窗 */
  FACADES.utilMetal = function (ctx, W, H, v, night, rng) {
    var bay = W / 4, i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 4; i++) {
        litPane(ctx, i * bay + 10, H * 0.16, bay - 20, H * 0.18, rng, 0.3, true);
      }
      return;
    }
    for (var y = 0; y < H; y += 8) {
      ctx.fillStyle = ((y / 8) | 0) % 2 ? '#eef0ee' : '#dbdedc';
      ctx.fillRect(0, y, W, 4);
      ctx.fillStyle = 'rgba(80,86,86,0.16)';
      ctx.fillRect(0, y + 3, W, 1);
    }
    ctx.fillStyle = '#8e9291';
    ctx.fillRect(0, H * 0.84, W, H * 0.16);
    for (i = 0; i < 4; i++) {
      glassGrad(ctx, i * bay + 10, H * 0.16, bay - 20, H * 0.18, '#5a7280', '#26363f');
      ctx.strokeStyle = '#6e7473';
      ctx.lineWidth = 3;
      ctx.strokeRect(i * bay + 10, H * 0.16, bay - 20, H * 0.18);
    }
    if (v === 1) {
      ctx.fillStyle = 'rgba(70,74,74,0.25)';
      ctx.fillRect(0, H * 0.5, W, 2);
    }
  };

  /** 小体量门卫/亭：抹灰墙 + 小窗 */
  FACADES.plainWin = function (ctx, W, H, v, night, rng) {
    var bay = W / 2, y0 = H * 0.28, y1 = H * 0.66, i;
    if (night) {
      nightBg(ctx, W, H);
      for (i = 0; i < 2; i++) {
        litPane(ctx, i * bay + bay * 0.24, y0, bay * 0.42, y1 - y0, rng, 0.55, false);
      }
      return;
    }
    fillWall(ctx, W, H, '#f8f4ea', rng, 18);
    ctx.fillStyle = '#d8d1c2';
    ctx.fillRect(0, H * 0.84, W, H * 0.16);
    for (i = 0; i < 2; i++) {
      var x = i * bay + bay * 0.24, ww = bay * 0.42;
      glassGrad(ctx, x, y0, ww, y1 - y0, '#7d99a8', '#31485a');
      ctx.strokeStyle = '#f7f4ec';
      ctx.lineWidth = 4;
      ctx.strokeRect(x - 2, y0 - 2, ww + 4, y1 - y0 + 4);
    }
  };

  var FACADE_DEFS = {
    teachBand: { tw: 14.4, th: 3.9, draw: FACADES.teachBand },
    labSlit: { tw: 14.4, th: 3.9, draw: FACADES.labSlit },
    dormPunch: { tw: 13.6, th: 3.3, draw: FACADES.dormPunch },
    curtain: { tw: 12.0, th: 3.9, draw: FACADES.curtain },
    hotelPunch: { tw: 13.6, th: 3.6, draw: FACADES.hotelPunch },
    gymGlass: { tw: 12.0, th: 5.0, draw: FACADES.gymGlass },
    canteenGl: { tw: 12.0, th: 4.6, draw: FACADES.canteenGl },
    hallRing: { tw: 10.0, th: 4.2, draw: FACADES.hallRing },
    utilMetal: { tw: 8.0, th: 5.0, draw: FACADES.utilMetal },
    plainWin: { tw: 6.0, th: 3.6, draw: FACADES.plainWin }
  };

  /**
   * 取立面纹理（day 色图 + night 自发光遮罩），按 kind+variant 缓存。
   * @returns {{day: THREE.Texture, night: THREE.Texture, tw: number, th: number}}
   */
  function getFacade(kind, variant) {
    var def = FACADE_DEFS[kind] || FACADE_DEFS.teachBand;
    variant = (variant | 0) % 3;
    var key = 'facade|' + kind + '|' + variant;
    if (TEX_CACHE[key]) { return TEX_CACHE[key]; }
    var W = 256, H = 128;
    var c1 = newCanvas(W, H);
    var c2 = newCanvas(W, H);
    var seed = hash32(kind) + variant * 1013;
    def.draw(c1.getContext('2d'), W, H, variant, false, makeRng(seed));
    def.draw(c2.getContext('2d'), W, H, variant, true, makeRng(seed + 7777));
    var out = { day: canvasTexture(c1), night: canvasTexture(c2), tw: def.tw, th: def.th };
    TEX_CACHE[key] = out;
    return out;
  }

  /* ---------- 1.3 其他材质纹理 ---------- */
  function drawBrick(ctx, W, H, rng) {
    ctx.fillStyle = '#d9d2c6';
    ctx.fillRect(0, 0, W, H);
    var bh = 16, bw = 32, row, col;
    for (row = 0; row < H / bh; row++) {
      for (col = -1; col < W / bw + 1; col++) {
        var x = col * bw + (row % 2 ? bw / 2 : 0);
        var y = row * bh;
        var r = 168 + rng() * 28, g = 96 + rng() * 22, b = 78 + rng() * 18;
        ctx.fillStyle = 'rgb(' + ((r) | 0) + ',' + ((g) | 0) + ',' + ((b) | 0) + ')';
        ctx.fillRect(x + 1.5, y + 1.5, bw - 3, bh - 3);
        ctx.fillStyle = 'rgba(255,255,255,0.07)';
        ctx.fillRect(x + 1.5, y + 1.5, bw - 3, 2);
      }
    }
  }

  function drawGranite(ctx, W, H, rng) {
    ctx.fillStyle = '#8f8c85';
    ctx.fillRect(0, 0, W, H);
    for (var i = 0; i < 900; i++) {
      var v = 100 + rng() * 90;
      ctx.fillStyle = 'rgba(' + (v | 0) + ',' + ((v * 0.98) | 0) + ',' + ((v * 0.94) | 0) + ',' + (0.15 + rng() * 0.35) + ')';
      ctx.fillRect(rng() * W, rng() * H, 1 + rng() * 2.5, 1 + rng() * 2.5);
    }
  }

  function drawRoofGravel(ctx, W, H, rng) {
    ctx.fillStyle = '#a9a9a4';
    ctx.fillRect(0, 0, W, H);
    for (var i = 0; i < 700; i++) {
      var v = 120 + rng() * 100;
      ctx.fillStyle = 'rgba(' + (v | 0) + ',' + (v | 0) + ',' + ((v * 0.97) | 0) + ',' + (0.25 + rng() * 0.4) + ')';
      ctx.fillRect(rng() * W, rng() * H, 1 + rng() * 2, 1 + rng() * 2);
    }
    ctx.strokeStyle = 'rgba(70,70,68,0.22)';
    ctx.lineWidth = 1;
    for (var x = 0; x < W; x += 32) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    }
  }

  function drawRoofMetal(ctx, W, H, rng) {
    var g = ctx.createLinearGradient(0, 0, W, 0);
    g.addColorStop(0, '#c3cad0');
    g.addColorStop(0.5, '#b3bcc3');
    g.addColorStop(1, '#c8cfd4');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    for (var x = 0; x < W; x += 16) {
      ctx.fillStyle = 'rgba(70,80,88,0.28)';
      ctx.fillRect(x, 0, 1.5, H);
      ctx.fillStyle = 'rgba(255,255,255,0.20)';
      ctx.fillRect(x + 2, 0, 1, H);
    }
    for (var i = 0; i < 120; i++) {
      ctx.fillStyle = 'rgba(90,95,100,' + (0.03 + rng() * 0.05) + ')';
      ctx.fillRect(rng() * W, rng() * H, 4 + rng() * 18, 1 + rng() * 3);
    }
  }

  function drawRoofTile(ctx, W, H, rng) {
    ctx.fillStyle = '#8f5343';
    ctx.fillRect(0, 0, W, H);
    var rh = 14, cw = 18, row, col;
    for (row = 0; row < H / rh; row++) {
      for (col = 0; col < W / cw; col++) {
        var x = col * cw + (row % 2 ? cw / 2 : 0);
        var y = row * rh;
        var v = 0.85 + rng() * 0.3;
        ctx.fillStyle = 'rgb(' + ((150 * v) | 0) + ',' + ((78 * v) | 0) + ',' + ((64 * v) | 0) + ')';
        ctx.fillRect(x + 0.5, y, cw - 1, rh - 2);
        ctx.fillStyle = 'rgba(255,255,255,0.10)';
        ctx.fillRect(x + 0.5, y, cw - 1, 2);
        ctx.fillStyle = 'rgba(30,18,14,0.22)';
        ctx.fillRect(x + 0.5, y + rh - 3, cw - 1, 2);
      }
    }
  }

  function getSimpleTexture(kind) {
    var key = 'simple|' + kind;
    if (TEX_CACHE[key]) { return TEX_CACHE[key]; }
    var W = 128, H = 128;
    var c = newCanvas(W, H);
    var ctx = c.getContext('2d');
    var rng = makeRng(hash32(kind) + 99);
    if (kind === 'brick') { drawBrick(ctx, W, H, rng); }
    else if (kind === 'granite') { drawGranite(ctx, W, H, rng); }
    else if (kind === 'roofGravel') { drawRoofGravel(ctx, W, H, rng); }
    else if (kind === 'roofMetal') { drawRoofMetal(ctx, W, H, rng); }
    else if (kind === 'roofTile') { drawRoofTile(ctx, W, H, rng); }
    else { ctx.fillStyle = '#c8c8c4'; ctx.fillRect(0, 0, W, H); }
    var tex = canvasTexture(c);
    TEX_CACHE[key] = tex;
    return tex;
  }

  /* ---------- 1.4 建筑名牌贴图 ---------- */
  /**
   * 生成建筑名牌（透明底 + 深色牌面 + 金色描边 + 中文名）。
   * @param {string} name 建筑名
   * @param {object} [opts] {sub:副标题, w:画布宽, h:画布高, bg, fg, border}
   * @returns {THREE.CanvasTexture}
   */
  function createBuildingLabelTexture(name, opts) {
    ensureLib();
    opts = opts || {};
    name = String(name === undefined || name === null ? '' : name);
    var W = opts.w || 512;
    var H = opts.h || 128;
    var key = 'label|' + name + '|' + W + 'x' + H + '|' + (opts.bg || '') + (opts.fg || '') + (opts.sub || '');
    if (LABEL_CACHE[key]) { return LABEL_CACHE[key]; }

    var c = newCanvas(W, H);
    var ctx = c.getContext('2d');
    ctx.clearRect(0, 0, W, H);

    var r = Math.min(H * 0.16, 18);
    var pad = Math.max(4, H * 0.06);
    var x0 = pad, y0 = pad, w0 = W - pad * 2, h0 = H - pad * 2;
    // 牌面
    ctx.beginPath();
    ctx.moveTo(x0 + r, y0);
    ctx.lineTo(x0 + w0 - r, y0);
    ctx.quadraticCurveTo(x0 + w0, y0, x0 + w0, y0 + r);
    ctx.lineTo(x0 + w0, y0 + h0 - r);
    ctx.quadraticCurveTo(x0 + w0, y0 + h0, x0 + w0 - r, y0 + h0);
    ctx.lineTo(x0 + r, y0 + h0);
    ctx.quadraticCurveTo(x0, y0 + h0, x0, y0 + h0 - r);
    ctx.lineTo(x0, y0 + r);
    ctx.quadraticCurveTo(x0, y0, x0 + r, y0);
    ctx.closePath();
    var bg = ctx.createLinearGradient(0, y0, 0, y0 + h0);
    bg.addColorStop(0, opts.bg || 'rgba(22,36,50,0.94)');
    bg.addColorStop(1, opts.bg2 || 'rgba(12,22,34,0.94)');
    ctx.fillStyle = bg;
    ctx.fill();
    ctx.lineWidth = Math.max(2, H * 0.022);
    ctx.strokeStyle = opts.border || 'rgba(226,190,120,0.95)';
    ctx.stroke();
    // 细内线
    ctx.beginPath();
    ctx.moveTo(x0 + 10, y0 + 8);
    ctx.lineTo(x0 + 10, y0 + h0 - 8);
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(226,190,120,0.28)';
    ctx.stroke();

    // 文字（自动缩放以适配牌面宽度）
    var fg = opts.fg || '#f6e7c6';
    var maxW = w0 - H * 0.42;
    var fs = Math.floor(H * 0.52);
    var font = '700 ' + fs + 'px "Microsoft YaHei","PingFang SC","Hiragino Sans GB","Noto Sans CJK SC","SimHei",sans-serif';
    ctx.font = font;
    var m = ctx.measureText(name);
    var tw = (m && m.width) || (name.length * fs);
    if (tw > maxW && tw > 0) {
      fs = Math.max(12, Math.floor(fs * maxW / tw));
      font = '700 ' + fs + 'px "Microsoft YaHei","PingFang SC","Hiragino Sans GB","Noto Sans CJK SC","SimHei",sans-serif';
      ctx.font = font;
    }
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.fillText(name, W / 2 + 1.5, H / 2 + 1.5);
    ctx.fillStyle = fg;
    ctx.fillText(name, W / 2, H / 2);
    // 小装饰点
    ctx.fillStyle = 'rgba(226,190,120,0.9)';
    ctx.beginPath();
    ctx.arc(x0 + 16, H / 2, Math.max(2, H * 0.024), 0, PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.arc(x0 + w0 - 16, H / 2, Math.max(2, H * 0.024), 0, PI * 2);
    ctx.fill();

    var tex = canvasTexture(c);
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    LABEL_CACHE[key] = tex;
    return tex;
  }

  /* ======================================================================
   * 2. 风格默认参数 / 材质系统
   * ==================================================================== */
  var STYLE_DEFS = {
    library: {
      floors: 12, floorH: 4.35, w: 110, d: 82,
      facade: 'curtain', glassFacade: 'curtain', roofKind: 'metal',
      walls: ['#ecebe6', '#e4e2da', '#f0efea'],
      accents: ['#b6604f', '#9c5a4b', '#c0765f'],
      roofs: ['#c7ccd0', '#bfc4c8', '#d0d4d6']
    },
    teaching: {
      floors: 5, floorH: 3.9, w: 70, d: 22,
      facade: 'teachBand', glassFacade: 'curtain', roofKind: 'gravel',
      walls: ['#efe7d6', '#e9e4da', '#f2e9dc'],
      accents: ['#b6604f', '#b97a5a', '#a9584a'],
      roofs: ['#b6b0a4', '#c2b6a6', '#b0a89c']
    },
    lab: {
      floors: 6, floorH: 3.9, w: 60, d: 24,
      facade: 'labSlit', glassFacade: 'curtain', roofKind: 'gravel',
      walls: ['#e7e8e5', '#dfe3e1', '#ecedea'],
      accents: ['#5b7d97', '#6c8ca4', '#51718a'],
      roofs: ['#b4b8ba', '#c0c4c6', '#aeb2b4']
    },
    dorm: {
      floors: 6, floorH: 3.3, w: 66, d: 16,
      facade: 'dormPunch', glassFacade: 'curtain', roofKind: 'gravel',
      walls: ['#e8dcc7', '#eddcd2', '#e2e7e3'],
      accents: ['#7f95a8', '#8fa3b3', '#6f889c'],
      roofs: ['#b0aca2', '#bdb6a8', '#c6c2b8']
    },
    gym: {
      floors: 2, floorH: 8.0, w: 62, d: 40,
      facade: 'gymGlass', glassFacade: 'gymGlass', roofKind: 'metal',
      walls: ['#e9ecec', '#e2e6e6', '#eef0ef'],
      accents: ['#3f6d8c', '#4b7a99', '#35607d'],
      roofs: ['#aeb6bb', '#b8c0c4', '#a6aeb3']
    },
    canteen: {
      floors: 3, floorH: 4.4, w: 44, d: 30,
      facade: 'canteenGl', glassFacade: 'canteenGl', roofKind: 'gravel',
      walls: ['#eddfc4', '#e7d9c6', '#f1e4c8'],
      accents: ['#b07a4c', '#c08a58', '#a06c40'],
      roofs: ['#bdb4a6', '#c7beb0', '#b3aa9c']
    },
    hall: {
      floors: 2, floorH: 6.0, w: 40, d: 36,
      facade: 'hallRing', glassFacade: 'hallRing', roofKind: 'metal',
      walls: ['#e7e3d9', '#dfdbd1', '#ece8dc'],
      accents: ['#8a6d4d', '#9a7d5b', '#7a5f42'],
      roofs: ['#a9b0b4', '#b6bcbe', '#9ea5a9']
    },
    exchange: {
      floors: 8, floorH: 3.6, w: 58, d: 30,
      facade: 'hotelPunch', glassFacade: 'curtain', roofKind: 'gravel',
      walls: ['#ece6da', '#e0e6e8', '#f2e9dc'],
      accents: ['#8f7357', '#a3855f', '#7d6449'],
      roofs: ['#b8b8b2', '#c2c2bc', '#aeaea8']
    },
    apartment: {
      floors: 4, floorH: 3.1, w: 36, d: 15,
      facade: 'dormPunch', glassFacade: 'curtain', roofKind: 'tile',
      walls: ['#ecdfc9', '#e5d8c6', '#efdfd6'],
      accents: ['#8d7660', '#9a8268', '#7e6a55'],
      roofs: ['#8e5a4a', '#7d5347', '#96604c']
    },
    utility: {
      floors: 2, floorH: 4.5, w: 24, d: 16,
      facade: 'utilMetal', glassFacade: 'utilMetal', roofKind: 'metal',
      walls: ['#c3c7c5', '#b7bcba', '#cdd1cf'],
      accents: ['#6f7473', '#7d8280', '#646968'],
      roofs: ['#9aa0a0', '#a7adad', '#8f9595']
    },
    pavilion: {
      floors: 1, floorH: 3.8, w: 9, d: 7,
      facade: 'plainWin', glassFacade: 'plainWin', roofKind: 'tile',
      walls: ['#f1ead9', '#e9e1cf', '#f5efe1'],
      accents: ['#9a5a44', '#8a6a4a', '#a4684e'],
      roofs: ['#7f5648', '#8d5f4c', '#714c40']
    }
  };

  var STYLE_LIST = ['library', 'teaching', 'lab', 'dorm', 'gym', 'canteen',
    'hall', 'exchange', 'apartment', 'utility', 'pavilion'];

  var STYLE_ALIAS = {
    library: 'library', lib: 'library', book: 'library', libraryhall: 'library',
    teach: 'teaching', teaching: 'teaching', education: 'teaching', classroom: 'teaching',
    lab: 'lab', laboratory: 'lab', experiment: 'lab', '实验楼': 'lab',
    dorm: 'dorm', dormitory: 'dorm', hostel: 'dorm', student: 'dorm',
    gym: 'gym', gymnasium: 'gym', sports: 'gym', stadium: 'gym', '体育馆': 'gym',
    canteen: 'canteen', dining: 'canteen', restaurant: 'canteen', cafeteria: 'canteen',
    hall: 'hall', auditorium: 'hall', theater: 'hall', theatre: 'hall',
    exchange: 'exchange', hotel: 'exchange', academic: 'exchange', guesthouse: 'exchange',
    apartment: 'apartment', residence: 'apartment', house: 'apartment', staff: 'apartment',
    utility: 'utility', boiler: 'utility', bath: 'utility', plant: 'utility',
    pavilion: 'pavilion', gate: 'pavilion', guard: 'pavilion', kiosk: 'pavilion'
  };
  var STYLE_ZH = {
    '图文信息中心': 'library', '图书馆': 'library', '图文中心': 'library',
    '教学大楼': 'teaching', '教学楼': 'teaching', '综合楼': 'teaching',
    '实验大楼': 'lab', '实验楼': 'lab', '实训楼': 'lab',
    '学生宿舍': 'dorm', '宿舍': 'dorm', '宿舍楼': 'dorm',
    '体育馆': 'gym', '风雨操场': 'gym',
    '食堂': 'canteen', '餐厅': 'canteen', '学生食堂': 'canteen',
    '多功能厅': 'hall', '报告厅': 'hall', '大礼堂': 'hall',
    '学术交流中心': 'exchange', '交流中心': 'exchange', '招待所': 'exchange',
    '教师公寓': 'apartment', '公寓': 'apartment', '外教公寓': 'apartment',
    '锅炉房': 'utility', '浴室': 'utility', '设备房': 'utility', '水泵房': 'utility',
    '门卫': 'pavilion', '门房': 'pavilion', '亭': 'pavilion', '小亭': 'pavilion'
  };

  function normalizeStyle(style) {
    var s = (style === undefined || style === null) ? '' : String(style).trim();
    var low = s.toLowerCase();
    if (STYLE_DEFS[low]) { return low; }
    if (STYLE_ALIAS[low]) { return STYLE_ALIAS[low]; }
    if (STYLE_ZH[s]) { return STYLE_ZH[s]; }
    // 模糊匹配：包含关键字（如 "学生宿舍A栋"）
    for (var zh in STYLE_ZH) {
      if (Object.prototype.hasOwnProperty.call(STYLE_ZH, zh) && s.indexOf(zh) >= 0) { return STYLE_ZH[zh]; }
    }
    return 'teaching';
  }

  /**
   * 一栋（或一个体量）的材质集合：按 key 惰性创建，同 key 复用。
   * 每栋建筑独立一套材质 -> 支持每栋单独的夜间状态与释放。
   */
  function MaterialKit(styleKey, volMeta) {
    ensureLib();
    var def = STYLE_DEFS[styleKey] || STYLE_DEFS.teaching;
    var variant = (((volMeta && volMeta.themeVariant) | 0) % 3 + 3) % 3;
    this.styleKey = styleKey;
    this.def = def;
    this.variant = variant;
    this.mats = {};
    this.list = [];
    this.night = [];
    this.p = {
      wall: def.walls[variant % def.walls.length],
      wall2: def.walls[(variant + 1) % def.walls.length],
      accent: (volMeta && volMeta.accent) || def.accents[variant % def.accents.length],
      roof: def.roofs[variant % def.roofs.length],
      floorH: def.floorH
    };
    this.facadeWall = getFacade(def.facade, variant);
    this.facadeGlass = getFacade(def.glassFacade || def.facade, variant);
  }
  MaterialKit.prototype.pal = function () { return this.p; };
  MaterialKit.prototype.std = function (o) {
    ensureLib();
    var params = {
      color: (o.color !== undefined ? o.color : 0xffffff),
      roughness: (o.roughness !== undefined ? o.roughness : 0.82),
      metalness: (o.metalness !== undefined ? o.metalness : 0.0)
    };
    if (o.map) { params.map = o.map; }
    if (o.emissiveMap) { params.emissiveMap = o.emissiveMap; }
    if (o.emissive) { params.emissive = new THREE.Color(o.emissive); }
    var mat = new THREE.MeshStandardMaterial(params);
    if (o.emissiveMap) {
      mat.emissive = new THREE.Color(o.emissive || 0xffcf9c);
      mat.emissiveIntensity = 0;
      this.night.push({ mat: mat, k: (o.nightK !== undefined ? o.nightK : 1.0) });
    } else if (o.emissive) {
      mat.emissiveIntensity = (o.emissiveIntensity !== undefined ? o.emissiveIntensity : 0);
      if (o.nightK) { this.night.push({ mat: mat, k: o.nightK }); }
    }
    if (o.transparent) {
      mat.transparent = true;
      mat.opacity = (o.opacity !== undefined ? o.opacity : 1);
      mat.depthWrite = (o.depthWrite !== undefined ? o.depthWrite : false);
    }
    if (o.side) { mat.side = o.side; }
    if (o.flatShading) { mat.flatShading = true; }
    mat.name = this.styleKey + '_' + this.list.length;
    this.list.push(mat);
    return mat;
  };
  MaterialKit.prototype.get = function (key) {
    if (this.mats[key]) { return this.mats[key]; }
    var f = MAT_FACTORIES[key];
    if (!f) { throw new Error('[CampusBuildings] 未知材质 key: ' + key); }
    var m = f(this);
    if (m.userData) {
      m.userData.kind = key;
      m.userData.style = this.styleKey;
      m.userData.variant = this.variant;
    }
    this.mats[key] = m;
    return m;
  };

  var MAT_FACTORIES = {
    wall: function (kit) {
      var p = kit.pal(), f = kit.facadeWall;
      return kit.std({ map: f.day, color: p.wall, roughness: 0.87, metalness: 0.02, emissiveMap: f.night, emissive: 0xffcf9c, nightK: 0.9 });
    },
    wall2: function (kit) {
      var p = kit.pal(), f = kit.facadeWall;
      return kit.std({ map: f.day, color: p.wall2, roughness: 0.87, metalness: 0.02, emissiveMap: f.night, emissive: 0xffcf9c, nightK: 0.9 });
    },
    glass: function (kit) {
      var f = kit.facadeGlass;
      return kit.std({ map: f.day, color: 0xffffff, roughness: 0.22, metalness: 0.32, emissiveMap: f.night, emissive: 0xffd6a4, nightK: 1.15 });
    },
    glassSoft: function (kit) {
      var f = kit.facadeGlass;
      return kit.std({ map: f.day, color: 0xd9e6ee, roughness: 0.26, metalness: 0.25, emissiveMap: f.night, emissive: 0xffd6a4, nightK: 1.1 });
    },
    glassDoor: function (kit) {
      return kit.std({ color: 0x25333e, roughness: 0.16, metalness: 0.55, emissive: 0xffd9a0, emissiveIntensity: 0, nightK: 0.5 });
    },
    rail: function (kit) {
      return kit.std({ color: 0xa9c5d6, roughness: 0.12, metalness: 0.15, transparent: true, opacity: 0.4, side: THREE.DoubleSide });
    },
    base: function (kit) {
      return kit.std({ map: getSimpleTexture('brick'), color: 0xffffff, roughness: 0.92, metalness: 0.0 });
    },
    stone: function (kit) {
      return kit.std({ map: getSimpleTexture('granite'), color: 0xd8d5cf, roughness: 0.9, metalness: 0.02 });
    },
    accent: function (kit) {
      return kit.std({ color: kit.pal().accent, roughness: 0.62, metalness: 0.05 });
    },
    trim: function (kit) {
      return kit.std({ color: 0xf3f2ee, roughness: 0.55, metalness: 0.03 });
    },
    trimWarm: function (kit) {
      return kit.std({ color: 0xe8e0d1, roughness: 0.65 });
    },
    white: function (kit) {
      return kit.std({ color: 0xf8f8f5, roughness: 0.45 });
    },
    metal: function (kit) {
      return kit.std({ color: 0x8d949c, roughness: 0.38, metalness: 0.62 });
    },
    darkMetal: function (kit) {
      return kit.std({ color: 0x363c42, roughness: 0.5, metalness: 0.45 });
    },
    roof: function (kit) {
      var kind = kit.def.roofKind || 'gravel';
      var texKind = kind === 'metal' ? 'roofMetal' : (kind === 'tile' ? 'roofTile' : 'roofGravel');
      return kit.std({ map: getSimpleTexture(texKind), color: kit.pal().roof, roughness: kind === 'metal' ? 0.62 : 0.86, metalness: kind === 'metal' ? 0.3 : 0.04 });
    },
    roofMetal: function (kit) {
      return kit.std({ map: getSimpleTexture('roofMetal'), color: kit.pal().roof, roughness: 0.6, metalness: 0.3 });
    },
    roofTile: function (kit) {
      return kit.std({ map: getSimpleTexture('roofTile'), color: 0xffffff, roughness: 0.82 });
    },
    green: function (kit) {
      return kit.std({ color: 0x517a3d, roughness: 0.95 });
    },
    wood: function (kit) {
      return kit.std({ color: 0x8a6a4c, roughness: 0.8 });
    },
    gold: function (kit) {
      return kit.std({ color: 0xc9a35c, roughness: 0.34, metalness: 0.65 });
    },
    lamp: function (kit) {
      return kit.std({ color: 0x6d6558, emissive: 0xffd9a0, emissiveIntensity: 0, nightK: 2.4, roughness: 0.4 });
    }
  };

  /* ======================================================================
   * 3. 几何 Builder：按材质聚合，最后合并为少量 Mesh（控制 draw call）
   * ==================================================================== */
  function Builder() {
    this.buckets = new Map();
    this.baseM = null;
    this.count = 0;
  }
  Builder.prototype.setBase = function (x, y, z, rot) {
    ensureLib();
    if (!x && !y && !z && !rot) { this.baseM = null; return; }
    var m = new THREE.Matrix4();
    var q = new THREE.Quaternion();
    if (rot) { q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rot); }
    m.compose(new THREE.Vector3(x || 0, y || 0, z || 0), q, new THREE.Vector3(1, 1, 1));
    this.baseM = m;
  };
  Builder.prototype.add = function (mat, geo, x, y, z, rx, ry, rz) {
    if (!mat || !geo) { return; }
    var arr = this.buckets.get(mat);
    if (!arr) { arr = []; this.buckets.set(mat, arr); }
    arr.push({ geo: geo, x: x || 0, y: y || 0, z: z || 0, rx: rx || 0, ry: ry || 0, rz: rz || 0 });
    this.count++;
  };
  Builder.prototype.build = function (group) {
    ensureLib();
    var _m4 = new THREE.Matrix4();
    var _pos = new THREE.Vector3();
    var _quat = new THREE.Quaternion();
    var _euler = new THREE.Euler();
    var _one = new THREE.Vector3(1, 1, 1);
    var self = this;
    var tris = 0;
    this.buckets.forEach(function (items, mat) {
      var geos = [];
      var vcount = 0;
      var i, j, g, it;
      for (i = 0; i < items.length; i++) {
        it = items[i];
        g = it.geo;
        if (g.index) { var ng = g.toNonIndexed(); g.dispose(); g = ng; }
        if (it.rx || it.ry || it.rz) {
          _euler.set(it.rx, it.ry, it.rz, 'XYZ');
          _quat.setFromEuler(_euler);
          _m4.compose(_pos.set(it.x, it.y, it.z), _quat, _one);
        } else {
          _m4.makeTranslation(it.x, it.y, it.z);
        }
        if (self.baseM) {
          var mm = new THREE.Matrix4().multiplyMatrices(self.baseM, _m4);
          g.applyMatrix4(mm);
        } else {
          g.applyMatrix4(_m4);
        }
        geos.push(g);
        vcount += g.attributes.position.count;
      }
      if (!vcount) { return; }
      var hasUV = true;
      for (i = 0; i < geos.length; i++) {
        g = geos[i];
        if (!g.attributes.normal) { g.computeVertexNormals(); }
        if (!g.attributes.uv) { hasUV = false; }
      }
      if (hasUV) {
        for (i = 0; i < geos.length; i++) {
          g = geos[i];
          if (!g.attributes.uv) {
            g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(g.attributes.position.count * 2), 2));
          }
        }
      }
      var posArr = new Float32Array(vcount * 3);
      var norArr = new Float32Array(vcount * 3);
      var uvArr = hasUV ? new Float32Array(vcount * 2) : null;
      var off = 0;
      for (i = 0; i < geos.length; i++) {
        g = geos[i];
        posArr.set(g.attributes.position.array, off * 3);
        norArr.set(g.attributes.normal.array, off * 3);
        if (uvArr) { uvArr.set(g.attributes.uv.array, off * 2); }
        off += g.attributes.position.count;
        g.dispose();
      }
      var merged = new THREE.BufferGeometry();
      merged.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
      merged.setAttribute('normal', new THREE.BufferAttribute(norArr, 3));
      if (uvArr) { merged.setAttribute('uv', new THREE.BufferAttribute(uvArr, 2)); }
      merged.computeBoundingBox();
      merged.computeBoundingSphere();
      var mesh = new THREE.Mesh(merged, mat);
      mesh.name = (group.name || 'bld') + ':' + (mat.name || 'mat');
      var basic = !!mat.isMeshBasicMaterial;
      mesh.castShadow = (!basic && !mat.transparent);
      mesh.receiveShadow = !basic;
      if (mat.transparent) { mesh.renderOrder = 3; }
      group.add(mesh);
      tris += vcount / 3;
    });
    return tris;
  };

  /* ---------- 3.1 UV 缩放（让立面纹理按开间/层数重复，而不是拉满一面墙） ---------- */
  function scaleBoxUV(geo, w, h, d, tw, th, vScale) {
    var uv = geo.attributes.uv;
    if (!uv) { return geo; }
    var sv = (vScale !== undefined && vScale > 0) ? vScale : h / th;
    var suX = d / tw, suZ = w / tw;
    // BoxGeometry 面顺序: +X, -X, +Y, -Y, +Z, -Z（每面 4 个顶点）
    var su = [suX, suX, suZ, suZ, suZ, suZ];
    var svs = [sv, sv, d / th, d / th, sv, sv];
    for (var f = 0; f < 6; f++) {
      for (var i = 0; i < 4; i++) {
        var k = f * 4 + i;
        if (k >= uv.count) { break; }
        uv.setXY(k, uv.getX(k) * su[f], uv.getY(k) * svs[f]);
      }
    }
    uv.needsUpdate = true;
    return geo;
  }

  function scaleCylUV(geo, circ, h, tw, th, vScale) {
    var uv = geo.attributes.uv;
    if (!uv) { return geo; }
    var su = circ / tw;
    var sv = (vScale !== undefined && vScale > 0) ? vScale : h / th;
    for (var i = 0; i < uv.count; i++) {
      uv.setXY(i, uv.getX(i) * su, uv.getY(i) * sv);
    }
    uv.needsUpdate = true;
    return geo;
  }

  /* ======================================================================
   * 4. 几何与构件小工具
   * ==================================================================== */
  function box(b, mat, w, h, d, x, y, z, ry) {
    if (!(w > 0) || !(h > 0) || !(d > 0)) { return; }
    b.add(mat, new THREE.BoxGeometry(w, h, d), x, y, z, 0, ry || 0, 0);
  }
  function boxR(b, mat, w, h, d, x, y, z, rx, ry, rz) {
    if (!(w > 0) || !(h > 0) || !(d > 0)) { return; }
    b.add(mat, new THREE.BoxGeometry(w, h, d), x, y, z, rx || 0, ry || 0, rz || 0);
  }
  function texBox(b, mat, w, h, d, x, y, z, ry, tw, th) {
    if (!(w > 0) || !(h > 0) || !(d > 0)) { return; }
    var g = new THREE.BoxGeometry(w, h, d);
    scaleBoxUV(g, w, h, d, tw || 4, th || 4);
    b.add(mat, g, x, y, z, 0, ry || 0, 0);
  }
  /** 立面盒（贴图按 tw×th 重复；vScale 一般传层数，使窗格与楼层对齐） */
  function facadeBox(b, kit, key, w, h, d, x, y, z, ry, vScale) {
    if (!(w > 0) || !(h > 0) || !(d > 0)) { return; }
    var mat = kit.get(key);
    var f = (key === 'glass' || key === 'glassSoft') ? kit.facadeGlass : kit.facadeWall;
    var g = new THREE.BoxGeometry(w, h, d);
    scaleBoxUV(g, w, h, d, f.tw, f.th, vScale);
    b.add(mat, g, x, y, z, 0, ry || 0, 0);
  }
  function cyl(b, mat, rTop, rBot, h, seg, x, y, z, open, tStart, tLen) {
    if (!(h > 0) || !(rTop > 0) || !(rBot > 0)) { return; }
    seg = Math.max(4, seg | 0 || 12);
    var g = new THREE.CylinderGeometry(rTop, rBot, h, seg, 1, !!open,
      tStart === undefined ? 0 : tStart,
      tLen === undefined ? PI * 2 : tLen);
    b.add(mat, g, x, y, z, 0, 0, 0);
  }
  function cylUV(b, kit, key, r, h, seg, x, y, z, tStart, tLen, vScale) {
    if (!(h > 0) || !(r > 0)) { return; }
    seg = Math.max(4, seg | 0 || 16);
    var g = new THREE.CylinderGeometry(r, r, h, seg, 1, true,
      tStart === undefined ? 0 : tStart,
      tLen === undefined ? PI * 2 : tLen);
    var f = (key === 'glass' || key === 'glassSoft') ? kit.facadeGlass : kit.facadeWall;
    scaleCylUV(g, PI * 2 * r, h, f.tw, f.th, vScale);
    b.add(kit.get(key), g, x, y, z, 0, 0, 0);
  }
  function sphereUp(b, mat, r, x, y, z, segW, segH) {
    if (!(r > 0)) { return; }
    var g = new THREE.SphereGeometry(r, Math.max(6, segW | 0 || 12), Math.max(4, segH | 0 || 6), 0, PI * 2, 0, PI / 2);
    b.add(mat, g, x, y, z, 0, 0, 0);
  }
  function disc(b, mat, r, seg, x, y, z, rx) {
    if (!(r > 0)) { return; }
    var g = new THREE.CircleGeometry(r, Math.max(6, seg | 0 || 16));
    b.add(mat, g, x, y, z, (rx === undefined ? -PI / 2 : rx), 0, 0);
  }
  function planeFront(b, mat, w, h, x, y, z, ry) {
    if (!(w > 0) || !(h > 0)) { return; }
    var g = new THREE.PlaneGeometry(w, h);
    b.add(mat, g, x, y, z, 0, ry || 0, 0);
  }
  function triPrism(b, mat, w, rise, d, x, y, z) {
    var shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.lineTo(d, rise);
    shape.lineTo(d, 0);
    shape.lineTo(0, 0);
    var g = new THREE.ExtrudeGeometry(shape, { depth: w, bevelEnabled: false, steps: 1 });
    g.rotateY(-PI / 2);
    g.translate(w / 2, 0, -d / 2);
    b.add(mat, g, x, y, z, 0, 0, 0);
  }
  /** 三角形面片（山墙）：ZW/WZ 面上的直角三角形或等腰三角形 */
  function triangleShapeGeo(points) {
    var s = new THREE.Shape();
    s.moveTo(points[0][0], points[0][1]);
    for (var i = 1; i < points.length; i++) { s.lineTo(points[i][0], points[i][1]); }
    s.closePath();
    return new THREE.ShapeGeometry(s);
  }

  /* ======================================================================
   * 5. 通用建筑构件
   * ==================================================================== */

  /** 基座（石/砖），略大于主体，y 从 0 起 */
  function addPlinth(b, kit, w, d, h, over, matKey) {
    texBox(b, kit.get(matKey || 'stone'), w + over * 2, h, d + over * 2, 0, h / 2, 0, 0, 2.4, 1.2);
  }

  /** 女儿墙（屋顶四周）+ 压顶 */
  function addParapet(b, kit, w, d, yTop, h, t, matKey) {
    h = h || 0.9; t = t || 0.35;
    var mat = kit.get(matKey || 'trim');
    var cop = kit.get('accent');
    var hw = w / 2, hd = d / 2;
    box(b, mat, w, h, t, 0, yTop + h / 2, hd - t / 2);
    box(b, mat, w, h, t, 0, yTop + h / 2, -hd + t / 2);
    box(b, mat, t, h, d - t * 2, hw - t / 2, yTop + h / 2, 0);
    box(b, mat, t, h, d - t * 2, -hw + t / 2, yTop + h / 2, 0);
    box(b, cop, w + 0.24, 0.12, t + 0.12, 0, yTop + h, hd - t / 2);
    box(b, cop, w + 0.24, 0.12, t + 0.12, 0, yTop + h, -hd + t / 2);
  }

  /** 屋面（铺装/金属/瓦） */
  function addRoofDeck(b, kit, w, d, yTop, matKey) {
    texBox(b, kit.get(matKey || 'roof'), Math.max(1, w - 0.4), 0.3, Math.max(1, d - 0.4), 0, yTop + 0.15, 0, 0, 4, 4);
  }

  /** 平屋顶：屋面 + 女儿墙 */
  function addFlatRoof(b, kit, vol, w, d, yTop, opts) {
    opts = opts || {};
    addRoofDeck(b, kit, w, d, yTop);
    addParapet(b, kit, w, d, yTop + 0.3, opts.parapetH || 0.9, opts.thick || 0.35, opts.mat);
  }

  /** 山墙三角面片（坡屋顶两端） */
  function addGableTri(b, mat, w, d, rise, x, y, z, faceDir) {
    var s = new THREE.Shape();
    s.moveTo(-d / 2, 0);
    s.lineTo(d / 2, 0);
    s.lineTo(0, rise);
    s.closePath();
    var g = new THREE.ShapeGeometry(s);
    if (faceDir > 0) { g.rotateY(PI / 2); } else { g.rotateY(-PI / 2); }
    b.add(mat, g, x, y, z, 0, 0, 0);
  }

  /** 双坡屋顶（屋脊沿 X） */
  function addPitchRoof(b, kit, vol, w, d, yTop, opts) {
    opts = opts || {};
    var rise = opts.rise || Math.min(d * 0.34, Math.max(1.2, d * 0.3));
    var over = opts.over || 0.85;
    var halfD = d / 2 + over;
    var ang = Math.atan2(rise, halfD);
    var slopeLen = Math.sqrt(halfD * halfD + rise * rise);
    var roofMat = kit.get(opts.mat || 'roofTile');
    var len = w + over * 2;
    boxR(b, roofMat, len, 0.26, slopeLen + 0.15, 0, yTop + rise / 2, halfD / 2, ang, 0, 0);
    boxR(b, roofMat, len, 0.26, slopeLen + 0.15, 0, yTop + rise / 2, -halfD / 2, -ang, 0, 0);
    // 山墙
    var gm = kit.get(opts.gableMat || 'trimWarm');
    addGableTri(b, gm, w, d, rise + 0.02, w / 2 - 0.05, yTop, 0, 1);
    addGableTri(b, gm, w, d, rise + 0.02, -w / 2 + 0.05, yTop, 0, -1);
    // 屋脊
    box(b, kit.get(opts.ridgeMat || 'accent'), len + 0.15, 0.3, 0.42, 0, yTop + rise + 0.06, 0);
    // 檐口封边
    box(b, kit.get('trimWarm'), len, 0.22, 0.24, 0, yTop + 0.06, halfD - 0.05);
    box(b, kit.get('trimWarm'), len, 0.22, 0.24, 0, yTop + 0.06, -halfD + 0.05);
  }

  /** 锯齿形（北向采光）屋顶：剖面沿 Z 排列，挤出沿 X */
  function addSawtoothRoof(b, kit, vol, w, d, yTop, teeth, opts) {
    opts = opts || {};
    teeth = clamp(teeth || Math.round(d / 6), 2, 10);
    var dd = d / teeth;
    var rise = Math.min(dd * 0.6, 3.4);
    var shape = new THREE.Shape();
    shape.moveTo(0, 0);
    for (var i = 0; i < teeth; i++) {
      shape.lineTo(dd * (i + 1), rise);
      shape.lineTo(dd * (i + 1), 0);
    }
    shape.lineTo(0, 0);
    var g = new THREE.ExtrudeGeometry(shape, { depth: w, bevelEnabled: false, steps: 1 });
    g.rotateY(-PI / 2);
    g.translate(w / 2, 0, -d / 2);
    b.add(kit.get(opts.mat || 'roofMetal'), g, 0, yTop, 0, 0, 0, 0);
    // 每个齿的竖向玻璃（北向天窗）
    var glass = kit.get(opts.glassMat || 'glassDoor');
    for (var t = 0; t < teeth; t++) {
      var z = -d / 2 + (t + 1) * dd;
      box(b, glass, w * 0.96, rise * 0.82, 0.1, 0, yTop + rise * 0.5, z + 0.06);
    }
    // 檐口
    box(b, kit.get('trim'), w + 0.3, 0.24, 0.3, 0, yTop + 0.05, -d / 2 + 0.1);
  }

  /** 金属穹顶（可压扁） */
  function addDome(b, kit, r, y, opts) {
    opts = opts || {};
    var hgt = opts.h || r * 0.86;
    var mat = kit.get(opts.mat || 'metal');
    var g = new THREE.SphereGeometry(r, 20, 10, 0, PI * 2, 0, PI / 2);
    g.scale(1, hgt / r, 1);
    b.add(mat, g, 0, y, 0, 0, 0, 0);
    // 基座环 / 环向加强环
    cyl(b, kit.get('trim'), r + 0.4, r + 0.4, 0.55, 20, 0, y - 0.08, 0);
    var t = 0.38;
    var rr = r * Math.sqrt(Math.max(0.04, 1 - t * t));
    var ring = new THREE.TorusGeometry(rr, 0.11, 3, 18);
    ring.rotateX(PI / 2);
    b.add(kit.get('gold'), ring, 0, y + hgt * t, 0, 0, 0, 0);
    // 宝顶
    cyl(b, kit.get('gold'), r * 0.05, r * 0.1, hgt * 0.28, 8, 0, y + hgt + hgt * 0.14, 0);
    sphereUp(b, kit.get('gold'), Math.max(0.18, r * 0.07), 0, y + hgt + hgt * 0.26, 0, 8, 5);
  }

  /** 台阶：从建筑边缘向 dir 方向下到地面（最内侧台阶顶 = count*rise） */
  function addSteps(b, kit, matKey, width, zEdge, dir, count, rise, run) {
    count = Math.max(1, count | 0);
    for (var i = 0; i < count; i++) {
      var topY = (count - i) * rise;
      var z = zEdge + dir * (i + 0.5) * run;
      box(b, kit.get(matKey || 'stone'), width - i * (width * 0.025), topY, run + 0.04, 0, topY / 2, z);
    }
  }

  /**
   * 主入口门斗 + 雨棚 + 柱子 + 入口灯。
   * @returns {{frontZ:number, topY:number, dir:number, width:number}}
   */
  function addEntrance(b, kit, vol, opts) {
    opts = opts || {};
    var dir = opts.dir || (vol.entrance === 'north' ? -1 : 1);
    if (_suppressEntrance) {
      return { frontZ: dir * (vol.d / 2), topY: vol.h * 0.5, dir: dir, width: 4 };
    }
    var front = vol.d / 2;
    var baseY = opts.baseY || 0;
    var pw = clamp(opts.width || vol.w * 0.24, 4.2, 20);
    var pd = opts.depth || 2.6;
    var ph = opts.height || Math.min(vol.fh * 1.5, 6.4);
    var matKey = opts.mat || 'accent';
    // 门斗体量
    box(b, kit.get(matKey), pw, ph, pd, 0, baseY + ph / 2, dir * (front + pd / 2));
    // 玻璃门
    box(b, kit.get('glassDoor'), pw * 0.8, ph * 0.7, 0.18, 0, baseY + ph * 0.35, dir * (front + pd + 0.02));
    // 门框
    box(b, kit.get('trim'), pw * 0.86, ph * 0.78, 0.05, 0, baseY + ph * 0.39, dir * (front + pd + 0.08));
    box(b, kit.get('glassDoor'), pw * 0.78, ph * 0.68, 0.05, 0, baseY + ph * 0.34, dir * (front + pd + 0.11));
    // 中梃
    box(b, kit.get('trim'), 0.26, ph * 0.7, 0.16, 0, baseY + ph * 0.35, dir * (front + pd + 0.13));
    // 雨棚
    var cw = pw + 2.4;
    box(b, kit.get('trim'), cw, 0.32, pd + 1.7, 0, baseY + ph + 0.22, dir * (front + (pd + 1.7) / 2 - 0.5));
    // 雨棚柱
    var colX = pw / 2 + 1.0;
    var colH = ph + 0.22;
    box(b, kit.get('trim'), 0.3, colH, 0.3, colX, baseY + colH / 2, dir * (front + pd + 0.85));
    box(b, kit.get('trim'), 0.3, colH, 0.3, -colX, baseY + colH / 2, dir * (front + pd + 0.85));
    // 入口灯（夜间发光）
    box(b, kit.get('lamp'), pw * 0.5, 0.16, 0.26, 0, baseY + ph + 0.02, dir * (front + pd * 0.55));
    // 平台
    if (baseY <= 0.15) {
      box(b, kit.get('stone'), pw + 1.6, 0.18, pd + 1.4, 0, 0.09, dir * (front + (pd + 1.4) / 2 - 0.2));
    }
    return { frontZ: dir * (front + pd), topY: baseY + ph, dir: dir, width: pw };
  }

  /**
   * 建筑名牌（深色牌面 + 中文名 + 金属背板）。
   * opts: { x, y, bottom, z, dir, height, width, fascia }
   *   height/width: 牌面尺寸（默认 height=clamp(vol.h*0.07, 1.0, 2.8)，宽高比 4:1）
   *   bottom: 牌面底边高度（优先于 y）
   *   fascia: 传入材质 key（如 'trim'）时，在牌面后加一条门头横幅
   * @returns {THREE.Material|null}
   */
  function addSign(b, kit, vol, opts) {
    if (!vol.name || vol.sign === false || _suppressSign) { return null; }
    opts = opts || {};
    var dir = opts.dir || (vol.entrance === 'north' ? -1 : 1);
    var signH = opts.height || clamp(vol.h * 0.07, 1.0, 2.8);
    var signW = opts.width || signH * 4;
    signW = Math.min(signW, Math.max(2.4, vol.w * 0.8));
    if (opts.width && !opts.height) { signH = signW * 0.25; }
    var x = opts.x || 0;
    var y = (opts.bottom !== undefined) ? (opts.bottom + signH / 2)
      : ((opts.y !== undefined) ? opts.y : vol.h * 0.62);
    var z = (opts.z !== undefined) ? opts.z : dir * (vol.d / 2 + 0.16);
    // 门头横幅
    if (opts.fascia) {
      box(b, kit.get(typeof opts.fascia === 'string' ? opts.fascia : 'trim'),
        signW + 0.9, signH + 0.6, 0.6, x, y, z - dir * 0.3);
    }
    // 深色牌底
    box(b, kit.get('darkMetal'), signW + 0.36, signH + 0.26, 0.16, x, y, z - dir * 0.04);
    // 文字面
    var tex = createBuildingLabelTexture(vol.name);
    var mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.FrontSide });
    mat.toneMapped = false;
    mat.name = 'sign';
    if (mat.userData) { mat.userData.kind = 'sign'; }
    var g = new THREE.PlaneGeometry(signW, signH);
    b.add(mat, g, x, y, z + dir * 0.06, 0, dir < 0 ? PI : 0, 0);
    return mat;
  }

  /** 楼层线脚（每层一圈，略微出挑） */
  function addFloorBands(b, kit, w, d, y0, fh, floors, matKey, thick, out) {
    var mat = kit.get(matKey || 'trim');
    thick = thick || 0.18;
    out = out || 0.3;
    for (var f = 1; f < floors; f++) {
      box(b, mat, w + out, thick, d + out, 0, y0 + f * fh, 0);
    }
  }

  /** 角柱（四角壁柱，增强体量感） */
  function addCornerPilasters(b, kit, w, d, y0, h, size, matKey) {
    size = size || 1.1;
    var mat = kit.get(matKey || 'trim');
    var x = w / 2 - size / 2 + 0.08;
    var z = d / 2 - size / 2 + 0.08;
    box(b, mat, size, h, size, x, y0 + h / 2, z);
    box(b, mat, size, h, size, -x, y0 + h / 2, z);
    box(b, mat, size, h, size, x, y0 + h / 2, -z);
    box(b, mat, size, h, size, -x, y0 + h / 2, -z);
  }

  /** 宿舍/公寓阳台：板 + 玻璃栏板 + 顶栏 + 可选空调机位 */
  function addBalcony(b, kit, bw, x, y, z, opts) {
    opts = opts || {};
    box(b, kit.get('trim'), bw, 0.22, 1.35, x, y, z);
    box(b, kit.get('rail'), bw - 0.16, 1.0, 0.07, x, y + 0.61, z + 0.65);
    if (!opts.min) {
      box(b, kit.get('metal'), bw, 0.07, 0.12, x, y + 1.13, z + 0.65);
    }
    if (opts.ac) {
      box(b, kit.get('metal'), 0.72, 0.55, 0.42, x + bw * 0.26, y + 0.45, z - 0.34);
    }
  }

  /** 屋顶设备机组 */
  function addRoofUnits(b, kit, rng, areaW, areaD, yTop, count, maxW) {
    count = count || 3;
    maxW = maxW || 3;
    for (var i = 0; i < count; i++) {
      var uw = 1.2 + rng() * maxW;
      var ud = 1.0 + rng() * maxW;
      var uh = 0.6 + rng() * 1.3;
      var ux = (rng() - 0.5) * Math.max(0.5, areaW - uw - 2);
      var uz = (rng() - 0.5) * Math.max(0.5, areaD - ud - 2);
      box(b, kit.get('metal'), uw, uh, ud, ux, yTop + uh / 2, uz);
      if (uh > 1.2) {
        box(b, kit.get('darkMetal'), uw * 0.6, 0.12, ud * 0.6, ux, yTop + uh + 0.06, uz);
      }
    }
  }

  /** 屋顶水箱（宿舍/公寓/食堂） */
  function addWaterTank(b, kit, r, hgt, x, yTop, z) {
    cyl(b, kit.get('metal'), r, r, hgt, 12, x, yTop + 0.9 + hgt / 2, z);
    // 顶盖
    cyl(b, kit.get('darkMetal'), r * 0.92, r * 1.02, 0.2, 12, x, yTop + 0.9 + hgt + 0.1, z);
    // 支架
    var lx = r * 0.65, lz = r * 0.65;
    box(b, kit.get('darkMetal'), 0.22, 0.95, 0.22, x + lx, yTop + 0.47, z + lz);
    box(b, kit.get('darkMetal'), 0.22, 0.95, 0.22, x - lx, yTop + 0.47, z + lz);
    box(b, kit.get('darkMetal'), 0.22, 0.95, 0.22, x + lx, yTop + 0.47, z - lz);
    box(b, kit.get('darkMetal'), 0.22, 0.95, 0.22, x - lx, yTop + 0.47, z - lz);
  }

  /** 宿舍屋顶晾衣架 */
  function addDryingRack(b, kit, w, x, yTop, z) {
    var mat = kit.get('metal');
    box(b, mat, 0.14, 1.9, 0.14, x - w / 2 + 0.4, yTop + 0.95, z);
    box(b, mat, 0.14, 1.9, 0.14, x + w / 2 - 0.4, yTop + 0.95, z);
    for (var i = 0; i < 3; i++) {
      box(b, mat, w - 0.8, 0.08, 0.08, x, yTop + 1.35 + i * 0.28, z + (i - 1) * 0.45);
    }
  }

  /** 烟囱 / 排风塔 */
  function addChimney(b, kit, r, hgt, x, yTop, z, opts) {
    opts = opts || {};
    var mat = kit.get(opts.mat || 'metal');
    var seg = 12;
    cyl(b, mat, r, r * 1.12, hgt, seg, x, yTop + hgt / 2, z);
    // 环箍
    var n = Math.max(2, Math.round(hgt / 3));
    for (var i = 1; i <= n; i++) {
      cyl(b, kit.get('darkMetal'), r * 1.1, r * 1.1, 0.16, seg, x, yTop + (hgt * i) / (n + 1), z);
    }
    // 顶部伞形罩
    cyl(b, kit.get('darkMetal'), r * 1.45, r * 0.9, 0.35, seg, x, yTop + hgt + 0.18, z);
    cyl(b, mat, r * 0.55, r * 0.55, 0.25, seg, x, yTop + hgt + 0.46, z);
  }

  /** 屋面排风机 / 蘑菇头通风器 */
  function addVent(b, kit, r, hgt, x, yTop, z) {
    cyl(b, kit.get('metal'), r * 0.7, r, hgt * 0.7, 10, x, yTop + hgt * 0.35, z);
    cyl(b, kit.get('darkMetal'), r * 1.35, r * 0.75, hgt * 0.28, 10, x, yTop + hgt * 0.82, z);
  }

  /** 屋顶太阳能板阵列（教学/实验楼细节） */
  function addSolarPanels(b, kit, rng, w, d, yTop) {
    var mat = kit.get('darkMetal');
    var cols = Math.max(2, Math.round(w / 6));
    for (var i = 0; i < cols; i++) {
      var x = -w / 2 + (i + 0.5) * (w / cols);
      boxR(b, mat, 3.2, 0.08, 2.0, x, yTop + 0.75, 0, 0.35, 0, 0);
      box(b, kit.get('metal'), 0.12, 0.8, 0.12, x - 1.3, yTop + 0.4, 0.8);
      box(b, kit.get('metal'), 0.12, 0.8, 0.12, x + 1.3, yTop + 0.4, 0.8);
    }
  }

  /** 拱形屋面（体育馆）：半圆柱 + 可压扁 + 两端半圆封头 */
  function addBarrelRoof(b, kit, r, len, wallH, k, opts) {
    opts = opts || {};
    var seg = opts.seg || 18;
    var g = new THREE.CylinderGeometry(r, r, len, seg, 1, true, 0, PI);
    g.rotateZ(PI / 2);
    g.scale(1, k, 1);
    b.add(kit.get(opts.mat || 'roofMetal'), g, 0, wallH, 0, 0, 0, 0);
    // 端部半圆封头
    for (var s = -1; s <= 1; s += 2) {
      var cg = new THREE.CircleGeometry(r, seg, 0, PI);
      cg.rotateY(s > 0 ? PI / 2 : -PI / 2);
      cg.scale(1, k, 1);
      b.add(kit.get(opts.capMat || 'wall'), cg, s * len / 2, wallH, 0, 0, 0, 0);
    }
    // 拱肋
    var ribs = opts.ribs === undefined ? 5 : opts.ribs;
    if (ribs > 0) {
      for (var i = 0; i < ribs; i++) {
        var x = -len / 2 + (i + 0.5) * (len / ribs);
        var rg = new THREE.CylinderGeometry(r + 0.16, r + 0.16, 0.42, seg, 1, true, 0, PI);
        rg.rotateZ(PI / 2);
        rg.scale(1, k, 1);
        b.add(kit.get(opts.ribMat || 'trim'), rg, x, wallH, 0, 0, 0, 0);
      }
    }
    // 檐口
    box(b, kit.get('trim'), len + 0.4, 0.3, 0.4, 0, wallH - 0.05, r - 0.1);
    box(b, kit.get('trim'), len + 0.4, 0.3, 0.4, 0, wallH - 0.05, -r + 0.1);
  }

  /* ======================================================================
   * 6. 体量组合工具（多体量立面 + 楼层线 + 角柱 + 屋顶）
   * ==================================================================== */

  /**
   * 批量建立体量（每个体量 = 立面盒 + 楼层线脚 + 可选角柱）。
   * defs: [{ w,d,h,x?,z?,y?,mat?,floors?,vScale?,bands?,bandEvery?,bandMat?,
   *          corners?,cornerSize?,cornerMat?,noFacade?,plainMat? }]
   * @returns {Array} 体量信息 [{w,d,x,z,y0,h,yTop,floors}]
   */
  function addMassing(b, kit, vol, defs, opts) {
    opts = opts || {};
    var baseY = opts.y0 || 0;
    var fh = vol.fh;
    var out = [];
    for (var i = 0; i < defs.length; i++) {
      var df = defs[i];
      var x = df.x || 0, z = df.z || 0;
      var yy = baseY + (df.y || 0);
      var hgt = df.h;
      if (!(hgt > 0) || !(df.w > 0) || !(df.d > 0)) { continue; }
      var floors = df.floors || Math.max(1, Math.round(hgt / fh));
      if (df.noFacade) {
        box(b, kit.get(df.plainMat || 'trimWarm'), df.w, hgt, df.d, x, yy + hgt / 2, z, df.rot || 0);
      } else {
        facadeBox(b, kit, df.mat || 'wall', df.w, hgt, df.d, x, yy + hgt / 2, z, df.rot || 0, df.vScale || floors);
      }
      // 楼层线脚
      if (df.bands !== false) {
        var bandMat = kit.get(df.bandMat || 'trim');
        var every = Math.max(1, df.bandEvery || 1);
        for (var f = every; f < floors; f += every) {
          if (yy + f * fh >= yy + hgt - 0.3) { break; }
          box(b, bandMat, df.w + 0.28, 0.16, df.d + 0.28, x, yy + f * fh, z);
        }
      }
      // 角柱
      if (df.corners) {
        var size = df.cornerSize || 1.1;
        var px = df.w / 2 - size / 2 + 0.08;
        var pz = df.d / 2 - size / 2 + 0.08;
        var cm = kit.get(df.cornerMat || 'trim');
        box(b, cm, size, hgt, size, x + px, yy + hgt / 2, z + pz);
        box(b, cm, size, hgt, size, x - px, yy + hgt / 2, z + pz);
        box(b, cm, size, hgt, size, x + px, yy + hgt / 2, z - pz);
        box(b, cm, size, hgt, size, x - px, yy + hgt / 2, z - pz);
      }
      // 顶部檐口线
      if (df.cornice !== false) {
        box(b, kit.get(df.corniceMat || 'accent'), df.w + 0.5, 0.28, df.d + 0.5, x, yy + hgt - 0.16, z);
      }
      out.push({ w: df.w, d: df.d, x: x, z: z, y0: yy, h: hgt, yTop: yy + hgt, floors: floors, def: df });
    }
    return out;
  }

  /** 为体量加屋顶：主楼按 spec.roof（pitch / sawtooth / dome），其余平屋顶 */
  function addMassRoofs(b, kit, vol, bodies, opts) {
    opts = opts || {};
    var type = vol.roof || opts.defaultType || 'flat';
    for (var i = 0; i < bodies.length; i++) {
      var bd = bodies[i];
      var isMain = (i === 0);
      if (isMain && type === 'pitch') {
        addPitchRoof(b, kit, vol, bd.w, bd.d, bd.yTop, opts.pitch);
        continue;
      }
      if (isMain && type === 'sawtooth') {
        addSawtoothRoof(b, kit, vol, bd.w, bd.d, bd.yTop, opts.teeth);
        continue;
      }
      if (isMain && type === 'dome') {
        addDome(b, kit, Math.min(bd.w, bd.d) * 0.42, bd.yTop + 0.3, opts.dome);
        continue;
      }
      addFlatRoof(b, kit, vol, bd.w, bd.d, bd.yTop, { parapetH: (opts.parapetH || 0.9), thick: opts.thick || 0.35 });
    }
  }

  /* ======================================================================
   * 7. 风格生成器
   * ==================================================================== */
  var STYLES = {};

  /* ------------------------------ 图文信息中心（地标） ------------------------------ */
  STYLES.library = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors, fh = vol.fh;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 1.5;
    var podiumFloors = clamp(Math.round(floors * 0.22), 2, 4);
    var podiumH = podiumFloors * fh;
    var y0 = plinthH;
    var podiumTop = y0 + podiumH;
    var towerW = w * 0.5, towerD = d * 0.58;
    var crownH = Math.min(8, h * 0.15);
    var towerTop = h - crownH;
    var towerH = Math.max(6, towerTop - y0);
    var f, i;

    // 台地
    addPlinth(b, kit, w, d, plinthH, 2.8, 'stone');

    // 裙房：蓝玻璃幕墙 + 白色水平带
    facadeBox(b, kit, 'glass', w, podiumH, d, 0, y0 + podiumH / 2, 0, 0, podiumFloors);
    for (f = 1; f < podiumFloors; f++) {
      box(b, kit.get('trim'), w + 0.6, 0.45, d + 0.6, 0, y0 + f * fh, 0);
    }
    addRoofDeck(b, kit, w, d, podiumTop);
    addParapet(b, kit, w, d, podiumTop + 0.3, 0.75, 0.4);
    // 裙房屋顶露台绿化
    if (w > 44) {
      box(b, kit.get('trim'), w * 0.18, 0.22, d * 0.2, w * 0.32, podiumTop + 0.66, -d * 0.2);
      box(b, kit.get('green'), w * 0.16, 0.5, d * 0.18, w * 0.32, podiumTop + 0.75, -d * 0.2);
      box(b, kit.get('trim'), w * 0.18, 0.22, d * 0.2, -w * 0.32, podiumTop + 0.66, -d * 0.2);
      box(b, kit.get('green'), w * 0.16, 0.5, d * 0.18, -w * 0.32, podiumTop + 0.75, -d * 0.2);
    }

    // 塔楼：玻璃体 + 白色竖向遮阳肋
    facadeBox(b, kit, 'glass', towerW, towerH, towerD, 0, y0 + towerH / 2, 0, 0, floors);
    var finTop = towerTop - 1.4;
    var finH = Math.max(4, finTop - y0 - 1.2);
    var finY = y0 + 1.2 + finH / 2;
    var nf = clamp(Math.round(towerW / 4.0), 5, 12);
    for (i = 0; i <= nf; i++) {
      var fx = -towerW / 2 + i * towerW / nf;
      box(b, kit.get('trim'), 0.5, finH, 0.8, fx, finY, towerD / 2 + 0.12);
      box(b, kit.get('trim'), 0.5, finH, 0.8, fx, finY, -towerD / 2 - 0.12);
    }
    var ns = clamp(Math.round(towerD / 4.6), 4, 9);
    for (i = 0; i <= ns; i++) {
      var fz = -towerD / 2 + i * towerD / ns;
      box(b, kit.get('trim'), 0.8, finH, 0.5, towerW / 2 + 0.12, finY, fz);
      box(b, kit.get('trim'), 0.8, finH, 0.5, -towerW / 2 - 0.12, finY, fz);
    }
    // 四角粗肋
    var cH = finH + 2.4;
    var cY = y0 + 1.2 + cH / 2;
    for (i = 0; i < 4; i++) {
      var sx = (i % 2 ? 1 : -1), sz = (i < 2 ? 1 : -1);
      box(b, kit.get('trim'), 1.3, cH, 1.3, sx * (towerW / 2 + 0.15), cY, sz * (towerD / 2 + 0.15));
    }
    // 塔楼顶部出挑 + 构架
    box(b, kit.get('trim'), towerW + 4.2, 0.9, towerD + 4.2, 0, towerTop + 0.45, 0);
    box(b, kit.get('darkMetal'), towerW * 0.62, 2.6, towerD * 0.56, 0, towerTop + 1.2, 0);
    var postH = Math.max(1.2, crownH - 3.0);
    var postY = towerTop + 0.9 + postH / 2;
    var pxs = towerW / 2 + 1.4, pzs = towerD / 2 + 1.4;
    for (i = 0; i < 4; i++) {
      box(b, kit.get('metal'), 0.5, postH, 0.5, (i % 2 ? 1 : -1) * pxs, postY, (i < 2 ? 1 : -1) * pzs);
    }
    var beamY = postY + postH / 2 - 0.12;
    box(b, kit.get('metal'), pxs * 2, 0.34, 0.4, 0, beamY, pzs);
    box(b, kit.get('metal'), pxs * 2, 0.34, 0.4, 0, beamY, -pzs);
    box(b, kit.get('metal'), 0.4, 0.34, pzs * 2, pxs, beamY, 0);
    box(b, kit.get('metal'), 0.4, 0.34, pzs * 2, -pxs, beamY, 0);
    // 天线 + 航空障碍灯
    var antH = crownH * 0.6 + 2.2;
    cyl(b, kit.get('metal'), 0.1, 0.28, antH, 8, 0, towerTop + 0.9 + antH / 2, 0);
    sphereUp(b, kit.get('lamp'), 0.42, 0, towerTop + 0.9 + antH, 0, 8, 5);
    // 时钟
    var clockR = clamp(Math.min(towerW, towerD) * 0.085, 1.4, 3.0);
    var clockY = towerTop - clockR * 2.4;
    var clockZ = dir * (towerD / 2 + 1.0);
    b.add(kit.get('white'), new THREE.CircleGeometry(clockR, 24), 0, clockY, clockZ, 0, dir < 0 ? PI : 0, 0);
    boxR(b, kit.get('darkMetal'), 0.18, clockR * 0.62, 0.06, 0, clockY + clockR * 0.22, clockZ + dir * 0.05, 0, 0, 0.45);
    boxR(b, kit.get('darkMetal'), 0.16, clockR * 0.5, 0.06, clockR * 0.12, clockY + clockR * 0.06, clockZ + dir * 0.05, 0, 0, -1.2);

    // 裙房屋面采光带（丰富第五立面）
    if (w > 44) {
      box(b, kit.get('trim'), w * 0.2, 0.3, 2.0, -w * 0.16, podiumTop + 0.72, d * 0.26);
      box(b, kit.get('glassSoft'), w * 0.19, 0.45, 1.7, -w * 0.16, podiumTop + 0.9, d * 0.26);
      box(b, kit.get('trim'), w * 0.2, 0.3, 2.0, w * 0.16, podiumTop + 0.72, d * 0.26);
      box(b, kit.get('glassSoft'), w * 0.19, 0.45, 1.7, w * 0.16, podiumTop + 0.9, d * 0.26);
    }

    // 弧形玻璃中庭（主入口）
    var r = clamp(Math.min(d * 0.24, w * 0.15), 5, 16);
    var zc = dir * (d / 2 - r * 0.55);
    var atH = Math.max(6, Math.min(podiumH + 2.6, h * 0.34));
    var atBase = plinthH + 0.2;
    cyl(b, kit.get('stone'), r + 0.7, r + 0.7, atBase, 20, 0, atBase / 2, zc, false, -PI / 2, PI);
    cylUV(b, kit, 'glass', r, atH, 20, 0, atBase + atH / 2, zc, -PI / 2, PI, podiumFloors + 1);
    for (f = 1; f <= podiumFloors + 1; f++) {
      cyl(b, kit.get('trim'), r + 0.14, r + 0.14, 0.42, 20, 0, atBase + f * (atH / (podiumFloors + 1.6)), zc, true, -PI / 2, PI);
    }
    cyl(b, kit.get('trim'), r + 0.24, r + 0.24, 0.6, 20, 0, atBase + atH + 0.3, zc, false, -PI / 2, PI);
    // 中庭入口
    var atFront = zc + dir * r;
    box(b, kit.get('glassDoor'), r * 0.72, 4.4, 0.3, 0, atBase + 2.2, atFront + dir * 0.06);
    box(b, kit.get('trim'), r * 0.05, 4.6, 0.5, 0, atBase + 2.3, atFront + dir * 0.1);
    var canY = atBase + 5.2;
    box(b, kit.get('trim'), r * 1.25, 0.4, 2.6, 0, canY, atFront + dir * 1.1);
    box(b, kit.get('trim'), 0.4, 4.9, 0.4, r * 0.5, atBase + 2.45, atFront + dir * 1.9);
    box(b, kit.get('trim'), 0.4, 4.9, 0.4, -r * 0.5, atBase + 2.45, atFront + dir * 1.9);
    box(b, kit.get('lamp'), r * 0.4, 0.18, 0.3, 0, canY - 0.22, atFront + dir * 0.7);
    // 大台阶
    addSteps(b, kit, 'stone', Math.min(w * 0.5, r * 2.4), zc + dir * (r + 0.75), dir,
      Math.max(2, Math.round(atBase / 0.3)), 0.3, 0.95);
    // 裙房檐口灯带
    box(b, kit.get('lamp'), w * 0.9, 0.14, 0.2, 0, podiumTop + 0.05, dir * (d / 2 + 0.55));
    // 屋顶设备
    addRoofUnits(b, kit, rng, w * 0.4, d * 0.3, podiumTop + 0.35, 2, 2.4);
    // 塔楼名牌（悬挑于玻璃幕墙与遮阳肋之前）
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 2.6,
        bottom: podiumTop + 2.2,
        z: dir * (towerD / 2 + 0.76),
        dir: dir
      });
    }
  };

  /* ------------------------------ 教学大楼 ------------------------------ */
  STYLES.teaching = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors, fh = vol.fh;
    var variant = kit.variant % 3;
    var plinthH = 1.3;
    addPlinth(b, kit, w, d, plinthH, 1.5, 'base');
    var y0 = plinthH;
    var bodyH = Math.max(3, h - y0 - 1.2);
    var bodies;
    var i, f;

    if (variant === 1 && w >= 38) {
      // 双翼 + 中央玻璃连廊
      var gap = Math.max(4.5, w * 0.14);
      var wingW = (w - gap) / 2;
      var cx = (w - wingW) / 2;
      bodies = addMassing(b, kit, vol, [
        { w: wingW, d: d, h: bodyH, x: -cx, z: 0, corners: true, cornerSize: 1.25, mat: 'wall' },
        { w: wingW, d: d, h: bodyH, x: cx, z: 0, corners: true, cornerSize: 1.25, mat: 'wall2' }
      ], { y0: y0 });
      // 玻璃连廊
      facadeBox(b, kit, 'glass', gap + 0.8, bodyH * 0.94, d * 0.6, 0, y0 + bodyH * 0.47, 0, 0, floors);
      box(b, kit.get('trim'), gap + 1.4, 0.5, d * 0.6 + 0.5, 0, y0 + bodyH * 0.94 + 0.25, 0);
      for (f = 1; f < floors; f++) {
        box(b, kit.get('trim'), gap + 1.0, 0.16, d * 0.6 + 1.0, 0, y0 + f * fh, 0);
      }
    } else if (variant === 2 && w >= 30 && d >= 20) {
      // 前后错落：主楼 + 后翼
      var mainD = d * 0.66;
      var wingD = d - mainD;
      var wingW = Math.max(8, w * 0.36);
      bodies = addMassing(b, kit, vol, [
        { w: w, d: mainD, h: bodyH, x: 0, z: (d - mainD) / 2, corners: true, cornerSize: 1.15 },
        { w: wingW, d: wingD, h: bodyH * 0.9, x: -w * 0.22, z: -(mainD / 2), corners: true, cornerSize: 0.9, mat: 'wall2' }
      ], { y0: y0 });
    } else {
      // 单一体量 + 中央凸出玻璃楼梯间
      bodies = addMassing(b, kit, vol, [
        { w: w, d: d, h: bodyH, x: 0, z: 0, corners: true, cornerSize: 1.25 }
      ], { y0: y0 });
      var sw = clamp(w * 0.12, 4.5, 11);
      var sh = bodyH * 0.97;
      box(b, kit.get('glass'), sw, sh, 2.4, 0, y0 + sh / 2, d / 2 + 1.2);
      box(b, kit.get('trim'), sw + 0.8, 0.4, 3.0, 0, y0 + sh + 0.1, d / 2 + 1.2);
      box(b, kit.get('trim'), 0.4, sh, 0.5, -sw / 2, y0 + sh / 2, d / 2 + 2.4);
      box(b, kit.get('trim'), 0.4, sh, 0.5, sw / 2, y0 + sh / 2, d / 2 + 2.4);
      for (f = 1; f < floors; f++) {
        box(b, kit.get('trim'), sw + 0.3, 0.18, 0.6, 0, y0 + f * fh, d / 2 + 2.4);
      }
    }

    // 屋顶
    addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat' });
    var main = bodies[0];
    addRoofUnits(b, kit, rng, main.w * 0.45, main.d * 0.4, main.yTop + 0.35, 2, 2.0);
    if (variant !== 1 && rng() > 0.35) {
      addSolarPanels(b, kit, rng, main.w * 0.42, main.d * 0.4, main.yTop + 0.35);
    }
    // 入口 + 台阶 + 招牌
    var ent = addEntrance(b, kit, vol, {
      width: clamp(w * 0.16, 4.5, 12),
      depth: 2.8,
      height: Math.min(fh * 1.6, 6.4)
    });
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: clamp(h * 0.08, 1.3, 2.0),
        bottom: ent.topY + 0.9,
        z: ent.frontZ,
        dir: ent.dir,
        fascia: 'trim'
      });
    }
    // 雨棚灯
    box(b, kit.get('lamp'), ent.width * 0.5, 0.16, 0.24, 0, ent.topY - 0.28, ent.frontZ - ent.dir * 0.1);
  };

  /* ------------------------------ 实验大楼 ------------------------------ */
  STYLES.lab = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors, fh = vol.fh;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 1.0;
    addPlinth(b, kit, w, d, plinthH, 1.4, 'stone');
    var y0 = plinthH;
    var bodyH = Math.max(3, h - y0 - 1.4);
    var bodies = addMassing(b, kit, vol, [
      { w: w, d: d, h: bodyH, x: 0, z: 0, corners: true, cornerSize: 1.0, bandEvery: 2, bandMat: 'accent' }
    ], { y0: y0 });
    var main = bodies[0];
    var i, f;

    // 端部玻璃楼梯间（凸出屋面一点）
    var stW = clamp(w * 0.14, 4, 10);
    var stH = Math.max(5, Math.min(bodyH + 1.4, h));
    var stD = d * 0.5;
    var stX = -w / 2 + stW / 2 + 1.0;
    box(b, kit.get('glass'), stW, stH, stD, stX, y0 + stH / 2, d / 2 + stD / 2 - 1.6);
    box(b, kit.get('trim'), stW + 0.8, 0.4, stD + 0.6, stX, y0 + stH + 0.15, d / 2 + stD / 2 - 1.6);
    box(b, kit.get('trim'), 0.45, stH, 0.5, stX - stW / 2, y0 + stH / 2, d / 2 + stD - 1.45);
    box(b, kit.get('trim'), 0.45, stH, 0.5, stX + stW / 2, y0 + stH / 2, d / 2 + stD - 1.45);
    for (f = 1; f < floors + 2; f++) {
      var sy = y0 + f * fh;
      if (sy > y0 + stH - 0.4) { break; }
      box(b, kit.get('trim'), stW + 0.25, 0.18, 0.5, stX, sy, d / 2 + stD - 1.45);
    }

    // 屋顶：平屋面 + 机房 + 排风设备
    addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat', parapetH: 0.75 });
    box(b, kit.get('wall2'), Math.min(main.w * 0.3, 16), 2.8, Math.min(main.d * 0.45, 12), -main.w * 0.16, main.yTop + 1.75, 0);
    box(b, kit.get('trim'), Math.min(main.w * 0.3, 16) + 0.6, 0.3, Math.min(main.d * 0.45, 12) + 0.6, -main.w * 0.16, main.yTop + 3.3, 0);
    var vents = 3;
    for (i = 0; i < vents; i++) {
      addVent(b, kit, 0.55, 1.8 + rng() * 1.2, main.w * (0.12 + i * 0.16), main.yTop + 0.35, main.d * 0.18);
    }
    addChimney(b, kit, Math.max(0.5, main.w * 0.014), Math.max(3.4, h * 0.14), main.w * 0.34, main.yTop + 0.3, -main.d * 0.12);
    // 屋顶冷却机组
    addRoofUnits(b, kit, rng, main.w * 0.4, main.d * 0.4, main.yTop + 0.35, 3, 2.6);

    // 立面：外挂管道 + 空调百叶
    for (i = 0; i < 3; i++) {
      var px = -w * 0.3 + i * w * 0.12;
      box(b, kit.get('metal'), 0.45, bodyH * 0.82, 0.45, px, y0 + bodyH * 0.41, d / 2 + 0.3);
      box(b, kit.get('darkMetal'), 0.7, 0.5, 0.7, px, y0 + bodyH * 0.6, d / 2 + 0.3);
    }
    for (f = 1; f < floors; f++) {
      if (f % 2 !== 0) { continue; }
      box(b, kit.get('darkMetal'), w * 0.16, 0.7, 0.35, w * 0.24, y0 + f * fh - 0.6, d / 2 + 0.15);
      box(b, kit.get('darkMetal'), w * 0.16, 0.7, 0.35, -w * 0.24, y0 + f * fh - 0.6, d / 2 + 0.15);
    }
    // 入口与招牌
    var ent = addEntrance(b, kit, vol, {
      width: clamp(w * 0.18, 5, 12),
      depth: 2.4,
      height: Math.min(fh * 1.5, 6.0),
      mat: 'accent'
    });
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: clamp(h * 0.08, 1.4, 2.1),
        bottom: ent.topY + 0.9,
        z: ent.frontZ,
        dir: ent.dir,
        fascia: 'trim'
      });
    }
  };

  /* ------------------------------ 学生宿舍 ------------------------------ */
  STYLES.dorm = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors, fh = vol.fh;
    var plinthH = 0.8;
    addPlinth(b, kit, w, d, plinthH, 1.0, 'stone');
    var y0 = plinthH;
    var bodyH = Math.max(3, h - y0 - 1.1);
    var bodies = addMassing(b, kit, vol, [
      { w: w, d: d, h: bodyH, x: 0, z: 0, corners: false, bands: false }
    ], { y0: y0 });
    var main = bodies[0];
    var i, f;

    // 阳台做法随 seed 变化：0=独立阳台 1=连续阳台带 2=错位独立阳台
    var bays = clamp(Math.round(w / 5.2), 3, 7);
    var bw = w / bays;
    var balconyStyle = (kit.variant + (Math.round(toNum(vol.seed, 1)) % 3)) % 3;

    if (balconyStyle === 1) {
      // 连续阳台带
      for (f = 1; f < floors; f++) {
        var cy = y0 + f * fh + 0.05;
        var cw = w * (0.86 - (f % 2) * 0.05);
        box(b, kit.get('trim'), cw, 0.22, 1.4, 0, cy, d / 2 + 0.62);
        box(b, kit.get('rail'), cw - 0.3, 1.0, 0.07, 0, cy + 0.61, d / 2 + 1.25);
        box(b, kit.get('metal'), cw, 0.07, 0.12, 0, cy + 1.13, d / 2 + 1.25);
        for (i = 1; i < 6; i++) {
          box(b, kit.get('trimWarm'), 0.1, 1.1, 1.1, -cw / 2 + (i * cw) / 6, cy + 0.66, d / 2 + 0.72);
        }
        if (f % 2 === 0) {
          box(b, kit.get('metal'), 0.75, 0.6, 0.45, -cw / 2 + 1.1, cy + 0.55, d / 2 + 0.36);
          box(b, kit.get('metal'), 0.75, 0.6, 0.45, cw / 2 - 1.1, cy + 0.55, d / 2 + 0.36);
        }
      }
    } else {
      // 独立阳台（variant 2 时错位）
      var stagger = (balconyStyle === 2);
      var balconyW = Math.min(bw * 0.76, 3.4);
      for (f = 1; f < floors; f++) {
        var by = y0 + f * fh + 0.05;
        for (i = 0; i < bays; i++) {
          if (stagger && ((i + f) % 2 !== 0)) { continue; }
          var bx = -w / 2 + (i + 0.5) * bw;
          if (f === 1 && Math.abs(bx) < bw * 1.1) { continue; }
          addBalcony(b, kit, balconyW, bx, by, d / 2 + 0.6, { min: true, ac: ((i + f) % 3 === 0) });
        }
      }
    }
    // 背面空调机位
    for (f = 1; f < floors; f += 2) {
      for (i = 0; i < bays; i += 3) {
        var bxx = -w / 2 + (i + 0.5) * bw;
        box(b, kit.get('metal'), 0.75, 0.6, 0.45, bxx, y0 + f * fh + 0.55, -d / 2 - 0.28);
      }
    }
    // 立面竖向白色分隔（开间线）
    for (i = 1; i < bays; i += 2) {
      var vx = -w / 2 + i * bw;
      box(b, kit.get('trimWarm'), 0.18, bodyH, 0.14, vx, y0 + bodyH / 2, d / 2 + 0.1);
    }
    // 屋顶：楼梯间 + 水箱 + 晾衣架 + 设备
    addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat' });
    var stairW = clamp(w * 0.14, 4, 8);
    box(b, kit.get('wall2'), stairW, 2.8, d * 0.5, -w / 2 + stairW / 2 + 0.8, main.yTop + 1.75, 0);
    box(b, kit.get('trim'), stairW + 0.5, 0.3, d * 0.5 + 0.5, -w / 2 + stairW / 2 + 0.8, main.yTop + 3.28, 0);
    addWaterTank(b, kit, Math.min(main.w * 0.045, 2.2), 2.4, main.w * 0.26, main.yTop + 0.3, -main.d * 0.12);
    addDryingRack(b, kit, main.w * 0.3, -main.w * 0.12, main.yTop + 0.35, main.d * 0.12);
    addRoofUnits(b, kit, rng, main.w * 0.3, main.d * 0.3, main.yTop + 0.35, 2, 1.8);
    // 入口 + 雨棚 + 招牌
    var ent = addEntrance(b, kit, vol, {
      width: clamp(bw * 1.4, 4.2, 8),
      depth: 2.2,
      height: Math.min(fh * 1.5, 5.0)
    });
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: clamp(h * 0.075, 1.3, 1.8),
        bottom: ent.topY + 0.85,
        z: ent.frontZ,
        dir: ent.dir,
        fascia: 'trim'
      });
    }
  };

  /** 将 floors 拆成 n 段（尽量平均） */
  function splitFloors(floors, n) {
    var out = [];
    var base = Math.floor(floors / n);
    var rem = floors % n;
    for (var i = 0; i < n; i++) {
      out.push(Math.max(1, base + (i < rem ? 1 : 0)));
    }
    return out;
  }

  /* ------------------------------ 体育馆 ------------------------------ */
  STYLES.gym = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 1.0;
    addPlinth(b, kit, w, d, plinthH + 0.4, 2.2, 'stone');
    var wallH = Math.max(4, h * 0.48);
    var r = d * 0.5;
    var k = clamp((h - 0.3 - (plinthH + 0.4) - wallH) / r, 0.3, 1.12);
    var baseY = plinthH + 0.4;
    var bodyW = w * 0.94, bodyD = d * 0.94;
    var mullN, i;

    // 侧墙玻璃幕墙
    facadeBox(b, kit, 'glass', bodyW, wallH, bodyD, 0, baseY + wallH / 2, 0, 0, Math.max(2, Math.round(wallH / 4)));
    // 两端山墙
    box(b, kit.get('wall2'), 0.7, wallH, bodyD, bodyW / 2 - 0.35, baseY + wallH / 2, 0);
    box(b, kit.get('wall2'), 0.7, wallH, bodyD, -bodyW / 2 + 0.35, baseY + wallH / 2, 0);
    // 幕墙竖梃
    mullN = clamp(Math.round(w / 3.6), 8, 22);
    for (i = 0; i <= mullN; i++) {
      var mx = -bodyW / 2 + (i * bodyW) / mullN;
      box(b, kit.get('trim'), 0.2, wallH, 0.28, mx, baseY + wallH / 2, bodyD / 2 + 0.12);
      box(b, kit.get('trim'), 0.2, wallH, 0.28, mx, baseY + wallH / 2, -bodyD / 2 - 0.12);
    }
    for (i = 0; i <= 3; i++) {
      var mz = -bodyD / 2 + (i * bodyD) / 3;
      box(b, kit.get('trim'), 0.28, wallH, 0.2, bodyW / 2 + 0.12, baseY + wallH / 2, mz);
      box(b, kit.get('trim'), 0.28, wallH, 0.2, -bodyW / 2 - 0.12, baseY + wallH / 2, mz);
    }
    // 水平腰线
    box(b, kit.get('accent'), bodyW + 0.5, 0.55, bodyD + 0.5, 0, baseY + wallH * 0.62, 0);
    // 拱形屋面 + 拱肋 + 半圆山墙
    addBarrelRoof(b, kit, r, bodyW, baseY + wallH, k, {
      ribs: clamp(Math.round(w / 9), 3, 9),
      mat: 'roofMetal',
      ribMat: 'trim',
      capMat: 'trimWarm',
      seg: 18
    });

    // 主入口：大玻璃门厅（凸出于幕墙）
    var pw = clamp(w * 0.3, 9, 22);
    var ph = Math.min(wallH * 0.82, 10);
    var frontZ = bodyD / 2 + 3.4;
    box(b, kit.get('accent'), pw + 1.4, ph + 0.9, 4.2, 0, baseY + (ph + 0.9) / 2, dir * (frontZ - 2.1));
    box(b, kit.get('glassDoor'), pw, ph, 0.25, 0, baseY + ph / 2, dir * (frontZ + 0.02));
    // 雨棚
    box(b, kit.get('trim'), pw + 2.0, 0.5, 5.0, 0, baseY + ph + 0.55, dir * (frontZ - 1.0));
    // 雨棚柱
    box(b, kit.get('trim'), 0.55, ph, 0.55, pw / 2 + 0.9, baseY + ph / 2, dir * (frontZ + 0.9));
    box(b, kit.get('trim'), 0.55, ph, 0.55, -pw / 2 - 0.9, baseY + ph / 2, dir * (frontZ + 0.9));
    // 门厅台阶
    addSteps(b, kit, 'stone', pw + 2.4, dir * (frontZ + 0.4), dir, 3, 0.22, 0.9);
    // 入口雨棚灯
    box(b, kit.get('lamp'), pw * 0.6, 0.16, 0.3, 0, baseY + ph + 0.24, dir * (frontZ - 0.3));
    // 招牌
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 1.8,
        bottom: baseY + ph + 1.0,
        z: dir * frontZ,
        dir: dir,
        fascia: 'trim'
      });
    }
    // 屋顶通风器
    addVent(b, kit, 0.9, 1.6, bodyW * 0.2, baseY + wallH + r * k * 0.55, 0);
    addVent(b, kit, 0.9, 1.6, -bodyW * 0.2, baseY + wallH + r * k * 0.55, 0);
  };

  /* ------------------------------ 食堂 ------------------------------ */
  STYLES.canteen = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors, fh = vol.fh;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 0.9;
    addPlinth(b, kit, w, d, plinthH, 1.6, 'stone');
    var y0 = plinthH;
    var bodyH = Math.max(3, h - y0 - 1.1);
    var bodies = addMassing(b, kit, vol, [
      { w: w, d: d, h: bodyH, x: 0, z: 0, corners: true, cornerSize: 1.4, cornerMat: 'trimWarm', cornerMat2: 'trimWarm' }
    ], { y0: y0 });
    var main = bodies[0];
    var i, f;

    // 暖色水平装饰带
    for (f = 1; f < floors; f++) {
      box(b, kit.get('accent'), w + 0.7, 0.4, d + 0.7, 0, y0 + f * fh, 0);
    }
    // 屋顶：平台 + 采光天窗 + 烟道
    addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat', parapetH: 1.0 });
    var skyW = Math.min(w * 0.34, 14), skyD = Math.min(d * 0.24, 8);
    box(b, kit.get('glass'), skyW, 0.6, skyD, -w * 0.16, main.yTop + 0.85, 0);
    box(b, kit.get('trim'), skyW + 0.8, 0.3, skyD + 0.8, -w * 0.16, main.yTop + 0.5, 0);
    addChimney(b, kit, Math.max(0.6, w * 0.014), Math.max(4, h * 0.4), w * 0.3, main.yTop + 0.3, -d * 0.18);
    addChimney(b, kit, Math.max(0.5, w * 0.011), Math.max(3.4, h * 0.32), w * 0.18, main.yTop + 0.3, -d * 0.24);
    addRoofUnits(b, kit, rng, main.w * 0.3, main.d * 0.3, main.yTop + 0.35, 2, 1.8);
    // 沿街玻璃雨棚 + 斜撑
    var awY = y0 + fh * 1.02;
    var awW = w * 0.84;
    box(b, kit.get('glassSoft'), awW, 0.16, 2.2, 0, awY, dir * (d / 2 + 1.15));
    box(b, kit.get('darkMetal'), awW, 0.1, 0.14, 0, awY + 0.06, dir * (d / 2 + 2.2));
    for (i = 0; i < 5; i++) {
      var ax = -awW / 2 + awW * (i + 0.5) / 5;
      boxR(b, kit.get('metal'), 0.12, 2.34, 0.12, ax, awY - 0.6, dir * (d / 2 + 1.0), dir * 1.03, 0, 0);
    }
    // 入口
    var ent = addEntrance(b, kit, vol, {
      width: clamp(w * 0.24, 7, 18),
      depth: 3.2,
      height: Math.min(fh * 1.5, 6.6)
    });
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: clamp(h * 0.075, 1.2, 1.7),
        bottom: ent.topY + 0.9,
        z: ent.frontZ,
        dir: ent.dir,
        fascia: 'trim'
      });
    }
  };

  /* ------------------------------ 多功能厅 ------------------------------ */
  STYLES.hall = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var r = Math.min(w, d) * 0.5 * 0.94;
    var plinthH = 1.1;
    var domeH = clamp(h * 0.34, 3.2, 12);
    var bodyH = Math.max(3, h - plinthH - domeH - domeH * 0.34 - 0.6);
    var y0 = plinthH;
    var i;

    // 圆形台基（三级）
    cyl(b, kit.get('stone'), r + 3.2, r + 3.4, 0.4, 24, 0, 0.2, 0);
    cyl(b, kit.get('stone'), r + 2.3, r + 2.5, 0.4, 24, 0, 0.6, 0);
    cyl(b, kit.get('stone'), r + 1.5, r + 1.7, 0.35, 24, 0, 0.98, 0);
    // 环形玻璃体
    cylUV(b, kit, 'glass', r, bodyH, 24, 0, y0 + bodyH / 2, 0, 0, PI * 2, Math.max(2, Math.round(bodyH / 4)));
    // 环向玻璃带 + 上下白环
    var bandY = y0 + bodyH * 0.6;
    cyl(b, kit.get('glassSoft'), r + 0.16, r + 0.16, 3.0, 24, 0, bandY, 0);
    cyl(b, kit.get('trim'), r + 0.3, r + 0.3, 0.32, 24, 0, bandY + 1.55, 0);
    cyl(b, kit.get('trim'), r + 0.3, r + 0.3, 0.32, 24, 0, bandY - 1.55, 0);
    // 顶部檐口环
    cyl(b, kit.get('trim'), r + 0.5, r + 0.5, 0.6, 24, 0, y0 + bodyH + 0.28, 0);
    // 金属穹顶
    addDome(b, kit, r * 1.02, y0 + bodyH + 0.55, { h: domeH, mat: 'roofMetal' });
    // 环向柱廊
    var cols = 10;
    for (i = 0; i < cols; i++) {
      var ang = (i / cols) * PI * 2;
      var px = Math.sin(ang) * (r + 0.95);
      var pz = Math.cos(ang) * (r + 0.95);
      if (pz * dir > r * 0.62) { continue; }
      box(b, kit.get('trimWarm'), 0.95, bodyH * 0.94, 0.95, px, y0 + bodyH * 0.47, pz);
      box(b, kit.get('trim'), 1.35, 0.3, 1.35, px, y0 + bodyH * 0.94, pz);
    }
    // 门厅
    var pw = clamp(r * 1.15, 6, 16);
    var ph = Math.min(bodyH * 0.6, 7.2);
    var pz0 = dir * (r + 1.5);
    box(b, kit.get('accent'), pw, ph, 4.2, 0, y0 + ph / 2, pz0);
    box(b, kit.get('glassDoor'), pw * 0.72, ph * 0.8, 0.3, 0, y0 + ph * 0.4, pz0 + dir * 2.15);
    box(b, kit.get('trim'), pw + 1.4, 0.42, 5.2, 0, y0 + ph + 0.26, pz0);
    box(b, kit.get('trim'), 0.5, ph, 0.5, pw / 2 + 0.6, y0 + ph / 2, pz0 + dir * 2.2);
    box(b, kit.get('trim'), 0.5, ph, 0.5, -pw / 2 - 0.6, y0 + ph / 2, pz0 + dir * 2.2);
    addSteps(b, kit, 'stone', pw + 1.8, dir * (r + 3.0), dir, 3, 0.25, 0.85);
    box(b, kit.get('lamp'), pw * 0.5, 0.16, 0.3, 0, y0 + ph + 0.05, pz0 + dir * 1.8);
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 1.8,
        bottom: y0 + ph + 0.85,
        z: pz0 + dir * 2.15,
        dir: dir,
        fascia: 'trim'
      });
    }
  };

  /* ------------------------------ 学术交流中心 ------------------------------ */
  STYLES.exchange = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 1.0;
    addPlinth(b, kit, w, d, plinthH, 2.2, 'stone');
    var y0 = plinthH;
    var segs = 3;
    var fCounts = splitFloors(floors, segs);
    var fhA = Math.max(2.2, (h - y0 - 1.2) / floors);
    var volA = extend({}, vol);
    volA.fh = fhA;
    var y = y0;
    var bodies = [];
    var i, f;

    for (i = 0; i < segs; i++) {
      var hh = fCounts[i] * fhA;
      if (hh <= 0.5) { continue; }
      var sw = w * (1 - i * 0.16);
      var sd = d * (1 - i * 0.14);
      var ox = (i === 1 ? -w * 0.05 : (i === 2 ? w * 0.02 : 0));
      var oz = (i === 1 ? -d * 0.03 : (i === 2 ? d * 0.04 : 0));
      var seg = addMassing(b, kit, volA, [
        {
          w: sw, d: sd, h: hh, x: ox, z: oz,
          corners: true, cornerSize: i === 0 ? 1.25 : 0.8,
          mat: (i === 1 ? 'wall2' : 'wall')
        }
      ], { y0: y });
      bodies = bodies.concat(seg);
      y += hh;
    }

    // 退台露台：屋面 + 栏杆 + 花池
    for (i = 1; i < bodies.length; i++) {
      var prev = bodies[i - 1];
      var ty = y0;
      for (var j = 0; j < i; j++) { ty += bodies[j].h; }
      addRoofDeck(b, kit, prev.w - 0.3, prev.d - 0.3, prev.yTop);
      var railW = prev.w - 0.6;
      var railZ = prev.z + prev.d / 2 - 0.32;
      box(b, kit.get('rail'), railW, 1.0, 0.08, prev.x, ty + 0.52, railZ);
      box(b, kit.get('metal'), railW, 0.07, 0.12, prev.x, ty + 1.04, railZ);
      box(b, kit.get('rail'), 0.08, 1.0, prev.d - 0.7, prev.x + prev.w / 2 - 0.32, ty + 0.52, prev.z);
      box(b, kit.get('metal'), 0.12, 0.07, prev.d - 0.7, prev.x + prev.w / 2 - 0.32, ty + 1.04, prev.z);
      box(b, kit.get('rail'), 0.08, 1.0, prev.d - 0.7, prev.x - prev.w / 2 + 0.32, ty + 0.52, prev.z);
      box(b, kit.get('metal'), 0.12, 0.07, prev.d - 0.7, prev.x - prev.w / 2 + 0.32, ty + 1.04, prev.z);
      box(b, kit.get('green'), Math.min(3.2, prev.w * 0.2), 0.55, 1.1, prev.x - prev.w * 0.28, ty + 0.3, railZ - 0.65);
      box(b, kit.get('green'), Math.min(3.2, prev.w * 0.2), 0.55, 1.1, prev.x + prev.w * 0.28, ty + 0.3, railZ - 0.65);
      box(b, kit.get('trim'), Math.min(3.3, prev.w * 0.21), 0.2, 1.2, prev.x - prev.w * 0.28, ty + 0.1, railZ - 0.65);
      box(b, kit.get('trim'), Math.min(3.3, prev.w * 0.21), 0.2, 1.2, prev.x + prev.w * 0.28, ty + 0.1, railZ - 0.65);
    }

    // 顶部：屋面 + 构架 + 天线
    var top = bodies[bodies.length - 1];
    addFlatRoof(b, kit, vol, top.w, top.d, top.yTop, { parapetH: 0.9 });
    var postH = clamp(h * 0.05, 1.0, 2.2);
    var px = top.w / 2 - 0.5, pzz = top.d / 2 - 0.5;
    var posts = [[px, pzz], [-px, pzz], [px, -pzz], [-px, -pzz]];
    for (i = 0; i < 4; i++) {
      box(b, kit.get('metal'), 0.4, postH, 0.4, top.x + posts[i][0], top.yTop + 0.9 + postH / 2, top.z + posts[i][1]);
    }
    box(b, kit.get('metal'), px * 2, 0.3, 0.35, top.x, top.yTop + 0.9 + postH, top.z + pzz);
    box(b, kit.get('metal'), px * 2, 0.3, 0.35, top.x, top.yTop + 0.9 + postH, top.z - pzz);
    box(b, kit.get('metal'), 0.35, 0.3, pzz * 2, top.x + px, top.yTop + 0.9 + postH, top.z);
    box(b, kit.get('metal'), 0.35, 0.3, pzz * 2, top.x - px, top.yTop + 0.9 + postH, top.z);
    cyl(b, kit.get('metal'), 0.08, 0.2, 1.1, 8, top.x, top.yTop + 1.05 + postH, top.z);
    addRoofUnits(b, kit, rng, top.w * 0.4, top.d * 0.4, top.yTop + 0.35, 2, 1.8);

    // 底层弧形玻璃（入口侧转角）
    var cr = clamp(Math.min(d * 0.3, w * 0.16), 3.5, 9);
    var cz = dir * (d / 2 - cr * 0.3);
    var cx0 = -w * 0.28;
    var cH = Math.min(fhA * 2.6, 10);
    var tStart = dir > 0 ? -PI / 2 : PI / 2;
    cylUV(b, kit, 'glass', cr, cH, 18, cx0, cH / 2 + 0.2, cz, tStart, PI, 3);
    cyl(b, kit.get('glassDoor'), cr + 0.08, cr + 0.08, 0.35, 18, cx0, cH + 0.3, cz, false, tStart, PI);
    cyl(b, kit.get('trim'), cr + 0.16, cr + 0.16, 0.3, 18, cx0, cH + 0.02, cz, true, tStart, PI);

    // 立面竖向装饰肋
    var ribN = clamp(Math.round(w / 7), 4, 8);
    for (i = 0; i <= ribN; i++) {
      var rx = -w / 2 + (i * w) / ribN;
      box(b, kit.get('accent'), 0.4, bodies[0].h * 0.92, 0.35, rx, y0 + bodies[0].h * 0.46, dir * (d / 2 + 0.1));
    }

    // 入口 + 招牌
    var ent = addEntrance(b, kit, vol, {
      width: clamp(w * 0.2, 6, 14),
      depth: 3.0,
      height: Math.min(fhA * 1.7, 6.4)
    });
    addSteps(b, kit, 'stone', ent.width + 3.0, dir * (d / 2 + 0.3), dir, 2, 0.22, 0.8);
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 1.9,
        bottom: ent.topY + 0.9,
        z: ent.frontZ,
        dir: ent.dir,
        fascia: 'trim'
      });
    }
  };

  /* ------------------------------ 教师公寓 ------------------------------ */
  STYLES.apartment = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h, floors = vol.floors, fh = vol.fh;
    var roofType = vol.roof || 'pitch';
    var plinthH = 0.7;
    var pitchRise = (roofType === 'pitch') ? Math.max(1.3, Math.min(2.6, d * 0.32)) : 0;
    var bodyH = Math.max(2.6, h - plinthH - (roofType === 'pitch' ? pitchRise + 0.35 : 1.1));
    addPlinth(b, kit, w, d, plinthH, 1.0, 'stone');
    var y0 = plinthH;
    var bodies = addMassing(b, kit, vol, [
      { w: w, d: d, h: bodyH, x: 0, z: 0, corners: true, cornerSize: 0.95, cornerMat: 'trimWarm', bands: false }
    ], { y0: y0 });
    var main = bodies[0];
    var bays = clamp(Math.round(w / 3.8), 2, 6);
    var bw = w / bays;
    var phase = (kit.variant + Math.round(toNum(vol.seed, 1))) % 2;
    var i, f;

    // 端部楼梯间（部分变体）
    if (kit.variant !== 2 && w >= 28) {
      var stW = Math.min(4.0, w * 0.15);
      var stX = -w / 2 + stW / 2 + 0.7;
      box(b, kit.get('wall2'), stW, bodyH * 0.97, 3.0, stX, y0 + bodyH * 0.485, d / 2 + 0.85);
      box(b, kit.get('trimWarm'), stW + 0.6, 0.3, 3.5, stX, y0 + bodyH * 0.97, d / 2 + 0.85);
      for (f = 1; f < floors; f++) {
        box(b, kit.get('trimWarm'), stW + 0.2, 0.18, 0.5, stX, y0 + f * fh, d / 2 + 2.35);
      }
    }

    // 错落阳台（奇偶层左右交错，seed 决定相位）
    for (f = 1; f < floors; f++) {
      var by = y0 + f * fh + 0.05;
      for (i = 0; i < bays; i++) {
        if ((i + phase) % 2 !== f % 2) { continue; }
        var bx = -w / 2 + (i + 0.5) * bw;
        addBalcony(b, kit, Math.min(bw * 0.62, 2.6), bx, by, d / 2 + 0.55, { ac: false });
      }
    }
    // 空调机位（避开阳台开间）
    for (f = 2; f < floors; f += 2) {
      for (i = 0; i < bays; i++) {
        if ((i + phase) % 2 === f % 2) { continue; }
        var ax = -w / 2 + (i + 0.5) * bw;
        box(b, kit.get('metal'), 0.7, 0.55, 0.4, ax, y0 + f * fh - 0.5, d / 2 + 0.2);
      }
    }
    // 屋顶
    if (roofType === 'pitch') {
      addPitchRoof(b, kit, vol, w, d, main.yTop, { rise: pitchRise, over: 0.9, mat: 'roof', ridgeMat: 'trimWarm' });
      addChimney(b, kit, 0.45, 1.8, w * 0.24, main.yTop + pitchRise * 0.55, -d * 0.1);
      addChimney(b, kit, 0.4, 1.5, -w * 0.2, main.yTop + pitchRise * 0.55, -d * 0.16);
    } else {
      addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat' });
      addRoofUnits(b, kit, rng, main.w * 0.4, main.d * 0.3, main.yTop + 0.35, 2, 1.5);
    }
    // 入口 + 台阶 + 招牌
    var ent = addEntrance(b, kit, vol, {
      width: clamp(bw * 1.2, 4, 8),
      depth: 2.2,
      height: Math.min(fh * 1.5, 4.8),
      mat: 'accent'
    });
    addSteps(b, kit, 'stone', ent.width + 1.8, d / 2 + 0.2, ent.dir, 2, 0.16, 0.65);
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 1.25,
        bottom: ent.topY + 0.8,
        z: ent.frontZ,
        dir: ent.dir,
        fascia: 'trim'
      });
    }
  };

  /* ------------------------------ 锅炉房 / 浴室 ------------------------------ */
  STYLES.utility = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 0.6;
    addPlinth(b, kit, w, d, plinthH, 1.4, 'stone');
    var y0 = plinthH;
    var bodyH = Math.max(2.8, h - y0 - 0.9);
    var bodies = addMassing(b, kit, vol, [
      { w: w, d: d, h: bodyH, x: 0, z: 0, corners: false, bandEvery: 2, bandMat: 'darkMetal' }
    ], { y0: y0 });
    var main = bodies[0];
    var i;

    addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat', parapetH: 0.65, thick: 0.3 });
    // 大卷帘门
    var doorW = clamp(w * 0.4, 3.6, 12), doorH = Math.min(bodyH * 0.62, 5.2);
    box(b, kit.get('darkMetal'), doorW, doorH, 0.22, -w * 0.18, y0 + doorH / 2, d / 2 + 0.14);
    for (i = 1; i <= 5; i++) {
      box(b, kit.get('metal'), doorW - 0.2, 0.1, 0.28, -w * 0.18, y0 + (doorH * i) / 6, d / 2 + 0.2);
    }
    box(b, kit.get('accent'), doorW + 1.4, 0.35, 2.2, -w * 0.18, y0 + doorH + 0.4, d / 2 + 0.9);
    // 小门
    box(b, kit.get('glassDoor'), 1.4, 2.4, 0.16, w * 0.24, y0 + 1.2, d / 2 + 0.1);
    box(b, kit.get('accent'), 2.0, 0.22, 1.2, w * 0.24, y0 + 2.6, d / 2 + 0.5);
    // 大烟囱
    addChimney(b, kit, Math.max(0.7, Math.min(w * 0.03, 1.6)), Math.max(6, h * 0.9), -w * 0.3, 0, -d * 0.22);
    // 外露管线（只在右侧墙面，避免遮挡门洞）
    for (i = 0; i < 3; i++) {
      var px = w * 0.3 + i * Math.max(0.9, w * 0.05);
      box(b, kit.get('metal'), 0.3, bodyH * 0.86, 0.3, px, y0 + bodyH * 0.43, d / 2 + 0.32);
      box(b, kit.get('darkMetal'), 0.5, 0.25, 0.5, px, y0 + bodyH * 0.7, d / 2 + 0.32);
    }
    box(b, kit.get('metal'), w * 0.16, 0.24, 0.24, w * 0.36, y0 + bodyH * 0.3, d / 2 + 0.32);
    // 屋顶设备 + 通风器
    addRoofUnits(b, kit, rng, main.w * 0.5, main.d * 0.5, main.yTop + 0.3, 3, 2.2);
    addVent(b, kit, 0.5, 1.5, w * 0.28, main.yTop + 0.3, d * 0.2);
    // 招牌
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 1.1,
        bottom: y0 + Math.min(bodyH * 0.62, 5.8) + 0.7,
        z: dir * (d / 2 + 0.16),
        dir: dir
      });
    }
  };

  /* ------------------------------ 门卫 / 小亭 ------------------------------ */
  STYLES.pavilion = function (b, kit, vol, opts, rng) {
    var w = vol.w, d = vol.d, h = vol.h;
    var dir = vol.entrance === 'north' ? -1 : 1;
    var plinthH = 0.35;
    var pitchRise = clamp(h * 0.26, 1.0, 1.9);
    var bodyH = Math.max(2.2, h - plinthH - pitchRise - 0.15);
    addPlinth(b, kit, w, d, plinthH, 0.9, 'stone');
    var y0 = plinthH;
    var bodies = addMassing(b, kit, vol, [
      { w: w, d: d, h: bodyH, x: 0, z: 0, corners: true, cornerSize: 0.55, cornerMat: 'trimWarm', bands: false }
    ], { y0: y0 });
    var main = bodies[0];
    var s;
    // 门
    var dw = clamp(w * 0.3, 1.2, 3.0);
    var dh = Math.min(bodyH * 0.75, 2.5);
    box(b, kit.get('trim'), dw + 0.3, dh + 0.2, 0.1, 0, y0 + dh / 2 + 0.05, dir * (d / 2 + 0.1));
    box(b, kit.get('glassDoor'), dw, dh, 0.12, 0, y0 + dh / 2, dir * (d / 2 + 0.16));
    // 窗（白框 + 深色玻璃，做出真实窗洞层次）
    var winY = y0 + bodyH * 0.56;
    for (s = -1; s <= 1; s += 2) {
      var wx = s * w * 0.29;
      box(b, kit.get('trim'), 1.5, 1.2, 0.1, wx, winY, dir * (d / 2 + 0.06));
      box(b, kit.get('glassDoor'), 1.26, 0.98, 0.1, wx, winY, dir * (d / 2 + 0.13));
      box(b, kit.get('trim'), 0.1, 0.98, 0.12, wx, winY, dir * (d / 2 + 0.17));
    }
    // 侧窗
    box(b, kit.get('trim'), 0.1, 1.2, 1.5, w / 2 + 0.04, winY, 0);
    box(b, kit.get('glassDoor'), 0.1, 0.98, 1.26, w / 2 + 0.1, winY, 0);
    // 窗台/花池
    box(b, kit.get('trim'), w * 0.7, 0.35, 0.9, 0, y0 + 0.2, dir * (d / 2 + 0.55));
    box(b, kit.get('green'), w * 0.5, 0.3, 0.5, 0, y0 + 0.45, dir * (d / 2 + 0.55));
    // 入口台阶
    addSteps(b, kit, 'stone', dw + 2.0, dir * (d / 2 + 0.5), dir, 1, 0.16, 0.5);
    // 坡屋顶
    if ((vol.roof || 'pitch') === 'pitch') {
      addPitchRoof(b, kit, vol, w, d, main.yTop, {
        rise: pitchRise,
        over: 0.75,
        mat: 'roof',
        ridgeMat: 'trimWarm',
        gableMat: 'trimWarm'
      });
    } else {
      addMassRoofs(b, kit, vol, bodies, { defaultType: 'flat' });
    }
    // 招牌（小牌匾，挂在门上方）
    if (!opts.part) {
      addSign(b, kit, vol, {
        height: 0.5,
        width: 2.0,
        bottom: y0 + dh + 0.12,
        z: dir * (d / 2 + 0.14),
        dir: dir
      });
    }
  };

  /* ======================================================================
   * 8. spec 解析 / create / 夜景 / dispose / 导出
   * ==================================================================== */
  var _suppressEntrance = false;   // parts 体量不生成主入口
  var _suppressSign = false;       // parts 体量不生成名牌

  function themeVariantFor(id, style, seed) {
    return hash32(String(id) + '|' + style + '|' + String(seed)) % 3;
  }

  /** 规范化主 spec */
  function normalizeSpec(raw) {
    raw = raw || {};
    var style = normalizeStyle(raw.style);
    var def = STYLE_DEFS[style] || STYLE_DEFS.teaching;
    var h = toNum(raw.h, 0);
    var floors;
    if (raw.floors !== undefined && raw.floors !== null && toNum(raw.floors, 0) > 0) {
      floors = Math.round(toNum(raw.floors, def.floors));
    } else if (h > 0) {
      floors = Math.round(h / def.floorH);
    } else {
      floors = def.floors;
    }
    floors = clamp(floors, 1, 40);
    if (!(h > 0)) { h = floors * def.floorH; }
    var w = Math.max(3, toNum(raw.w, def.w));
    var d = Math.max(3, toNum(raw.d, def.d));
    h = Math.max(3, h);
    var name = (raw.name === undefined || raw.name === null) ? '' : String(raw.name);
    var id = (raw.id === undefined || raw.id === null || raw.id === '')
      ? ('bld_' + hash32(name + '|' + style + '|' + w + '|' + d + '|' + h).toString(36))
      : String(raw.id);
    var seed = toNum(raw.seed, 1);
    var entrance = (String(raw.entrance || '').toLowerCase() === 'north') ? 'north' : 'south';
    var poiRaw = raw.poi;
    var poi;
    if (poiRaw === undefined || poiRaw === null) { poi = {}; }
    else if (typeof poiRaw === 'string') { poi = { desc: poiRaw }; }
    else if (typeof poiRaw === 'object') { poi = extend({}, poiRaw); }
    else { poi = { value: poiRaw }; }
    return {
      id: id,
      name: name,
      style: style,
      w: w,
      d: d,
      h: h,
      floors: floors,
      rot: toNum(raw.rot, 0),
      parts: (Object.prototype.toString.call(raw.parts) === '[object Array]') ? raw.parts : null,
      roof: raw.roof || null,
      accent: raw.accent || null,
      sign: raw.sign !== false,
      entrance: entrance,
      seed: seed,
      themeVariant: themeVariantFor(id, style, seed),
      poi: extend({ id: id, name: name, style: style, type: 'building' }, poi)
    };
  }

  /** 规范化 parts 中的单个体量 */
  function normalizeVolume(raw, parent, index) {
    raw = raw || {};
    var style = normalizeStyle(raw.style || parent.style);
    var def = STYLE_DEFS[style] || STYLE_DEFS.teaching;
    var h = toNum(raw.h, 0);
    var floors;
    if (raw.floors !== undefined && raw.floors !== null && toNum(raw.floors, 0) > 0) {
      floors = Math.round(toNum(raw.floors, def.floors));
    } else if (h > 0) {
      floors = Math.round(h / def.floorH);
    } else {
      floors = Math.max(1, Math.round(def.floors * 0.5));
    }
    floors = clamp(floors, 1, 40);
    if (!(h > 0)) { h = floors * def.floorH; }
    var seed = toNum(raw.seed, parent.seed);
    return {
      id: parent.id,
      name: '',
      style: style,
      w: Math.max(2.5, toNum(raw.w, def.w * 0.5)),
      d: Math.max(2.5, toNum(raw.d, def.d * 0.5)),
      h: Math.max(2, h),
      floors: floors,
      fh: Math.max(1.8, h / floors),
      rot: toNum(raw.rot, 0),
      roof: raw.roof || null,
      accent: raw.accent || parent.accent,
      sign: raw.sign === true,
      entrance: (String(raw.entrance || parent.entrance || 'south').toLowerCase() === 'north') ? 'north' : 'south',
      seed: seed,
      themeVariant: themeVariantFor(parent.id, style, seed),
      ox: toNum(raw.ox, 0),
      oy: toNum(raw.oy, 0),
      oz: toNum(raw.oz, 0),
      index: index
    };
  }

  function mainVolumeOf(spec) {
    return {
      id: spec.id,
      name: spec.name,
      style: spec.style,
      w: spec.w,
      d: spec.d,
      h: spec.h,
      floors: spec.floors,
      fh: spec.h / spec.floors,
      rot: 0,
      roof: spec.roof,
      accent: spec.accent,
      sign: spec.sign,
      entrance: spec.entrance,
      seed: spec.seed,
      themeVariant: spec.themeVariant,
      ox: 0,
      oy: 0,
      oz: 0,
      poi: spec.poi
    };
  }

  /** 构建单个体量到共享 Builder 上（parts 使用 base 矩阵偏移） */
  function buildVolume(b, vol, opts) {
    var styleFn = STYLES[vol.style] || STYLES.teaching;
    var rng = makeRng(hash32(vol.id + '|' + vol.style + '|' + (opts.index || 0) + '|' + vol.seed + '|' + vol.w + 'x' + vol.d));
    b.setBase(vol.ox || 0, vol.oy || 0, vol.oz || 0, vol.rot || 0);
    _suppressEntrance = !!opts.part;
    _suppressSign = !!opts.part;
    try {
      styleFn(b, opts.kit, vol, { part: !!opts.part, index: opts.index || 0 }, rng);
    } finally {
      _suppressEntrance = false;
      _suppressSign = false;
      b.setBase(0, 0, 0, 0);
    }
  }

  /**
   * 创建一栋建筑。
   * @param {object} rawSpec 见文件头部注释
   * @returns {THREE.Group}
   */
  function create(rawSpec) {
    ensureLib();
    var spec = normalizeSpec(rawSpec);
    var group = new THREE.Group();
    group.name = spec.id;
    if (spec.rot) { group.rotation.y = spec.rot; }

    var b = new Builder();
    var kits = [];
    var kitMap = {};

    function getKit(vol) {
      var key = vol.style + '|' + vol.themeVariant + '|' + (vol.accent || '');
      if (!kitMap[key]) {
        var k = new MaterialKit(vol.style, { themeVariant: vol.themeVariant, accent: vol.accent });
        kitMap[key] = k;
        kits.push(k);
      }
      return kitMap[key];
    }

    // 1) 主体量
    var mainVol = mainVolumeOf(spec);
    buildVolume(b, mainVol, { part: false, kit: getKit(mainVol), index: 0 });

    // 2) 分体量（复合建筑）
    if (spec.parts) {
      for (var i = 0; i < spec.parts.length; i++) {
        if (!spec.parts[i]) { continue; }
        var pv = normalizeVolume(spec.parts[i], spec, i + 1);
        buildVolume(b, pv, { part: true, kit: getKit(pv), index: i + 1 });
      }
    }

    // 3) 合并几何（按材质分桶 -> 少量 Mesh）
    var tris = b.build(group);

    // 4) 夜间自发光材质列表
    var nightWindows = [];
    var targets = [];
    for (var k = 0; k < kits.length; k++) {
      var nights = kits[k].night;
      for (var t = 0; t < nights.length; t++) {
        if (targets.indexOf(nights[t]) < 0) { targets.push(nights[t]); }
      }
    }
    for (var t2 = 0; t2 < targets.length; t2++) { nightWindows.push(targets[t2].mat); }

    function setNight(ratio) {
      var r = clamp(toNum(ratio, 0), 0, 1);
      for (var n = 0; n < targets.length; n++) {
        var mm = targets[n].mat;
        if (mm) { mm.emissiveIntensity = r * targets[n].k; }
      }
      return r;
    }
    setNight(0);

    // 5) 包围盒 / userData
    var bbox = new THREE.Box3().setFromObject(group);
    var bounds = {
      min: [bbox.min.x, bbox.min.y, bbox.min.z],
      max: [bbox.max.x, bbox.max.y, bbox.max.z]
    };
    group.userData = {
      poi: spec.poi,
      footprint: { w: spec.w, d: spec.d, h: spec.h },
      setNight: setNight,
      nightWindows: nightWindows,
      style: spec.style,
      name: spec.name,
      id: spec.id,
      entrance: spec.entrance,
      triangles: Math.round(tris),
      bounds: bounds,
      actualHeight: bbox.max.y,
      _kits: kits,
      _materials: null
    };
    return group;
  }

  /** 释放一栋建筑：从父节点移除，释放几何体与材质（共享纹理缓存保留复用） */
  function dispose(group) {
    if (!group) { return; }
    if (group.parent && group.parent.remove) { group.parent.remove(group); }
    var mats = [];
    group.traverse(function (o) {
      if (o && o.isMesh) {
        if (o.geometry && o.geometry.dispose) { o.geometry.dispose(); }
        var m = o.material;
        if (m) {
          if (Object.prototype.toString.call(m) === '[object Array]') {
            for (var i = 0; i < m.length; i++) {
              if (m[i] && mats.indexOf(m[i]) < 0) { mats.push(m[i]); }
            }
          } else if (mats.indexOf(m) < 0) {
            mats.push(m);
          }
        }
      }
    });
    for (var i = 0; i < mats.length; i++) {
      if (mats[i].dispose) { mats[i].dispose(); }
    }
    while (group.children.length) { group.remove(group.children[0]); }
    if (group.userData) {
      group.userData.nightWindows = [];
      group.userData.setNight = function () { };
    }
  }

  /** 清空模块级 canvas 纹理缓存（一般在完全卸载场景时调用） */
  function disposeCache() {
    var k, v;
    for (k in TEX_CACHE) {
      if (!Object.prototype.hasOwnProperty.call(TEX_CACHE, k)) { continue; }
      v = TEX_CACHE[k];
      if (!v) { continue; }
      if (v.dispose) { v.dispose(); }
      else {
        if (v.day && v.day.dispose) { v.day.dispose(); }
        if (v.night && v.night.dispose) { v.night.dispose(); }
      }
    }
    TEX_CACHE = {};
    for (k in LABEL_CACHE) {
      if (!Object.prototype.hasOwnProperty.call(LABEL_CACHE, k)) { continue; }
      v = LABEL_CACHE[k];
      if (v && v.dispose) { v.dispose(); }
    }
    LABEL_CACHE = {};
  }

  /* ======================================================================
   * 9. 导出
   * ==================================================================== */
  root.CampusBuildings = {
    version: VERSION,
    styles: STYLE_LIST.slice(),
    create: create,
    createBuildingLabelTexture: createBuildingLabelTexture,
    dispose: dispose,
    disposeCache: disposeCache
  };

})(typeof window !== 'undefined' ? window : this);
