/* =========================================================================
 * 湖北国土资源职业学院 · 三维校园
 * data.js — 校园总平面数据（依据学校官网《校园地图》重绘）
 * 坐标系：平面图像素坐标 (px, py)；由 app.js 统一映射为世界坐标
 *   世界 x = (px - CX) * S ；世界 z = (py - CZ) * S
 *   S = 0.62 m/px  CX = 572  CZ = 486
 * ========================================================================= */
window.CAMPUS_DATA = {
  meta: {
    name: '湖北国土资源职业学院',
    enName: 'Hubei Land Resources Vocational College',
    shortName: '湖北国土职院',
    motto: '明德 · 修业 · 砺志 · 笃行',
    schoolSpirit: '团结奋进 · 自强不息 · 精业敬业 · 追求卓越',
    address: '武汉经济技术开发区（汉南区）纱帽街育才路399号',
    coords: '30.3209°N, 114.0421°E',
    founded: '1978',
    intro:
      '学校始建于1978年，是经湖北省人民政府批准、教育部备案的省属公办高等职业院校，地处“中国车谷”武汉经开区职教园区，武汉地铁16号线湾湖站紧邻校园，风景秀丽的马影河沿校园南侧流过，是湖北省“园林式校园”。',
    stats: [
      { value: '1978', label: '建校年份', unit: '年' },
      { value: '8', label: '二级学院', unit: '个' },
      { value: '36', label: '高职专业', unit: '个' },
      { value: '12000', label: '在校生', unit: '余人' },
      { value: '95.8', label: '就业落实率', unit: '%' },
      { value: '525', label: '专兼职教师', unit: '人' }
    ],
    facts: [
      '省属公办全日制高职院校，由湖北省人民政府举办，行政主管部门为湖北省地质局。',
      '2022年入选湖北省高水平高职院校和专业群立项建设单位。',
      '国家级骨干专业：宝玉石鉴定与加工；建有国家级“机器人+”产教融合基地、吉利汽车产教融合基地。',
      '图文信息中心地上12层、建筑面积17783㎡，是校园地标。',
      '地铁16号线湾湖站紧邻校园，南侧隔马影河与坛山岛人工湿地公园相望。'
    ],
    disclaimer:
      '三维校园依据学校官方网站公布的《校园地图》重绘，建筑体量与景观为艺术化表达，非精确测绘；图中“预留发展”等地块尚未建成。',
    sources: [
      { name: '学校简介 · 湖北国土资源职业学院', url: 'https://www.hbgt.edu.cn/xxgk/xxjj.htm' },
      { name: '校园地图 · 湖北国土资源职业学院', url: 'https://www.hbgt.edu.cn/xywh/xydt.htm' },
      { name: '湖北国土资源职业学院章程', url: 'https://xxgk.hbgt.edu.cn/info/1076/3992.htm' },
      { name: '历史沿革 · 湖北国土资源职业学院', url: 'https://www.hbgt.edu.cn/xxgk/lsyg.htm' },
      { name: '学校标识 · 湖北国土资源职业学院', url: 'https://www.hbgt.edu.cn/xywh/xxbs.htm' },
      { name: '图文信息中心工程概况', url: 'http://hbdjcc.com/view/2918.html' }
    ]
  },

  /* ---------------- 建筑 ----------------
   * bx, by  平面图像素坐标（建筑平面中心）
   * w, d    平面图上的宽、深（像素，app 会换算为米）
   * h       高度（米）
   * rot     平面图上的旋转角（度，图面顺时针为正；app 转为 three.js 的 rotation.y = -rot）
   * style   建筑风格（见 js/buildings.js）
   * parts   复合体量：{ w,d,h,ox,oz,oy,floors,style,rot }（单位：像素/米，ox/oz 为像素偏移）
   */
  buildings: [
    /* ---- 学生宿舍（西北生活区，8 栋） ---- */
    { id: 'dorm1', name: '学生宿舍', style: 'dorm', bx: 445, by: 63, w: 92, d: 18, h: 20, floors: 6, rot: -22, seed: 1 },
    { id: 'dorm2', name: '学生宿舍', style: 'dorm', bx: 425, by: 116, w: 92, d: 18, h: 20, floors: 6, rot: -22, seed: 2 },
    { id: 'dorm3', name: '学生宿舍', style: 'dorm', bx: 405, by: 169, w: 92, d: 18, h: 20, floors: 6, rot: -22, seed: 3 },
    { id: 'dorm4', name: '学生宿舍', style: 'dorm', bx: 385, by: 222, w: 92, d: 18, h: 20, floors: 6, rot: -22, seed: 4 },
    { id: 'dorm5', name: '学生宿舍', style: 'dorm', bx: 365, by: 275, w: 92, d: 18, h: 20, floors: 6, rot: -22, seed: 5 },
    { id: 'dorm6', name: '学生宿舍', style: 'dorm', bx: 615, by: 78, w: 88, d: 18, h: 20, floors: 6, rot: -22, seed: 6 },
    { id: 'dorm7', name: '学生宿舍', style: 'dorm', bx: 595, by: 131, w: 88, d: 18, h: 20, floors: 6, rot: -22, seed: 7 },
    { id: 'dorm8', name: '学生宿舍', style: 'dorm', bx: 575, by: 184, w: 88, d: 18, h: 20, floors: 6, rot: -22, seed: 8 },

    /* ---- 东北生活服务组团 ---- */
    {
      id: 'canteen', name: '食堂', style: 'canteen', bx: 788, by: 168, w: 72, d: 46, h: 15, floors: 3, rot: -20, seed: 21, sign: true,
      parts: [
        { w: 30, d: 30, h: 12, ox: 44, oz: 18, floors: 2, style: 'canteen', rot: -20 }
      ]
    },
    { id: 'bath', name: '浴室', style: 'utility', bx: 852, by: 165, w: 36, d: 30, h: 11, floors: 2, rot: -20, seed: 22 },
    { id: 'boiler', name: '锅炉房', style: 'utility', bx: 872, by: 213, w: 28, d: 26, h: 9, floors: 1, rot: -20, seed: 23 },

    /* ---- 中央环形教学区：实验大楼、教学大楼（U 形组合） ---- */
    {
      id: 'lab1', name: '实验大楼', style: 'lab', bx: 705, by: 332, w: 138, d: 24, h: 25, floors: 6, rot: 0, seed: 31, sign: true,
      parts: [
        { w: 22, d: 46, h: 25, ox: -58, oz: 30, floors: 6, style: 'lab' },
        { w: 22, d: 46, h: 25, ox: 58, oz: 30, floors: 6, style: 'lab' }
      ]
    },
    {
      id: 'lab2', name: '实验大楼', style: 'lab', bx: 700, by: 405, w: 146, d: 24, h: 25, floors: 6, rot: 0, seed: 32,
      parts: [
        { w: 22, d: 46, h: 25, ox: -62, oz: 30, floors: 6, style: 'lab' },
        { w: 22, d: 46, h: 25, ox: 62, oz: 30, floors: 6, style: 'lab' }
      ]
    },
    {
      id: 'teach1', name: '教学大楼', style: 'teaching', bx: 700, by: 480, w: 150, d: 24, h: 25, floors: 6, rot: 0, seed: 33, sign: true,
      parts: [
        { w: 22, d: 48, h: 25, ox: -64, oz: 30, floors: 6, style: 'teaching' },
        { w: 22, d: 48, h: 25, ox: 64, oz: 30, floors: 6, style: 'teaching' }
      ]
    },
    {
      id: 'teach2', name: '教学大楼', style: 'teaching', bx: 694, by: 555, w: 142, d: 24, h: 25, floors: 6, rot: 0, seed: 34,
      parts: [
        { w: 22, d: 46, h: 25, ox: -60, oz: 30, floors: 6, style: 'teaching' },
        { w: 22, d: 46, h: 25, ox: 60, oz: 30, floors: 6, style: 'teaching' }
      ]
    },

    /* ---- 图文信息中心（地标） ---- */
    {
      id: 'library', name: '图文信息中心', style: 'library', bx: 858, by: 452, w: 50, d: 44, h: 50, floors: 12, rot: 0, seed: 41, sign: true,
      parts: [
        { w: 104, d: 24, h: 11, ox: -8, oz: -54, floors: 3, style: 'podium' },
        { w: 104, d: 24, h: 11, ox: -8, oz: 54, floors: 3, style: 'podium' },
        { w: 40, d: 78, h: 17, ox: 52, oz: 0, floors: 4, style: 'podium' }
      ]
    },

    /* ---- 西部运动区 ---- */
    { id: 'gym', name: '体育馆', style: 'gym', bx: 330, by: 388, w: 86, d: 58, h: 23, floors: 2, rot: -24, seed: 51, sign: true },
    { id: 'hall', name: '多功能厅', style: 'hall', bx: 452, by: 438, w: 54, d: 54, h: 16, floors: 2, rot: 0, seed: 52 },
    { id: 'culture', name: '文化活动中心', style: 'exchange', bx: 505, by: 543, w: 78, d: 30, h: 17, floors: 3, rot: 55, seed: 53, sign: true },
    { id: 'stand', name: '看台', style: 'stand', bx: 155, by: 626, w: 18, d: 118, h: 9, floors: 1, rot: 25, seed: 54 },

    /* ---- 南部 ---- */
    { id: 'exchange', name: '学术交流中心', style: 'exchange', bx: 600, by: 692, w: 118, d: 48, h: 26, floors: 6, rot: -12, seed: 61, sign: true,
      parts: [
        { w: 42, d: 42, h: 13, ox: -52, oz: 38, floors: 2, style: 'podium' }
      ]
    },

    /* ---- 西南教师公寓 / 人才公寓组团 ---- */
    { id: 'apt1', name: '教师公寓', style: 'apartment', bx: 186, by: 801, w: 58, d: 17, h: 15, floors: 4, rot: 16, seed: 71 },
    { id: 'apt2', name: '教师公寓', style: 'apartment', bx: 252, by: 786, w: 56, d: 17, h: 15, floors: 4, rot: 16, seed: 72 },
    { id: 'apt3', name: '教师公寓', style: 'apartment', bx: 330, by: 812, w: 52, d: 17, h: 15, floors: 4, rot: 12, seed: 73 },
    { id: 'apt4', name: '教师公寓', style: 'apartment', bx: 400, by: 846, w: 54, d: 17, h: 15, floors: 4, rot: 12, seed: 74 },
    { id: 'apt5', name: '教师公寓', style: 'apartment', bx: 300, by: 863, w: 54, d: 16, h: 15, floors: 4, rot: 20, seed: 75 },
    { id: 'apt6', name: '教师公寓', style: 'apartment', bx: 432, by: 886, w: 54, d: 16, h: 15, floors: 4, rot: 20, seed: 76 },

    /* ---- 校门 ---- */
    { id: 'gate_e', name: '校园东门', style: 'gate', bx: 1018, by: 452, w: 12, d: 12, h: 7, floors: 1, rot: 0, seed: 81 },
    { id: 'gate_s', name: '校园南门', style: 'gate', bx: 604, by: 812, w: 12, d: 12, h: 7, floors: 1, rot: 0, seed: 82 }
  ],

  /* ---------------- 场景装饰与水系 ---------------- */
  landmarks: {
    track: { bx: 234, by: 626, rx: 34.6, rz: 67.6, rot: -25 },   // 田径场（中心为图像素；rx/rz 为内圈半轴，单位米）
    courts: { bx: 405, by: 575, w: 190, d: 160, rot: -18 },       // 球类场地群
    plaza: { bx: 760, by: 452 },                                   // 中央礼仪轴
    gate_E: { bx: 1030, by: 452 },                                 // 东门广场
    gate_S: { bx: 604, by: 820 },
    parking: { bx: 972, by: 520, w: 70, d: 52, rot: -15 },
    metroStation: { x: -55, z: -565 },                             // 湾湖站（世界坐标）
    wetland: { x: 330, z: 560 }
  },

  /* ---------------- POI ---------------- */
  pois: [
    { id: 'library', name: '图文信息中心', cat: '教学科研', icon: '◆', bx: 858, by: 452, focus: { dist: 155, pitch: 22 },
      desc: '校园东部地标，集图书馆与信息中心于一体，地上12层、建筑面积17783㎡。',
      facts: ['地上12层，建筑面积17783㎡', '设社科、自科、自习阅览室', '获湖北省结构优质工程', '自习阅览室 8:30—22:00 开放'] },
    { id: 'lab', name: '实验大楼', cat: '教学科研', icon: '◇', bx: 702, by: 368, focus: { dist: 165, pitch: 25 },
      desc: '中央教学区北侧，含部分教学功能，是学校实验实训的重要载体。',
      facts: ['中央环形教学区北翼', '实验实训与教学复合功能', '与教学大楼共同围合中央轴线'] },
    { id: 'teach', name: '教学大楼', cat: '教学科研', icon: '◇', bx: 697, by: 518, focus: { dist: 170, pitch: 25 },
      desc: '中央环形教学区主体，多栋教学楼承担公共课与专业课教学。',
      facts: ['环形教学区南翼', '多栋教学单元组合', '与实验大楼对称布局'] },
    { id: 'dorm', name: '学生宿舍', cat: '生活服务', icon: '▣', bx: 470, by: 180, focus: { dist: 135, pitch: 26 },
      desc: '校园西北部生活区，多栋学生公寓，以四人间为主，配空调、独立卫浴和热水。',
      facts: ['西北生活区，多栋公寓', '四人间为主，上床下桌', '配空调、独立卫浴与热水'] },
    { id: 'canteen', name: '食堂', cat: '生活服务', icon: '▤', bx: 788, by: 168, focus: { dist: 115, pitch: 26 },
      desc: '校园东北部两层食堂，菜品兼顾南北风味，是学生日常就餐的主要场所。',
      facts: ['东北生活服务组团', '两层餐厅，南北风味', '与浴室、锅炉房相邻'] },
    { id: 'bath', name: '浴室 · 锅炉房', cat: '生活服务', icon: '▥', bx: 862, by: 190, focus: { dist: 105, pitch: 24 },
      desc: '与食堂同处一组建筑的公共浴室和锅炉房，构成宿舍区的生活服务配套。',
      facts: ['生活服务配套建筑', '与食堂同组布置'] },
    { id: 'gym', name: '体育馆', cat: '运动健康', icon: '⬡', bx: 330, by: 388, focus: { dist: 120, pitch: 22 },
      desc: '校园西部室内场馆，设健身房、8片羽毛球场、16片乒乓球场，可预约使用。',
      facts: ['1个健身房', '8片羽毛球场、16片乒乓球场', '师生可预约使用'] },
    { id: 'hall', name: '多功能厅', cat: '运动健康', icon: '◉', bx: 452, by: 438, focus: { dist: 85, pitch: 20 },
      desc: '体育馆东南侧的圆形建筑，用于会议、报告、演出等室内多功能活动。',
      facts: ['圆形体量，穹顶造型', '会议、报告、演出多功能厅'] },
    { id: 'track', name: '田径场', cat: '运动健康', icon: '◎', bx: 295, by: 650, focus: { dist: 180, pitch: 30 },
      desc: '校园西南部带看台的田径场，内场为足球场，是运动会与日常锻炼的主场地。',
      facts: ['标准环形跑道，内场足球场', '西侧设看台', '紧邻球类运动场'] },
    { id: 'courts', name: '球类运动场', cat: '运动健康', icon: '⌗', bx: 400, by: 575, focus: { dist: 150, pitch: 32 },
      desc: '田径场东侧的室外球类场地群，篮球场、排球场、网球场毗邻体育馆。',
      facts: ['篮球场、排球场、网球场', '毗邻体育馆与田径场', '满足日常球类运动'] },
    { id: 'culture', name: '文化活动中心', cat: '景观人文', icon: '✦', bx: 505, by: 543, focus: { dist: 100, pitch: 22 },
      desc: '体育馆南侧的学生文化活动场所，适合社团排练、展演与交流。',
      facts: ['学生社团与文化活动空间', '位于体育馆与田径场之间'] },
    { id: 'exchange', name: '学术交流中心', cat: '景观人文', icon: '✧', bx: 600, by: 692, focus: { dist: 120, pitch: 22 },
      desc: '校园南部、临近马影河的学术会议、讲座与接待场所。',
      facts: ['学术会议与培训接待', '临近马影河滨水界面'] },
    { id: 'metasequoia', name: '水杉林区', cat: '景观人文', icon: '♣', bx: 900, by: 728, focus: { dist: 130, pitch: 24 },
      desc: '校园东南部临马影河的成片水杉林，是校园特色生态景观与滨水生态带。',
      facts: ['临马影河的特色植物景观', '校园滨水生态带'] },
    { id: 'oxidation', name: '氧化塘', cat: '景观人文', icon: '≈', bx: 998, by: 244, focus: { dist: 105, pitch: 26 },
      desc: '校园东北角的人工水体，与周边绿地共同构成生态景观。',
      facts: ['东北角人工水体', '与预留发展绿地相邻'] },
    { id: 'river', name: '马影河', cat: '景观人文', icon: '〜', bx: 430, by: 912, focus: { dist: 210, pitch: 24 },
      desc: '沿校园南侧流过的自然河道，形成校园最开阔的滨水生态界面。',
      facts: ['校园南侧自然河道', '水杉、绿地与滨水步道相映', '与坛山岛湿地公园相望'] },
    { id: 'gate', name: '校园东门', cat: '交通门户', icon: '⊓', bx: 1018, by: 452, focus: { dist: 105, pitch: 18 },
      desc: '面向城市主干道的校园东入口，与图文信息中心形成东西向礼仪轴线。',
      facts: ['校园主要入口之一', '正对图文信息中心轴线', '设集中停车场'] },
    { id: 'metro', name: '地铁16号线 · 湾湖站', cat: '交通门户', icon: 'M', world: [-55, -565], focus: { dist: 110, pitch: 16 },
      desc: '武汉地铁16号线湾湖站紧邻校园北侧，从B出口出站即可到校。',
      facts: ['16号线于2021年12月开通', '汉南区首条地铁', '学校北侧即是地铁站'] },
    { id: 'wetland', name: '坛山岛人工湿地公园', cat: '周边地理', icon: '❋', world: [330, 560], focus: { dist: 150, pitch: 22 },
      desc: '校园南侧隔马影河相望，是武汉市最大的岛形人工湿地公园，面积52.51公顷。',
      facts: ['武汉市最大岛形人工湿地公园', '面积52.51公顷', '2.5公里环岛健身绿道', '马影河水质净化系统'] }
  ],

  /* ---------------- 导览路线 ---------------- */
  tour: [
    { id: 'overview', name: '校园全景', caption: '从空中俯瞰，中央环形教学区、西部运动区、西北生活区与东侧地标建筑尽收眼底。',
      cam: { x: 330, y: 300, z: 640 }, target: { x: 30, y: 0, z: 20 } },
    { id: 'gate', name: '东门礼仪轴', caption: '由东门进入，东西向礼仪轴线直抵图文信息中心，是校园最具仪式感的空间序列。',
      cam: { x: 360, y: 95, z: 60 }, target: { x: 175, y: 22, z: -18 } },
    { id: 'library', name: '图文信息中心', caption: '12层高的图文信息中心集图书馆与信息中心于一体，是校园的视觉核心。',
      cam: { x: 265, y: 85, z: 88 }, target: { x: 176, y: 30, z: -21 } },
    { id: 'axis', name: '中央环形教学区', caption: '实验大楼与教学大楼对称围合中央环形水系，形成“教学—实验—信息”一体的学习社区。',
      cam: { x: 115, y: 130, z: 135 }, target: { x: 70, y: 8, z: 12 } },
    { id: 'sports', name: '西部运动区', caption: '体育馆、多功能厅与标准田径场、球类场地共同构成充满活力的运动片区。',
      cam: { x: -330, y: 110, z: 210 }, target: { x: -180, y: 6, z: 60 } },
    { id: 'dorm', name: '西北生活区', caption: '八栋学生宿舍与食堂、浴室围合成安静便利的生活社区，紧邻地铁湾湖站方向。',
      cam: { x: -140, y: 105, z: -230 }, target: { x: -80, y: 8, z: -175 } },
    { id: 'river', name: '马影河滨水界面', caption: '马影河沿校园南侧蜿蜒而过，水杉林、湿地与滨水步道构成校园的生态底色。',
      cam: { x: 300, y: 95, z: 480 }, target: { x: 110, y: 2, z: 250 } },
    { id: 'night', name: '夜幕下的校园', caption: '华灯初上，图书馆与教学楼次第亮起，环形水系倒映着星光与灯火。',
      cam: { x: 250, y: 170, z: 420 }, target: { x: 40, y: 6, z: 10 }, night: true }
  ],

  /* ---------------- UI 文案 ---------------- */
  ui: {
    title: '湖北国土资源职业学院',
    subtitle: '三维校园 · 云上国土',
    loadingTips: [
      '正在依据官方校园地图铺开三维校园…',
      '正在栽种香樟与水杉…',
      '正在点亮图文信息中心的灯火…',
      '正在引马影河水入校…',
      '即将抵达 · 中国车谷 · 武汉经开区'
    ],
    welcome: '欢迎来到湖北国土资源职业学院',
    warmLine: '丈量山河经纬 · 淬炼匠者初心',
    controls: ['拖动旋转', '滚轮缩放', '右键平移', '点击地标查看详情']
  }
};
