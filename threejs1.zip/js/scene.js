/* =========================================================================
 * 湖北国土资源职业学院 · 三维校园
 * scene.js — 场景构建：地表 / 水系 / 天空 / 植被 / 建筑集成 / 交通 / 人物 / 灯光
 * 依赖：three.min.js (r159 UMD)、ground-data.js、ground-tex.js、data.js、buildings.js
 * ========================================================================= */
(function () {
  'use strict';
  const THREE = window.THREE;
  const GD = window.GROUND_DATA;
  const DATA = window.CAMPUS_DATA;
  const S = GD.S, CX = GD.CX, CZ = GD.CZ;
  const SCENE_W = GD.SCENE_W, SCENE_D = GD.SCENE_D;
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const TAU = Math.PI * 2;

  function p2w(px, py) { return [(px - CX) * S, (py - CZ) * S]; }
  function wpx(px) { return px * S; }

  /* ---------------- 程序化贴图工具 ---------------- */
  function canvas(w, h, draw) {
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d');
    draw(ctx, w, h);
    return c;
  }
  function canvasTex(w, h, draw, opts) {
    const t = new THREE.CanvasTexture(canvas(w, h, draw));
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 4;
    if (opts && opts.wrap) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
    if (opts && opts.repeat) t.repeat.set(opts.repeat[0], opts.repeat[1]);
    return t;
  }
  const CACHE = {};
  function cached(key, fn) { return CACHE[key] || (CACHE[key] = fn()); }

  const PALETTE = {
    grass: 0x6f9b4f,
    lawn: 0x83ad5c,
    road: 0x6d7178,
    pave: 0xd9d0ba,
    wall: 0xf1ece0,
    wallWarm: 0xe8dfcd,
    glass: 0x4f7f96,
    glassLight: 0x9cc3cf,
    accent: 0xb6604f,
    gold: 0xc9a35e,
    teal: 0x1f6f7a,
    trunk: 0x6b4f36,
    leafA: 0x5d8b46,
    leafB: 0x4b7a3c,
    leafC: 0x74a253,
    conifer: 0x3f6b46,
    water: 0x2f7f95
  };

  /* ---------------- 天空着色器 ---------------- */
  const SKY_VERT = `
    varying vec3 vDir;
    void main(){
      vDir = normalize(position);
      vec4 mv = modelViewMatrix * vec4(position, 1.0);
      gl_Position = projectionMatrix * mv;
    }`;
  const SKY_FRAG = `
    varying vec3 vDir;
    uniform vec3 uTop;
    uniform vec3 uHorizon;
    uniform vec3 uBottom;
    uniform vec3 uSunDir;
    uniform vec3 uSunColor;
    uniform float uNight;
    uniform float uTime;
    float hash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }
    void main(){
      vec3 dir = normalize(vDir);
      float h = dir.y;
      vec3 col = mix(uHorizon, uTop, smoothstep(0.0, 0.55, max(h, 0.0)));
      col = mix(col, uBottom, smoothstep(0.0, -0.35, h));
      // 太阳光晕
      float sd = max(dot(dir, normalize(uSunDir)), 0.0);
      col += uSunColor * pow(sd, 18.0) * 0.55;
      col += uSunColor * pow(sd, 240.0) * 1.1;
      col += uSunColor * pow(sd, 1200.0) * 2.4;
      // 星星
      if (uNight > 0.01) {
        vec3 sp = floor(dir * 380.0);
        float star = step(0.9975, hash(sp));
        float tw = 0.55 + 0.45 * sin(uTime * 2.2 + hash(sp + 3.0) * 40.0);
        float mask = smoothstep(-0.02, 0.25, h) * uNight;
        col += vec3(0.9, 0.95, 1.0) * star * tw * mask * 1.4;
        // 月亮
        vec3 moonDir = normalize(vec3(-0.45, 0.42, 0.55));
        float md = max(dot(dir, moonDir), 0.0);
        col += vec3(0.85, 0.9, 1.0) * pow(md, 380.0) * 2.0 * uNight;
        col += vec3(0.45, 0.55, 0.75) * pow(md, 18.0) * 0.25 * uNight;
      }
      // 地平线柔光
      col += uSunColor * pow(1.0 - abs(h), 6.0) * 0.06;
      gl_FragColor = vec4(col, 1.0);
    }`;

  /* ---------------- 水面着色器 ---------------- */
  const WATER_VERT = `
    varying vec2 vUv;
    varying vec3 vWorld;
    varying float vFogDepth;
    void main(){
      vUv = uv;
      vec4 wp = modelMatrix * vec4(position, 1.0);
      vWorld = wp.xyz;
      vec4 mvPosition = viewMatrix * wp;
      vFogDepth = -mvPosition.z;
      gl_Position = projectionMatrix * mvPosition;
    }`;
  const WATER_FRAG = `
    varying vec2 vUv;
    varying vec3 vWorld;
    varying float vFogDepth;
    uniform sampler2D uMask;
    uniform float uTime;
    uniform vec3 uDeep;
    uniform vec3 uShallow;
    uniform vec3 uSky;
    uniform vec3 uSunDir;
    uniform vec3 uSunColor;
    uniform vec3 uFogColor;
    uniform float uFogDensity;
    uniform float uNight;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
    float noise(vec2 p){
      vec2 i = floor(p), f = fract(p);
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
                 mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
    }
    vec2 waveN(vec2 p, float t){
      float n1 = noise(p * 0.09 + vec2(t * 0.045, t * 0.02));
      float n2 = noise(p * 0.21 - vec2(t * 0.03, t * 0.05));
      float e = 0.35;
      float dx = noise((p + vec2(e, 0.0)) * 0.09 + vec2(t * 0.045, t * 0.02)) - n1;
      float dy = noise((p + vec2(0.0, e)) * 0.09 + vec2(t * 0.045, t * 0.02)) - n1;
      return normalize(vec2(dx, dy) * 2.2 + vec2(n2 - 0.5) * 0.6 + vec2(0.0001));
    }
    void main(){
      float a = texture2D(uMask, vUv).r;
      if (a < 0.06) discard;
      vec2 p = vWorld.xz;
      vec2 n = waveN(p * 1.6, uTime);
      vec3 N = normalize(vec3(n.x * 0.07, 1.0, n.y * 0.07));
      vec3 V = normalize(cameraPosition - vWorld);
      float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
      vec3 base = mix(uShallow, uDeep, smoothstep(0.18, 0.85, a));
      vec3 col = mix(base, uSky, fres * 0.26);
      float sp = pow(max(dot(reflect(-normalize(uSunDir), N), V), 0.0), 220.0);
      col += uSunColor * sp * (1.0 - uNight * 0.6) * 1.1;
      float spark = pow(noise(p * 5.2 + vec2(uTime * 0.5, -uTime * 0.3)), 16.0);
      col += uSunColor * spark * 0.12 * (1.0 - uNight * 0.8);
      float shore = smoothstep(0.55, 0.12, a);
      col = mix(col, uShallow * 0.98, shore * 0.45);
      col += vec3(0.95, 0.72, 0.38) * uNight * 0.035 * (0.4 + 0.6 * noise(p * 0.5 + uTime * 0.05));
      float fogFactor = 1.0 - exp(-uFogDensity * uFogDensity * vFogDepth * vFogDepth);
      col = mix(col, uFogColor, clamp(fogFactor, 0.0, 1.0));
      float alpha = smoothstep(0.055, 0.22, a) * 0.95;
      gl_FragColor = vec4(col, alpha);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }`;

  /* ---------------- 主场景类 ---------------- */
  class CampusWorld {
    constructor(scene, renderer) {
      this.scene = scene;
      this.renderer = renderer;
      this.root = new THREE.Group();
      this.root.name = 'campusRoot';
      scene.add(this.root);
      this.time = 0;
      this.night = 0;
      this.actors = [];
      this.carPaths = [];
      this.cars = [];
      this.people = [];
      this.birds = [];
      this.buildingGroups = [];
      this.pickMeshes = [];
      this.poiWorld = {};
      this.qualityShadows = true;
      this.textures = null;
    }

    /* -------- 初始化：先加载数据贴图，再构建 -------- */
    static async create(scene, renderer) {
      const world = new CampusWorld(scene, renderer);
      world.textures = await CampusWorld.loadTextures();
      world.build();
      return world;
    }

    static loadTextures() {
      return new Promise((resolve, reject) => {
        const loader = new THREE.TextureLoader();
        let ground = null, mask = null, pending = 2;
        const done = () => {
          if (--pending === 0) {
            resolve({ ground, mask });
          }
        };
        loader.load(window.GROUND_TEXTURE_URI, (t) => {
          t.colorSpace = THREE.SRGBColorSpace;
          t.anisotropy = 8;
          t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
          ground = t; done();
        }, undefined, () => { reject(new Error('地面贴图加载失败')); });
        loader.load(GD.waterMaskURI, (t) => {
          t.colorSpace = THREE.NoColorSpace;
          t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
          mask = t; done();
        }, undefined, () => { reject(new Error('水面遮罩加载失败')); });
      });
    }

    build() {
      this.buildSky();
      this.buildLights();
      this.buildGround();
      this.buildWater();
      this.buildTrees();
      this.buildBuildings();
      this.buildProps();
      this.buildMetro();
      this.buildDistantCity();
      this.buildPeople();
      this.buildCars();
      this.buildBirds();
      this.buildFireflies();
      this.setNight(0);
    }

    /* ================= 天空 / 灯光 ================= */
    buildSky() {
      const geo = new THREE.SphereGeometry(2600, 40, 24);
      this.skyUniforms = {
        uTop: { value: new THREE.Color(0x6fb4d8) },
        uHorizon: { value: new THREE.Color(0xe7f0e9) },
        uBottom: { value: new THREE.Color(0xc9d6c4) },
        uSunDir: { value: new THREE.Vector3(0.4, 0.7, 0.4).normalize() },
        uSunColor: { value: new THREE.Color(0xffe4b5) },
        uNight: { value: 0 },
        uTime: { value: 0 }
      };
      const mat = new THREE.ShaderMaterial({
        vertexShader: SKY_VERT, fragmentShader: SKY_FRAG,
        uniforms: this.skyUniforms, side: THREE.BackSide, depthWrite: false, fog: false
      });
      this.sky = new THREE.Mesh(geo, mat);
      this.sky.frustumCulled = false;
      this.scene.add(this.sky);

      // 云（远高层，避免进入镜头中间）
      this.clouds = new THREE.Group();
      const cloudTex = canvasTex(256, 128, (ctx, w, h) => {
        ctx.clearRect(0, 0, w, h);
        for (let i = 0; i < 26; i++) {
          const x = Math.random() * w, y = h * 0.45 + (Math.random() - 0.5) * h * 0.3;
          const r = 18 + Math.random() * 38;
          const g = ctx.createRadialGradient(x, y, 0, x, y, r);
          g.addColorStop(0, 'rgba(255,255,255,0.55)');
          g.addColorStop(0.6, 'rgba(255,255,255,0.18)');
          g.addColorStop(1, 'rgba(255,255,255,0)');
          ctx.fillStyle = g;
          ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
        }
      });
      const cloudMat = new THREE.MeshBasicMaterial({
        map: cloudTex, transparent: true, depthWrite: false, opacity: 0.45, fog: false
      });
      this.cloudMat = cloudMat;
      for (let i = 0; i < 10; i++) {
        const m = new THREE.Mesh(new THREE.PlaneGeometry(420 + Math.random() * 360, 130 + Math.random() * 110), cloudMat);
        const ang = Math.PI * (0.15 + Math.random() * 0.7);
        const r = 1500 + Math.random() * 700;
        m.position.set(Math.cos(ang) * r, 430 + Math.random() * 300, Math.sin(ang) * r);
        m.lookAt(0, m.position.y * 0.6, 0);
        m.userData.drift = 0.0005 + Math.random() * 0.001;
        this.clouds.add(m);
      }
      this.scene.add(this.clouds);
    }

    buildLights() {
      this.hemi = new THREE.HemisphereLight(0xd4e8f2, 0x707a52, 1.05);
      this.scene.add(this.hemi);

      this.sun = new THREE.DirectionalLight(0xffe3b8, 3.1);
      this.sun.position.set(-430, 330, 230);
      this.sun.castShadow = true;
      const sc = this.sun.shadow;
      sc.mapSize.set(2048, 2048);
      sc.camera.left = -470; sc.camera.right = 470;
      sc.camera.top = 470; sc.camera.bottom = -470;
      sc.camera.near = 20; sc.camera.far = 1800;
      sc.camera.updateProjectionMatrix();
      sc.bias = -0.0004;
      sc.normalBias = 0.06;
      sc.radius = 2.2;
      this.scene.add(this.sun);
      this.sunTarget = new THREE.Object3D();
      this.sunTarget.position.set(0, 0, 0);
      this.scene.add(this.sunTarget);
      this.sun.target = this.sunTarget;

      // 夜间补光（月光）
      this.moon = new THREE.DirectionalLight(0x8fa8cc, 0.0);
      this.moon.position.set(-260, 380, -180);
      this.scene.add(this.moon);
      this.ambient = new THREE.AmbientLight(0xffffff, 0.14);
      this.scene.add(this.ambient);
    }

    /* ================= 地面 / 水面 ================= */
    buildGround() {
      const tex = this.textures.ground;
      const mat = new THREE.MeshStandardMaterial({
        map: tex, roughness: 0.97, metalness: 0.0, color: 0xffffff
      });
      // 细节噪点：近景时补充地表颗粒感
      const detailTex = canvasTex(256, 256, (ctx, w, h) => {
        const img = ctx.createImageData(w, h);
        for (let i = 0; i < w * h; i++) {
          const v = 205 + Math.random() * 50;
          img.data[i * 4] = v; img.data[i * 4 + 1] = v; img.data[i * 4 + 2] = v * 0.96;
          img.data[i * 4 + 3] = 255;
        }
        ctx.putImageData(img, 0, 0);
        ctx.globalAlpha = 0.18;
        for (let i = 0; i < 900; i++) {
          ctx.fillStyle = Math.random() > 0.5 ? '#8a9a6a' : '#cbbf9e';
          ctx.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2);
        }
      }, { wrap: true, repeat: [90, 90] });
      mat.onBeforeCompile = (shader) => {
        shader.uniforms.uDetail = { value: detailTex };
        shader.fragmentShader = 'uniform sampler2D uDetail;\n' + shader.fragmentShader;
        shader.fragmentShader = shader.fragmentShader.replace(
          '#include <map_fragment>',
          `#include <map_fragment>
           vec3 dcol = texture2D(uDetail, vMapUv * 140.0).rgb;
           diffuseColor.rgb *= (0.93 + dcol.g * 0.13);`
        );
      };
      const geo = new THREE.PlaneGeometry(SCENE_W, SCENE_D);
      this.ground = new THREE.Mesh(geo, mat);
      this.ground.rotation.x = -Math.PI / 2;
      this.ground.position.y = 0;
      this.ground.receiveShadow = true;
      this.ground.name = 'ground';
      this.root.add(this.ground);

      // 远处大地（与地表色系统一，靠雾气过渡）
      const farGeo = new THREE.PlaneGeometry(7000, 7000);
      const farMat = new THREE.MeshStandardMaterial({ color: 0x8e9a6d, roughness: 1.0 });
      this.farGround = new THREE.Mesh(farGeo, farMat);
      this.farGround.rotation.x = -Math.PI / 2;
      this.farGround.position.y = -0.8;
      this.farGround.receiveShadow = false;
      this.root.add(this.farGround);
    }

    buildWater() {
      const mask = this.textures.mask;
      const uniforms = THREE.UniformsUtils.merge([THREE.UniformsLib.fog, {
        uMask: { value: null },
        uTime: { value: 0 },
        uDeep: { value: new THREE.Color(0x123a4a) },
        uShallow: { value: new THREE.Color(0x3f7e8e) },
        uSky: { value: new THREE.Color(0xc2dde6) },
        uSunDir: { value: new THREE.Vector3(-0.6, 0.5, 0.35).normalize() },
        uSunColor: { value: new THREE.Color(0xffe6bd) },
        uFogColor: { value: new THREE.Color(0xe8e6d6) },
        uFogDensity: { value: 0.00034 },
        uNight: { value: 0 }
      }]);
      uniforms.uMask.value = mask;
      const mat = new THREE.ShaderMaterial({
        vertexShader: WATER_VERT, fragmentShader: WATER_FRAG,
        uniforms: uniforms, transparent: true, depthWrite: false, fog: false
      });
      this.waterUniforms = mat.uniforms;
      const geo = new THREE.PlaneGeometry(SCENE_W, SCENE_D);
      this.water = new THREE.Mesh(geo, mat);
      this.water.rotation.x = -Math.PI / 2;
      this.water.position.y = 0.22;
      this.water.renderOrder = 2;
      this.root.add(this.water);
    }

    /* ================= 植被 ================= */
    buildTrees() {
      const trees = GD.trees.slice();
      // ---- 补充行道树 / 水岸树 / 林带（让校园周边更有生气） ----
      const rng = mulberry32(8899);
      const addRow = (pts, spacing, jitter, type, offsets) => {
        (offsets || [0]).forEach((off) => {
          for (let i = 0; i < pts.length - 1; i++) {
            const a = pts[i], b = pts[i + 1];
            const dx = b[0] - a[0], dz = b[1] - a[1];
            const len = Math.hypot(dx, dz);
            const n = Math.max(1, Math.floor(len / spacing));
            const nx = dz / (len || 1), nz = -dx / (len || 1);
            for (let k = 0; k < n; k++) {
              const t = k / n;
              const x = a[0] + dx * t + nx * off + (rng() - 0.5) * jitter;
              const z = a[1] + dz * t + nz * off + (rng() - 0.5) * jitter;
              trees.push([x, z, rng() < 0.28 ? 1 : 0, 0.85 + rng() * 0.5, rng() * TAU]);
            }
          }
        });
      };
      // 育才路两侧
      addRow([[-900, -445], [-600, -415], [-300, -390], [0, -370], [300, -355], [600, -375], [920, -405]], 17, 3, 0, [-15, 15]);
      // 东侧城市干道
      addRow([[432, -740], [430, -420], [424, -140], [414, 160], [398, 420], [382, 620]], 17, 3, 0, [-14, 14]);
      // 校园环路外侧
      const b = GD.boundary;
      if (b && b.length > 3) {
        const cx = b.reduce((a, p) => a + p[0], 0) / b.length;
        const cz = b.reduce((a, p) => a + p[1], 0) / b.length;
        const ring = b.map((p) => {
          const dx = p[0] - cx, dz = p[1] - cz, l = Math.hypot(dx, dz) || 1;
          return [p[0] + dx / l * 44, p[1] + dz / l * 44];
        });
        addRow(ring.concat([ring[0]]), 16, 2.2, 0, [0]);
        const ring2 = b.map((p) => {
          const dx = p[0] - cx, dz = p[1] - cz, l = Math.hypot(dx, dz) || 1;
          return [p[0] + dx / l * 52, p[1] + dz / l * 52];
        });
        addRow(ring2.concat([ring2[0]]), 20, 2.6, 1, [0]);
      }
      // 湾湖湖岸
      const lakeRow = [];
      for (let i = 0; i <= 26; i++) {
        const a = i / 26 * TAU;
        lakeRow.push([-700 + Math.cos(a) * 240, -370 + Math.sin(a) * 180]);
      }
      addRow(lakeRow, 22, 12, 0, [0]);
      // 远处林带（围绕场景外圈）
      for (let i = 0; i < 420; i++) {
        const a = rng() * TAU;
        const r = 780 + rng() * 380;
        const x = Math.cos(a) * r, z = Math.sin(a) * r * 0.86;
        trees.push([x, z, rng() < 0.5 ? 1 : 0, 1.0 + rng() * 0.65, rng() * TAU]);
      }
      const broad = [], conifer = [], shrub = [];
      for (const t of trees) {
        const [x, z, type, s, r] = t;
        if (type === 1) conifer.push([x, z, s, r]);
        else if (type === 2) shrub.push([x, z, s, r]);
        else broad.push([x, z, s, r]);
      }
      const dummy = new THREE.Object3D();
      const makeInst = (geo, mat, list, yBase, heightFn, colorFn) => {
        const m = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length));
        m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
        const col = new THREE.Color();
        for (let i = 0; i < list.length; i++) {
          const [x, z, s, r] = list[i];
          dummy.position.set(x, yBase, z);
          dummy.rotation.set(0, r, 0);
          const sc = heightFn(s);
          dummy.scale.set(sc.x, sc.y, sc.z);
          dummy.updateMatrix();
          m.setMatrixAt(i, dummy.matrix);
          if (colorFn) { colorFn(col, i, s); m.setColorAt(i, col); }
        }
        m.count = list.length;
        m.castShadow = true;
        m.receiveShadow = true;
        m.frustumCulled = true;
        this.root.add(m);
        return m;
      };

      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x6a4a33, roughness: 0.95 });
      const leafMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, vertexColors: false });
      const coniferMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 });

      // 阔叶树：低多边形球簇
      const crownGeo = new THREE.IcosahedronGeometry(1, 1);
      crownGeo.scale(1.5, 1.15, 1.5);
      const trunkGeo = new THREE.CylinderGeometry(0.16, 0.32, 1, 5);
      const greens = [0x5f8f49, 0x527f3f, 0x6fa055, 0x4a7639, 0x7ba45a];

      const broadTrunks = makeInst(trunkGeo, trunkMat, broad, 0, s => ({ x: s, y: 3.4 * s, z: s }), null);
      broadTrunks.position.y = 0;
      // 对于圆柱：以中心定位，调整 y 到树干中心
      const broadCrowns = makeInst(crownGeo, leafMat, broad, 3.4, s => {
        const k = 2.15 * s;
        return { x: k, y: k * 0.95, z: k };
      }, (col, i, s) => { col.setHex(greens[i % greens.length]); });

      // 调整阔叶树干实例的 y（中心 = 1.7*s）
      {
        const d2 = new THREE.Object3D();
        const col = new THREE.Color();
        for (let i = 0; i < broad.length; i++) {
          const [x, z, s, r] = broad[i];
          d2.position.set(x, 1.7 * s, z);
          d2.rotation.set(0, r, 0);
          d2.scale.set(s, 3.4 * s, s);
          d2.updateMatrix();
          broadTrunks.setMatrixAt(i, d2.matrix);
          col.setHex(greens[i % greens.length]); broadTrunks.setColorAt(i, col);
        }
        broadTrunks.instanceColor.needsUpdate = true;
      }

      // 水杉：圆锥
      const coneGeo = new THREE.ConeGeometry(1, 1, 7);
      const coniferTrunks = makeInst(trunkGeo, trunkMat, conifer, 0, s => ({ x: s * 0.9, y: 2.6 * s, z: s * 0.9 }), null);
      {
        const d3 = new THREE.Object3D();
        for (let i = 0; i < conifer.length; i++) {
          const [x, z, s, r] = conifer[i];
          d3.position.set(x, 1.3 * s, z);
          d3.rotation.set(0, r, 0);
          d3.scale.set(s * 0.9, 2.6 * s, s * 0.9);
          d3.updateMatrix();
          coniferTrunks.setMatrixAt(i, d3.matrix);
        }
      }
      const coneCrown = makeInst(coneGeo, coniferMat, conifer, 2.4, s => ({ x: 1.55 * s, y: 5.4 * s, z: 1.55 * s }),
        (col, i) => { col.setHex(i % 3 === 0 ? 0x39634a : 0x2f5b3f); });
      {
        const d4 = new THREE.Object3D();
        for (let i = 0; i < conifer.length; i++) {
          const [x, z, s, r] = conifer[i];
          d4.position.set(x, 2.4 * s + 2.7 * s, z);
          d4.rotation.set(0, r, 0);
          d4.scale.set(1.55 * s, 5.4 * s, 1.55 * s);
          d4.updateMatrix();
          coneCrown.setMatrixAt(i, d4.matrix);
        }
      }

      // 灌木
      const bushGeo = new THREE.IcosahedronGeometry(1, 1);
      const bushMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95 });
      const bushes = makeInst(bushGeo, bushMat, shrub, 0.55, s => ({ x: 1.0 * s, y: 0.6 * s, z: 1.0 * s }),
        (col, i) => { col.setHex([0x5c8a46, 0x6b9950, 0x4f7d3e][i % 3]); });
      {
        const d5 = new THREE.Object3D();
        for (let i = 0; i < shrub.length; i++) {
          const [x, z, s, r] = shrub[i];
          d5.position.set(x, 0.6 * s, z);
          d5.rotation.set(0, r, 0);
          d5.scale.set(1.1 * s, 0.7 * s, 1.1 * s);
          d5.updateMatrix();
          bushes.setMatrixAt(i, d5.matrix);
        }
      }

      // 校园边界绿篱（世界坐标）
      this.addBoundaryHedge();

      this.treeMeshes = [broadTrunks, broadCrowns, coniferTrunks, coneCrown, bushes];
    }

    addBoundaryHedge() {
      const boundary = GD.boundary;
      if (!boundary || boundary.length < 3) return;
      const pts = [];
      for (let i = 0; i < boundary.length; i++) {
        const a = boundary[i], b = boundary[(i + 1) % boundary.length];
        const dx = b[0] - a[0], dz = b[1] - a[1];
        const len = Math.hypot(dx, dz);
        const n = Math.max(1, Math.floor(len / 4.5));
        for (let k = 0; k < n; k++) {
          const t = k / n;
          pts.push([a[0] + dx * t - (dz / (len || 1)) * 1.8, a[1] + dz * t + (dx / (len || 1)) * 1.8]);
        }
      }
      const geo = new THREE.IcosahedronGeometry(1, 0);
      const mat = new THREE.MeshStandardMaterial({ color: 0x4c7a3d, roughness: 1 });
      const inst = new THREE.InstancedMesh(geo, mat, pts.length);
      const dummy = new THREE.Object3D();
      for (let i = 0; i < pts.length; i++) {
        const s = 1.2 + (i % 3) * 0.25;
        dummy.position.set(pts[i][0], 0.55 * s, pts[i][1]);
        dummy.rotation.set(0, i * 1.7, 0);
        dummy.scale.set(s * 1.25, s * 0.75, s * 1.25);
        dummy.updateMatrix();
        inst.setMatrixAt(i, dummy.matrix);
      }
      inst.castShadow = true; inst.receiveShadow = true;
      this.root.add(inst);
      this.hedge = inst;
    }

    /* ================= 建筑 ================= */
    resolvePoiId(bid) {
      if (bid.indexOf('dorm') === 0) return 'dorm';
      if (bid === 'canteen') return 'canteen';
      if (bid === 'bath' || bid === 'boiler') return 'bath';
      if (bid === 'lab1' || bid === 'lab2') return 'lab';
      if (bid === 'teach1' || bid === 'teach2') return 'teach';
      if (bid === 'stand') return 'track';
      if (bid === 'gate_e' || bid === 'gate_s') return 'gate';
      return bid;
    }

    buildBuildings() {
      const B = window.CampusBuildings;
      for (const spec of DATA.buildings) {
        let group;
        const pos = p2w(spec.bx, spec.by);
        const conv = {
          id: spec.id, name: spec.name, style: spec.style,
          w: wpx(spec.w), d: wpx(spec.d), h: spec.h, floors: spec.floors,
          rot: 0, seed: spec.seed || 1, sign: !!spec.sign, entrance: spec.entrance || 'south',
          accent: spec.accent, parts: (spec.parts || []).map(p => ({
            w: wpx(p.w), d: wpx(p.d), h: p.h, floors: p.floors, style: p.style,
            ox: p.ox ? wpx(p.ox) : 0, oz: p.oz ? wpx(p.oz) : 0, oy: p.oy || 0,
            rot: p.rot ? -p.rot * Math.PI / 180 : 0
          }))
        };
        if (B && B.create) {
          group = B.create(conv);
        } else {
          group = this.fallbackBuilding(conv);
        }
        group.position.set(pos[0], 0, pos[1]);
        group.rotation.y = -(spec.rot || 0) * Math.PI / 180;
        group.userData.poiId = this.resolvePoiId(spec.id);
        group.userData.buildingId = spec.id;
        group.userData.height = spec.h;
        group.traverse(o => {
          if (o.isMesh) {
            o.castShadow = true;
            o.receiveShadow = true;
            o.userData.poiId = group.userData.poiId;
            o.userData.buildingId = spec.id;
            if (o.material && o.material.isMeshStandardMaterial) {
              if (o.material.envMapIntensity !== undefined) o.material.envMapIntensity = 0.35;
            }
            this.pickMeshes.push(o);
          }
        });
        this.root.add(group);
        this.buildingGroups.push(group);
      }
    }

    /* 兜底建筑（当 buildings.js 未加载时） */
    fallbackBuilding(spec) {
      const g = new THREE.Group();
      const tex = cached('win' + spec.style, () => canvasTex(256, 256, (ctx, w, h) => {
        ctx.fillStyle = '#f2ede1'; ctx.fillRect(0, 0, w, h);
        const rows = Math.max(2, Math.round(spec.floors || 5));
        const cols = 7;
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            ctx.fillStyle = (r + c) % 4 === 0 ? '#9db8c4' : '#54788c';
            ctx.fillRect(8 + c * 35, 10 + r * (236 / rows), 26, Math.max(8, 220 / rows - 10));
          }
        }
      }, { wrap: true, repeat: [2, 1] }));
      const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.8 });
      const m = new THREE.Mesh(new THREE.BoxGeometry(spec.w, spec.h, spec.d), mat);
      m.position.y = spec.h / 2;
      g.add(m);
      const roof = new THREE.Mesh(new THREE.BoxGeometry(spec.w * 1.02, 0.6, spec.d * 1.02),
        new THREE.MeshStandardMaterial({ color: 0xd8d2c5, roughness: 0.9 }));
      roof.position.y = spec.h + 0.3;
      g.add(roof);
      return g;
    }

    /* ================= 校园道具 ================= */
    buildProps() {
      this.buildTrack();
      this.buildCentralAxis();
      this.buildGates();
      this.buildLamps();
      this.buildFlagsAndStone();
      this.buildParking();
      this.buildPaving();
    }

    pavingTexture() {
      return cached('paving', () => canvasTex(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#cfc6b0'; ctx.fillRect(0, 0, w, h);
        const rng = mulberry32(99);
        for (let y = 0; y < 8; y++) {
          for (let x = 0; x < 8; x++) {
            const shade = 196 + Math.floor(rng() * 18);
            ctx.fillStyle = 'rgb(' + shade + ',' + (shade - 6) + ',' + (shade - 22) + ')';
            ctx.fillRect(x * 64 + 1, y * 64 + 1, 62, 62);
          }
        }
        ctx.strokeStyle = 'rgba(150,140,118,0.55)'; ctx.lineWidth = 2;
        for (let i = 0; i <= 8; i++) {
          ctx.beginPath(); ctx.moveTo(i * 64, 0); ctx.lineTo(i * 64, h); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(0, i * 64); ctx.lineTo(w, i * 64); ctx.stroke();
        }
        ctx.globalAlpha = 0.10;
        for (let i = 0; i < 2000; i++) {
          ctx.fillStyle = Math.random() > 0.5 ? '#6d6a5c' : '#f4ecd8';
          ctx.fillRect(Math.random() * w, Math.random() * h, 2, 2);
        }
      }, { wrap: true }));
    }

    buildPaving() {
      const tex = this.pavingTexture();
      tex.repeat.set(1, 1);
      const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.9, metalness: 0.0 });
      const rng = mulberry32(7);
      const addStrip = (cx, cz, lenX, lenZ, rot) => {
        const geo = new THREE.PlaneGeometry(lenX, lenZ);
        const m = new THREE.Mesh(geo, mat);
        m.rotation.x = -Math.PI / 2;
        m.rotation.z = rot || 0;
        m.position.set(cx, 0.045, cz);
        m.receiveShadow = true;
        if (m.material.map) m.material.map.repeat.set(lenX / 14, lenZ / 14);
        this.root.add(m);
      };
      // 东门—图文信息中心 礼仪轴
      const axisA = p2w(930, 452), axisB = p2w(1030, 452);
      addStrip((axisA[0] + axisB[0]) / 2, axisA[1], (axisB[0] - axisA[0]) + 8, 30, 0);
      // 图书馆前广场
      const fp = p2w(830, 452);
      addStrip(fp[0], fp[1], 86, 96, 0);
      // 中央教学区南北轴线
      const ca = p2w(758, 305), cb = p2w(758, 615);
      addStrip(ca[0], (ca[1] + cb[1]) / 2, 18, (cb[1] - ca[1]), 0);
      // 东门内广场
      const gp = p2w(1005, 452);
      addStrip(gp[0], gp[1], 44, 86, 0);
      // 南门广场（圆形）
      const sp = p2w(604, 822);
      const circle = new THREE.Mesh(new THREE.CircleGeometry(34, 40), mat);
      circle.rotation.x = -Math.PI / 2;
      circle.position.set(sp[0], 0.05, sp[1]);
      circle.receiveShadow = true;
      this.root.add(circle);
    }

    buildTrack() {
      const t = DATA.landmarks.track;
      const pos = p2w(t.bx, t.by);
      const laneW = 7.4;
      const innerRx = (t.rx || 34.6);
      const innerRz = (t.rz || 67.6);
      const outerRx = innerRx + laneW, outerRz = innerRz + laneW;
      const rotY = (t.rot || 0) * Math.PI / 180;
      const trackMat = new THREE.MeshStandardMaterial({ color: 0xb96a55, roughness: 0.95 });
      const laneMat = new THREE.MeshBasicMaterial({ color: 0xf2efe4, transparent: true, opacity: 0.85 });
      const group = new THREE.Group();
      // 环形跑道底
      const ring = new THREE.Mesh(ellipseRing(innerRx, innerRz, outerRx, outerRz, 128), trackMat);
      ring.receiveShadow = true;
      group.add(ring);
      // 分道线
      for (let i = 0; i <= 6; i++) {
        const rx = innerRx + laneW * i / 6;
        const rz = innerRz + laneW * i / 6;
        const line = new THREE.Mesh(ellipseLine(rx, rz, 128, 0.11), laneMat);
        line.position.y = 0.03 + i * 0.001;
        group.add(line);
      }
      // 内场草坪
      const infieldMat = new THREE.MeshStandardMaterial({ color: 0x679a4c, roughness: 0.95 });
      const infield = new THREE.Mesh(ellipseDisc(innerRx, innerRz, 96), infieldMat);
      infield.position.y = 0.05;
      infield.receiveShadow = true;
      group.add(infield);
      // 足球场白线
      const pitchTex = canvasTex(512, 320, (ctx, w, h) => {
        ctx.clearRect(0, 0, w, h);
        ctx.strokeStyle = 'rgba(250,250,245,0.85)'; ctx.lineWidth = 3;
        const m = 18;
        ctx.strokeRect(m, m, w - 2 * m, h - 2 * m);
        ctx.beginPath(); ctx.moveTo(w / 2, m); ctx.lineTo(w / 2, h - m); ctx.stroke();
        ctx.beginPath(); ctx.arc(w / 2, h / 2, 32, 0, TAU); ctx.stroke();
        ctx.strokeRect(w / 2 - 55, h / 2 - 55, 110, 110);
        ctx.strokeRect(w / 2 - 26, h / 2 - 110, 52, 55);
        ctx.strokeRect(w / 2 - 26, h / 2 + 55, 52, 55);
      });
      const pitch = new THREE.Mesh(new THREE.PlaneGeometry(innerRx * 1.45, innerRz * 1.3),
        new THREE.MeshBasicMaterial({ map: pitchTex, transparent: true, opacity: 0.9, depthWrite: false }));
      pitch.rotation.x = -Math.PI / 2;
      pitch.position.y = 0.09;
      group.add(pitch);
      group.position.set(pos[0], 0.02, pos[1]);
      group.rotation.y = rotY;
      this.root.add(group);
      this.trackGroup = group;
    }

    buildCentralAxis() {
      // 中央水系石桥与礼仪轴铺装
      const axis = DATA.landmarks.plaza;
      const pos = p2w(axis.bx, axis.by);
      this.axisCenter = new THREE.Vector3(pos[0], 0, pos[1]);
      // 桥：跨越中央水系的拱桥
      const bridgeMat = new THREE.MeshStandardMaterial({ color: 0xd8cdb4, roughness: 0.9 });
      const bridge = new THREE.Group();
      const deck = new THREE.Mesh(new THREE.BoxGeometry(18, 1.0, 32), bridgeMat);
      deck.position.y = 1.6;
      bridge.add(deck);
      for (let i = -1; i <= 1; i += 2) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.1, 32), bridgeMat);
        rail.position.set(i * 8.5, 2.6, 0);
        bridge.add(rail);
      }
      for (let i = 0; i < 2; i++) {
        const arch = new THREE.Mesh(new THREE.TorusGeometry(8, 1.1, 6, 14, Math.PI), bridgeMat);
        arch.rotation.y = Math.PI / 2;
        arch.rotation.z = 0;
        arch.position.set(0, 1.2, -7 + i * 14);
        bridge.add(arch);
      }
      bridge.position.set(pos[0] + 6, 0, pos[1]);
      bridge.rotation.y = 0;
      bridge.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      this.root.add(bridge);
    }

    buildGates() {
      // 东门：门柱 + 校名石
      const e = DATA.landmarks.gate_E;
      const gp = p2w(e.bx, e.by);
      const gate = new THREE.Group();
      const stoneMat = new THREE.MeshStandardMaterial({ color: 0xcfc6ae, roughness: 0.9 });
      const pillarMat = new THREE.MeshStandardMaterial({ color: 0xe4ddcd, roughness: 0.85 });
      for (let i = -1; i <= 1; i += 2) {
        const p = new THREE.Mesh(new THREE.BoxGeometry(2.6, 9, 2.6), pillarMat);
        p.position.set(0, 4.5, i * 21);
        p.castShadow = true; p.receiveShadow = true;
        gate.add(p);
      }
      const beam = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 46), pillarMat);
      beam.position.y = 9.2;
      beam.castShadow = true;
      gate.add(beam);
      gate.position.set(gp[0], 0, gp[1]);
      gate.rotation.y = -Math.PI / 2;
      this.root.add(gate);

      // 校名石（东门内侧绿地，正反两面均有校名）
      const stonePos = p2w(982, 430);
      const stoneGroup = new THREE.Group();
      stoneGroup.position.set(stonePos[0], 0, stonePos[1]);
      stoneGroup.rotation.y = -Math.PI / 2 + 0.18;
      const stone = new THREE.Mesh(new THREE.BoxGeometry(13, 3.6, 2.6),
        new THREE.MeshStandardMaterial({ color: 0xb9ac90, roughness: 0.95 }));
      stone.position.y = 1.9;
      stone.castShadow = true; stone.receiveShadow = true;
      stoneGroup.add(stone);
      const base = new THREE.Mesh(new THREE.BoxGeometry(14.2, 0.5, 3.6),
        new THREE.MeshStandardMaterial({ color: 0xa89b80, roughness: 0.95 }));
      base.position.y = 0.25;
      base.receiveShadow = true;
      stoneGroup.add(base);
      const stoneTex = canvasTex(1024, 256, (ctx, w, h) => {
        ctx.fillStyle = '#b6a88b'; ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#7a3a2e';
        ctx.font = 'bold 92px "Microsoft YaHei", "PingFang SC", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('湖北国土资源职业学院', w / 2, h * 0.42);
        ctx.font = '28px Georgia, serif';
        ctx.fillStyle = '#6a3b32';
        ctx.fillText('HUBEI LAND RESOURCES VOCATIONAL COLLEGE', w / 2, h * 0.78);
      });
      for (let s = -1; s <= 1; s += 2) {
        const face = new THREE.Mesh(new THREE.PlaneGeometry(12.4, 3.1),
          new THREE.MeshStandardMaterial({ map: stoneTex, roughness: 0.9 }));
        face.position.set(0, 1.95, s * 1.32);
        face.rotation.y = s > 0 ? 0 : Math.PI;
        stoneGroup.add(face);
      }
      this.root.add(stoneGroup);

      // 南门（简化）
      const s = DATA.landmarks.gate_S;
      const sp = p2w(s.bx, s.by);
      const gate2 = new THREE.Group();
      for (let i = -1; i <= 1; i += 2) {
        const p = new THREE.Mesh(new THREE.BoxGeometry(1.8, 7, 1.8), pillarMat);
        p.position.set(i * 13, 3.5, 0); p.castShadow = true;
        gate2.add(p);
      }
      const signTex = canvasTex(512, 128, (ctx, w, h) => {
        ctx.fillStyle = '#e8e2d4'; ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#1f5f6b';
        ctx.font = 'bold 52px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('南 门', w / 2, h / 2);
      });
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(10, 2.5), new THREE.MeshBasicMaterial({ map: signTex }));
      sign.position.set(0, 8.4, 0);
      gate2.add(sign);
      gate2.position.set(sp[0], 0, sp[1]);
      gate2.rotation.y = 0.1;
      this.root.add(gate2);
    }

    buildLamps() {
      const lampPts = [];
      // 环形道路灯
      const boundary = GD.boundary;
      if (boundary) {
        for (let i = 0; i < boundary.length; i++) {
          const a = boundary[i], b = boundary[(i + 1) % boundary.length];
          const dx = b[0] - a[0], dz = b[1] - a[1];
          const len = Math.hypot(dx, dz);
          const n = Math.max(1, Math.floor(len / 34));
          for (let k = 0; k < n; k++) {
            const t = k / n;
            const x = a[0] + dx * t, z = a[1] + dz * t;
            const nx = dz / len, nz = -dx / len;
            // 只保留北/东侧，南侧留给河岸树
            if (nz > 0.2 && z > 100) continue;
            lampPts.push([x + nx * 16 + (i % 2), z + nz * 16]);
          }
        }
      }
      // 中央轴线灯
      for (let i = -5; i <= 5; i++) {
        if (i === 0) continue;
        lampPts.push([(760 - 572) * S + i * (i > 0 ? 1 : 1) * 28, (452 - 486) * S + i * 30]);
      }
      const poleGeo = new THREE.CylinderGeometry(0.14, 0.2, 7.5, 5);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0x4a4f52, roughness: 0.7, metalness: 0.4 });
      const headGeo = new THREE.SphereGeometry(0.42, 8, 6);
      const headMat = new THREE.MeshStandardMaterial({
        color: 0xfff3d0, emissive: 0xffcf7a, emissiveIntensity: 0.0, roughness: 0.4
      });
      this.lampHeadMat = headMat;
      const poles = new THREE.InstancedMesh(poleGeo, poleMat, lampPts.length);
      const heads = new THREE.InstancedMesh(headGeo, headMat, lampPts.length);
      const dummy = new THREE.Object3D();
      for (let i = 0; i < lampPts.length; i++) {
        dummy.position.set(lampPts[i][0], 3.75, lampPts[i][1]);
        dummy.rotation.set(0, 0, 0); dummy.scale.set(1, 1, 1);
        dummy.updateMatrix(); poles.setMatrixAt(i, dummy.matrix);
        dummy.position.set(lampPts[i][0], 7.6, lampPts[i][1]);
        dummy.updateMatrix(); heads.setMatrixAt(i, dummy.matrix);
      }
      poles.castShadow = true;
      this.root.add(poles); this.root.add(heads);

      // 夜间灯晕（Points + 加法混合）
      const glowTex = canvasTex(64, 64, (ctx, w, h) => {
        const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
        g.addColorStop(0, 'rgba(255,224,160,0.9)');
        g.addColorStop(0.35, 'rgba(255,200,110,0.35)');
        g.addColorStop(1, 'rgba(255,180,80,0)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      });
      const pos = new Float32Array(lampPts.length * 3);
      for (let i = 0; i < lampPts.length; i++) {
        pos[i * 3] = lampPts[i][0]; pos[i * 3 + 1] = 7.6; pos[i * 3 + 2] = lampPts[i][1];
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      const mat = new THREE.PointsMaterial({
        size: 12, map: glowTex, transparent: true, depthWrite: false,
        blending: THREE.AdditiveBlending, opacity: 0.0, sizeAttenuation: true
      });
      this.lampGlow = new THREE.Points(geo, mat);
      this.root.add(this.lampGlow);
    }

    buildFlagsAndStone() {
      // 旗杆与校旗（东门广场）
      const p = p2w(905, 470);
      const poleMat = new THREE.MeshStandardMaterial({ color: 0xd8d8d2, metalness: 0.7, roughness: 0.35 });
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.22, 24, 10), poleMat);
      pole.position.set(p[0], 12, p[1]);
      pole.castShadow = true;
      this.root.add(pole);
      const flagTex = canvasTex(256, 160, (ctx, w, h) => {
        ctx.fillStyle = '#1f5f73'; ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 3;
        ctx.strokeRect(10, 10, w - 20, h - 20);
        ctx.fillStyle = '#f2e7c8';
        ctx.font = 'bold 30px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('湖北国土资源', w / 2, h / 2 - 16);
        ctx.fillText('职业学院', w / 2, h / 2 + 20);
      });
      const flagGeo = new THREE.PlaneGeometry(9, 5.6, 20, 8);
      const flagMat = new THREE.MeshStandardMaterial({
        map: flagTex, side: THREE.DoubleSide, roughness: 0.85
      });
      const flag = new THREE.Mesh(flagGeo, flagMat);
      flag.position.set(p[0] + 4.8, 20.5, p[1]);
      this.flagUniformTime = { value: 0 };
      flagMat.onBeforeCompile = (shader) => {
        shader.uniforms.uTime = this.flagUniformTime;
        shader.vertexShader = shader.vertexShader.replace(
          '#include <begin_vertex>',
          `#include <begin_vertex>
           float wave = sin(position.x * 0.85 + uTime * 4.0) * 0.28 + sin(position.x * 1.7 - uTime * 2.6) * 0.12;
           transformed.z += wave * (position.x + 4.5) * 0.16;
           transformed.y += sin(position.x * 0.6 + uTime * 3.0) * 0.07 * (position.x + 4.5) * 0.1;`
        );
        shader.vertexShader = 'uniform float uTime;\n' + shader.vertexShader;
      };
      this.root.add(flag);
      this.flag = flag;
    }

    buildParking() {
      const p = DATA.landmarks.parking;
      const c = p2w(p.bx, p.by);
      const cars = [];
      const colors = [0xdfe3e6, 0x3b4b5c, 0x9e2f2f, 0x2f4a63, 0xd8c9a5, 0x546a57];
      for (let i = 0; i < 6; i++) {
        const car = this.makeCar(colors[i % colors.length]);
        const row = i % 2, col = Math.floor(i / 2);
        car.position.set(c[0] - 18 + row * 15, 0, c[1] - 18 + col * 9);
        car.rotation.y = -Math.PI / 2 + 0.08;
        car.userData.parked = true;
        this.root.add(car);
      }
    }

    /* ================= 地铁 16 号线 ================= */
    buildMetro() {
      const z = -560;
      const g = new THREE.Group();
      const concrete = new THREE.MeshStandardMaterial({ color: 0xb9b9b2, roughness: 0.9 });
      const railMat = new THREE.MeshStandardMaterial({ color: 0x8d9196, metalness: 0.6, roughness: 0.5 });
      const deck = new THREE.Mesh(new THREE.BoxGeometry(1900, 1.6, 9.4), concrete);
      deck.position.set(0, 10.8, z);
      deck.castShadow = true; deck.receiveShadow = true;
      g.add(deck);
      for (let i = -5; i <= 5; i++) {
        const pier = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.5, 10, 8), concrete);
        pier.position.set(i * 85 + 10, 5, z);
        pier.castShadow = true;
        g.add(pier);
      }
      for (let i = -1; i <= 1; i += 2) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(1900, 0.5, 1.2), railMat);
        rail.position.set(0, 11.9, z + i * 2.6);
        g.add(rail);
      }
      // 湾湖站
      const st = DATA.landmarks.metroStation;
      const station = new THREE.Group();
      const platMat = new THREE.MeshStandardMaterial({ color: 0xdedbd2, roughness: 0.85 });
      const platform = new THREE.Mesh(new THREE.BoxGeometry(110, 1.4, 26), platMat);
      platform.position.y = 12.2;
      station.add(platform);
      const roof = new THREE.Mesh(new THREE.BoxGeometry(120, 1.0, 32),
        new THREE.MeshStandardMaterial({ color: 0xe8e6df, roughness: 0.8 }));
      roof.position.y = 24;
      station.add(roof);
      for (let i = -3; i <= 3; i++) {
        const col = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 11, 8),
          new THREE.MeshStandardMaterial({ color: 0xcfcfc8, roughness: 0.7 }));
        col.position.set(i * 17, 18.5, 0);
        station.add(col);
      }
      const stationTex = canvasTex(512, 128, (ctx, w, h) => {
        ctx.fillStyle = '#f0ede4'; ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#1f5f73';
        ctx.font = 'bold 64px "Microsoft YaHei", sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('湾 湖 站', w / 2, h * 0.45);
        ctx.font = '24px Georgia, serif';
        ctx.fillStyle = '#4a6b72';
        ctx.fillText('WANHU  STATION', w / 2, h * 0.8);
      });
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(34, 8.5),
        new THREE.MeshBasicMaterial({ map: stationTex, side: THREE.DoubleSide }));
      sign.position.set(0, 17, 16.2);
      station.add(sign);
      station.position.set(st.x, 0, st.z + 6);
      station.rotation.y = 0;
      g.add(station);
      // 列车（4 节）
      this.train = new THREE.Group();
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf2f2ee, roughness: 0.5, metalness: 0.15 });
      const stripeMat = new THREE.MeshStandardMaterial({ color: 0x1f6f7a, roughness: 0.6 });
      const winMat = new THREE.MeshStandardMaterial({
        color: 0x2a3e46, roughness: 0.2, metalness: 0.6,
        emissive: 0xffe6a8, emissiveIntensity: 0.0
      });
      this.trainWindows = winMat;
      for (let i = 0; i < 4; i++) {
        const car = new THREE.Group();
        const body = new THREE.Mesh(new THREE.BoxGeometry(22, 3.2, 3.4), bodyMat);
        body.position.y = 13.7;
        car.add(body);
        const stripe = new THREE.Mesh(new THREE.BoxGeometry(22.1, 0.45, 3.45), stripeMat);
        stripe.position.y = 14.7;
        car.add(stripe);
        const win = new THREE.Mesh(new THREE.BoxGeometry(22.05, 1.1, 3.45), winMat);
        win.position.y = 15.1;
        car.add(win);
        car.position.x = i * 23.4 - 35;
        this.train.add(car);
      }
      this.train.position.set(-300, 0, z);
      g.add(this.train);
      g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      this.root.add(g);
      this.metroGroup = g;
    }

    /* ================= 远景城市 ================= */
    buildDistantCity() {
      const group = new THREE.Group();
      const geo = new THREE.BoxGeometry(1, 1, 1);
      const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 });
      const n = 44;
      const inst = new THREE.InstancedMesh(geo, mat, n);
      const dummy = new THREE.Object3D();
      const col = new THREE.Color();
      let idx = 0;
      const rng = mulberry32(20241018);
      for (let i = 0; i < n; i++) {
        // 远处城市与厂区（北侧、东侧两组，其余留给田野与林带）
        let x, z;
        const r = rng();
        if (r < 0.55) { x = -520 + rng() * 1000; z = -1450 - rng() * 550; }
        else { x = 1350 + rng() * 550; z = -280 + rng() * 900; }
        const w = 24 + rng() * 55, d = 24 + rng() * 55, h = 9 + rng() * 26;
        dummy.position.set(x, h / 2, z);
        dummy.rotation.set(0, rng() * TAU, 0);
        dummy.scale.set(w, h, d);
        dummy.updateMatrix();
        inst.setMatrixAt(idx, dummy.matrix);
        const shade = 0.48 + rng() * 0.22;
        col.setRGB(0.52 * shade, 0.55 * shade, 0.55 * shade);
        inst.setColorAt(idx, col);
        idx++;
      }
      inst.count = idx;
      inst.castShadow = false; inst.receiveShadow = false;
      group.add(inst);
      this.city = group;
      this.root.add(group);
    }

    /* ================= 人物 ================= */
    makePerson(colors) {
      const g = new THREE.Group();
      const bodyMat = new THREE.MeshLambertMaterial({ color: colors.body });
      const skinMat = new THREE.MeshLambertMaterial({ color: 0xe6c6a8 });
      const legMat = new THREE.MeshLambertMaterial({ color: colors.legs });
      const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.55, 3, 6), bodyMat);
      body.position.y = 1.15;
      g.add(body);
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), skinMat);
      head.position.y = 1.72;
      g.add(head);
      const legL = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.72, 0.18), legMat);
      legL.position.set(-0.14, 0.36, 0);
      g.add(legL);
      const legR = legL.clone();
      legR.position.x = 0.14;
      g.add(legR);
      g.userData.legL = legL; g.userData.legR = legR;
      g.traverse(o => { if (o.isMesh) o.castShadow = true; });
      return g;
    }

    buildPeople() {
      const routes = [
        // 中央轴线（西南 → 东北）
        [[600, 560], [640, 520], [680, 480], [740, 460], [820, 455], [900, 452], [960, 452]],
        // 生活区小径
        [[500, 120], [470, 160], [430, 210], [380, 260], [330, 320], [300, 380], [270, 440]],
        // 运动区
        [[400, 500], [360, 560], [320, 620], [290, 700], [330, 760], [400, 780], [470, 740], [500, 660], [480, 580]],
        // 图文中心前广场
        [[700, 430], [760, 445], [820, 452], [870, 430], [900, 390], [880, 350], [820, 350], [770, 380], [720, 400]]
      ];
      const colors = [
        { body: 0x33506b, legs: 0x2b2f38 },
        { body: 0xa8483c, legs: 0x33353c },
        { body: 0x4f7d5c, legs: 0x3a3d44 },
        { body: 0xd9c27a, legs: 0x343b42 },
        { body: 0x7b6f9e, legs: 0x2f3239 },
        { body: 0xe4e0d6, legs: 0x50555c }
      ];
      let n = 0;
      for (let r = 0; r < routes.length; r++) {
        const route = routes[r].map(p => {
          const w = p2w(p[0], p[1]);
          return new THREE.Vector3(w[0], 0, w[1]);
        });
        const count = r === 0 ? 6 : 4;
        for (let i = 0; i < count; i++) {
          const person = this.makePerson(colors[(n + i) % colors.length]);
          person.userData.route = route;
          person.userData.progress = (i / count + r * 0.17) % 1;
          person.userData.speed = 0.012 + Math.random() * 0.012;
          person.userData.dir = Math.random() > 0.5 ? 1 : -1;
          this.root.add(person);
          this.people.push(person);
          n++;
        }
      }
    }

    makeCar(color) {
      const g = new THREE.Group();
      const bodyMat = new THREE.MeshStandardMaterial({ color, roughness: 0.35, metalness: 0.35 });
      const glassMat = new THREE.MeshStandardMaterial({ color: 0x2a3b45, roughness: 0.15, metalness: 0.5 });
      const tireMat = new THREE.MeshStandardMaterial({ color: 0x1d1f22, roughness: 0.95 });
      const body = new THREE.Mesh(new THREE.BoxGeometry(4.4, 0.8, 1.9), bodyMat);
      body.position.y = 0.72;
      g.add(body);
      const cabin = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.7, 1.7), glassMat);
      cabin.position.set(-0.15, 1.38, 0);
      g.add(cabin);
      for (let i = -1; i <= 1; i += 2) {
        for (let j = -1; j <= 1; j += 2) {
          const w = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.3, 10), tireMat);
          w.rotation.z = Math.PI / 2;
          w.position.set(i * 1.45, 0.36, j * 0.88);
          g.add(w);
        }
      }
      const lightMat = new THREE.MeshStandardMaterial({
        color: 0xfff4d0, emissive: 0xffd27a, emissiveIntensity: 0.2
      });
      this.carLightMats = this.carLightMats || [];
      for (let i = -1; i <= 1; i += 2) {
        const l = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.22, 0.32), lightMat);
        l.position.set(2.2, 0.72, i * 0.6);
        g.add(l);
      }
      this.carLightMats.push(lightMat);
      g.traverse(o => { if (o.isMesh) { o.castShadow = true; } });
      return g;
    }

    buildCars() {
      // 环绕校园的环路（边界外 27m）
      const boundary = GD.boundary;
      if (!boundary || boundary.length < 3) return;
      const ccx = boundary.reduce((a, p) => a + p[0], 0) / boundary.length;
      const ccz = boundary.reduce((a, p) => a + p[1], 0) / boundary.length;
      const ring = boundary.map(p => {
        const dx = p[0] - ccx, dz = p[1] - ccz;
        const l = Math.hypot(dx, dz) || 1;
        return new THREE.Vector3(p[0] + dx / l * 27, 0, p[1] + dz / l * 27);
      });
      // 平滑
      const path = [];
      for (let i = 0; i < ring.length; i++) {
        const a = ring[(i - 1 + ring.length) % ring.length];
        const b = ring[i];
        const c = ring[(i + 1) % ring.length];
        path.push(new THREE.Vector3((a.x + b.x * 2 + c.x) / 4, 0, (a.z + b.z * 2 + c.z) / 4));
      }
      this.carPath = path;
      const colors = [0xe8e8e4, 0x2f4358, 0x8f2f2f, 0x374c3c, 0xc9b98f];
      for (let i = 0; i < 5; i++) {
        const car = this.makeCar(colors[i % colors.length]);
        car.userData.progress = i / 5;
        car.userData.speed = 0.0035 + Math.random() * 0.002;
        car.userData.path = path;
        this.root.add(car);
        this.cars.push(car);
      }
    }

    buildBirds() {
      // 简化：远景飞鸟在低帧率设备上容易变成黑色噪点，改为不展示
      this.birds = [];
    }

    buildFireflies() {
      const count = 220;
      const base = new Float32Array(count * 3);
      const seed = new Float32Array(count);
      const rng = mulberry32(4242);
      // 集中在中央水系与马影河岸边
      const spots = [
        [p2w(760, 470), 60, 55], [p2w(500, 760), 90, 70], [p2w(900, 740), 110, 55], [p2w(1000, 300), 70, 45]
      ];
      for (let i = 0; i < count; i++) {
        const s = spots[i % spots.length];
        base[i * 3] = s[0][0] + (rng() - 0.5) * s[1];
        base[i * 3 + 1] = 1 + rng() * 4;
        base[i * 3 + 2] = s[0][1] + (rng() - 0.5) * s[2];
        seed[i] = rng() * 10;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute('position', new THREE.BufferAttribute(base, 3));
      geo.setAttribute('seed', new THREE.BufferAttribute(seed, 1));
      this.fireflyBase = base;
      const tex = canvasTex(32, 32, (ctx, w, h) => {
        const g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2);
        g.addColorStop(0, 'rgba(255,240,170,1)');
        g.addColorStop(0.4, 'rgba(220,255,150,0.4)');
        g.addColorStop(1, 'rgba(160,255,120,0)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
      });
      const mat = new THREE.PointsMaterial({
        size: 1.6, map: tex, transparent: true, opacity: 0, depthWrite: false,
        blending: THREE.AdditiveBlending, sizeAttenuation: true
      });
      this.fireflyMat = mat;
      this.fireflies = new THREE.Points(geo, mat);
      this.root.add(this.fireflies);
    }

    /* ================= 昼夜 ================= */
    setNight(n) {
      this.night = clamp(n, 0, 1);
      const n1 = this.night;
      // 灯光
      this.sun.intensity = lerp(3.1, 0.0, n1);
      this.sun.color.setRGB(1.0, lerp(0.89, 0.5, n1), lerp(0.72, 0.42, n1));
      this.moon.intensity = lerp(0.0, 0.5, n1);
      this.hemi.intensity = lerp(1.05, 0.24, n1);
      this.hemi.color.setRGB(lerp(0.83, 0.16, n1), lerp(0.90, 0.21, n1), lerp(0.95, 0.34, n1));
      this.hemi.groundColor.setRGB(lerp(0.44, 0.06, n1), lerp(0.48, 0.08, n1), lerp(0.33, 0.1, n1));
      this.ambient.intensity = lerp(0.14, 0.24, n1);
      this.ambient.color.setHex(n1 > 0.5 ? 0x3d5170 : 0xfff6ea);
      if (this.renderer) this.renderer.toneMappingExposure = lerp(1.08, 1.32, n1);
      // 天空
      const u = this.skyUniforms;
      u.uNight.value = n1;
      u.uTop.value.setRGB(lerp(0.30, 0.010, n1), lerp(0.57, 0.020, n1), lerp(0.80, 0.055, n1));
      u.uHorizon.value.setRGB(lerp(1.0, 0.05, n1), lerp(0.87, 0.07, n1), lerp(0.70, 0.13, n1));
      u.uBottom.value.setRGB(lerp(0.80, 0.015, n1), lerp(0.82, 0.025, n1), lerp(0.70, 0.050, n1));
      u.uSunColor.value.setRGB(lerp(1.0, 0.34, n1), lerp(0.80, 0.42, n1), lerp(0.55, 0.66, n1));
      // 水面
      this.waterUniforms.uNight.value = n1;
      this.waterUniforms.uSky.value.setRGB(lerp(0.72, 0.03, n1), lerp(0.85, 0.05, n1), lerp(0.90, 0.10, n1));
      this.waterUniforms.uDeep.value.setRGB(lerp(0.045, 0.007, n1), lerp(0.18, 0.030, n1), lerp(0.24, 0.058, n1));
      this.waterUniforms.uShallow.value.setRGB(lerp(0.18, 0.025, n1), lerp(0.40, 0.060, n1), lerp(0.46, 0.095, n1));
      // 雾
      if (!this.fog) {
        this.fog = new THREE.FogExp2(0xdde7d8, 0.00036);
        this.scene.fog = this.fog;
      }
      this.fog.color.setRGB(lerp(0.91, 0.032, n1), lerp(0.90, 0.045, n1), lerp(0.80, 0.085, n1));
      this.fog.density = lerp(0.00034, 0.00050, n1);
      if (this.waterUniforms) {
        this.waterUniforms.uFogColor.value.copy(this.fog.color);
        this.waterUniforms.uFogDensity.value = this.fog.density;
      }
      // 夜景元素
      this.lampHeadMat.emissiveIntensity = lerp(0.0, 2.6, n1);
      this.lampGlow.material.opacity = lerp(0.0, 1.0, n1);
      this.fireflyMat.opacity = lerp(0.0, 0.9, n1);
      if (this.trainWindows) this.trainWindows.emissiveIntensity = lerp(0.0, 1.8, n1);
      if (this.carLightMats) for (const m of this.carLightMats) m.emissiveIntensity = lerp(0.15, 2.2, n1);
      if (this.cloudMat) this.cloudMat.opacity = lerp(0.45, 0.12, n1);
      // 建筑窗户
      for (const g of this.buildingGroups) {
        try {
          if (g.userData && typeof g.userData.setNight === 'function') g.userData.setNight(n1);
          if (g.userData && g.userData.nightWindows) {
            for (const m of g.userData.nightWindows) {
              if (m && m.emissiveIntensity !== undefined) m.emissiveIntensity = lerp(0.0, 1.0, n1);
            }
          }
        } catch (e) { console.warn('setNight building failed', e); }
      }
      // 光照方向：白天为西南向暖阳，夜晚抬高为月光
      const dayDir = new THREE.Vector3(-0.66, 0.46, 0.32).normalize();
      const nightDir = new THREE.Vector3(-0.22, 0.86, -0.1).normalize();
      const sunDir = dayDir.clone().lerp(nightDir, n1).normalize();
      this.skyUniforms.uSunDir.value.copy(sunDir);
      this.waterUniforms.uSunDir.value.copy(sunDir);
      this.sun.position.copy(sunDir).multiplyScalar(680);
      this.sunTarget.position.set(0, 0, 0);
    }

    /* ================= 每帧更新 ================= */
    update(dt, elapsed) {
      this.time = elapsed;
      this.skyUniforms.uTime.value = elapsed;
      this.waterUniforms.uTime.value = elapsed;
      this.flagUniformTime.value = elapsed;
      // 云漂移
      for (const c of this.clouds.children) {
        c.position.x += c.userData.drift * dt * 60;
        if (c.position.x > 1500) c.position.x = -1500;
        c.lookAt(0, c.position.y, 0);
      }
      // 太阳光晕随时间轻微变化
      // 人物
      for (const p of this.people) {
        const route = p.userData.route;
        p.userData.progress += p.userData.speed * dt * p.userData.dir;
        if (p.userData.progress > 1) p.userData.progress -= 1;
        if (p.userData.progress < 0) p.userData.progress += 1;
        const t = p.userData.progress * (route.length - 1);
        const i = Math.floor(t), f = t - i;
        const a = route[i], b = route[Math.min(route.length - 1, i + 1)];
        const x = a.x + (b.x - a.x) * f;
        const z = a.z + (b.z - a.z) * f;
        p.position.set(x, 0, z);
        const ang = Math.atan2(b.x - a.x, b.z - a.z);
        p.rotation.y = ang + (p.userData.dir < 0 ? Math.PI : 0);
        const swing = Math.sin(elapsed * 7 + p.userData.progress * 30) * 0.38;
        p.userData.legL.rotation.x = swing;
        p.userData.legR.rotation.x = -swing;
        p.position.y = Math.abs(Math.sin(elapsed * 7 + p.userData.progress * 30)) * 0.04;
      }
      // 车辆
      for (const car of this.cars) {
        const path = car.userData.path;
        car.userData.progress = (car.userData.progress + car.userData.speed * dt) % 1;
        const t = car.userData.progress * (path.length - 1);
        const i = Math.floor(t), f = t - i;
        const a = path[i], b = path[Math.min(path.length - 1, i + 1)];
        car.position.set(a.x + (b.x - a.x) * f, 0, a.z + (b.z - a.z) * f);
        car.rotation.y = Math.atan2(b.x - a.x, b.z - a.z);
      }
      // 列车
      if (this.train) {
        this.train.position.x = ((elapsed * 26) % 2200) - 1100;
      }
      // 鸟
      for (const b of this.birds) {
        const ph = elapsed * b.userData.speed + b.userData.phase;
        b.position.set(
          b.userData.cx + Math.cos(ph) * b.userData.radius,
          b.userData.height + Math.sin(ph * 1.7) * 8,
          b.userData.cz + Math.sin(ph) * b.userData.radius * 0.8
        );
        b.rotation.y = -ph + Math.PI / 2;
        b.children[0].rotation.z = 0.25 + Math.sin(elapsed * 6 + b.userData.phase) * 0.35;
        b.children[1].rotation.z = -0.25 - Math.sin(elapsed * 6 + b.userData.phase) * 0.35;
      }
      // 萤火虫
      if (this.fireflyMat.opacity > 0.01) {
        const pos = this.fireflies.geometry.attributes.position;
        const base = this.fireflyBase;
        for (let i = 0; i < pos.count; i++) {
          const s = this.fireflies.geometry.attributes.seed.array[i];
          pos.array[i * 3] = base[i * 3] + Math.sin(elapsed * 0.6 + s) * 2.2;
          pos.array[i * 3 + 1] = base[i * 3 + 1] + Math.sin(elapsed * 0.9 + s * 2) * 0.8;
          pos.array[i * 3 + 2] = base[i * 3 + 2] + Math.cos(elapsed * 0.5 + s) * 2.2;
        }
        pos.needsUpdate = true;
        this.fireflyMat.opacity = 0.55 + 0.35 * Math.sin(elapsed * 1.3);
      }
      // 泛光平面跟随太阳
      this.waterUniforms.uSunDir.value.copy(this.skyUniforms.uSunDir.value);
    }

    /* 高亮建筑 */
    highlight(poiId) {
      for (const g of this.buildingGroups) {
        const hit = g.userData.poiId === poiId;
        g.traverse(o => {
          if (o.isMesh && o.material) {
            if (!o.userData._baseEmissive && o.material.emissive) {
              o.userData._baseEmissive = o.material.emissive.getHex();
              o.userData._baseEmissiveIntensity = o.material.emissiveIntensity || 0;
            }
            if (hit && o.material.emissive) {
              o.material.emissive.setHex(0x334c2a);
              o.material.emissiveIntensity = 0.55;
            } else if (o.material.emissive && o.userData._baseEmissive !== undefined) {
              o.material.emissive.setHex(o.userData._baseEmissive);
              o.material.emissiveIntensity = o.userData._baseEmissiveIntensity;
            }
          }
        });
      }
    }
  }

  /* ---------------- 几何辅助 ---------------- */
  function ellipseRing(rix, riz, rox, roz, seg) {
    const positions = [], indices = [];
    for (let i = 0; i <= seg; i++) {
      const a = i / seg * TAU;
      const ca = Math.cos(a), sa = Math.sin(a);
      positions.push(rox * ca, 0, roz * sa);
      positions.push(rix * ca, 0, riz * sa);
    }
    for (let i = 0; i < seg; i++) {
      const a = i * 2, b = i * 2 + 1, c = i * 2 + 2, d = i * 2 + 3;
      indices.push(a, b, c, b, d, c);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return geo;
  }
  function ellipseLine(rx, rz, seg, width) {
    const positions = [], indices = [];
    for (let i = 0; i <= seg; i++) {
      const a = i / seg * TAU;
      const ca = Math.cos(a), sa = Math.sin(a);
      positions.push((rx) * ca, 0, (rz) * sa);
      positions.push((rx - width) * ca, 0, (rz - width) * sa);
    }
    for (let i = 0; i < seg; i++) {
      const a = i * 2, b = i * 2 + 1, c = i * 2 + 2, d = i * 2 + 3;
      indices.push(a, b, c, b, d, c);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setIndex(indices);
    return geo;
  }
  function ellipseDisc(rx, rz, seg) {
    const positions = [0, 0, 0], indices = [];
    for (let i = 0; i <= seg; i++) {
      const a = i / seg * TAU;
      positions.push(rx * Math.cos(a), 0, rz * Math.sin(a));
    }
    for (let i = 1; i <= seg; i++) indices.push(0, i, i + 1);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geo.setIndex(indices);
    geo.computeVertexNormals();
    return geo;
  }
  function mulberry32(a) {
    return function () {
      a |= 0; a = a + 0x6D2B79F5 | 0;
      let t = Math.imul(a ^ a >>> 15, 1 | a);
      t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  window.CampusScene = { create: CampusWorld.create.bind(CampusWorld), p2w: p2w, palette: PALETTE, CampusWorld };
})();
