/* =========================================================================
 * 湖北国土资源职业学院 · 三维校园
 * app.js — 相机控制 / 交互 / 导览 / 昼夜 / UI / 渲染循环
 * ========================================================================= */
(function () {
  'use strict';
  const DATA = window.CAMPUS_DATA;
  const GD = window.GROUND_DATA;
  const S = GD.S, CX = GD.CX, CZ = GD.CZ;
  const $ = (id) => document.getElementById(id);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const easeInOutCubic = (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const TAU = Math.PI * 2;
  const p2w = window.CampusScene.p2w;
  const params = new URLSearchParams(location.search);
  const SHOT = params.has('shot');
  const HIDE_UI = params.has('hideui');

  // 记录运行时错误，便于自动化检查
  window.addEventListener('error', (ev) => {
    try {
      document.body.dataset.lastError = (ev.message || 'error') + ' @' +
        (ev.filename || '') + ':' + (ev.lineno || 0) + ':' + (ev.colno || 0);
    } catch (e) {}
  });
  window.addEventListener('unhandledrejection', (ev) => {
    try {
      document.body.dataset.lastRejection = String(ev.reason);
    } catch (e) {}
  });

  /* ---------------- 全局状态 ---------------- */
  const state = {
    ready: false,
    intro: false,
    introStart: 0,
    night: 0,
    nightTarget: 0,
    autoCycle: false,
    autoTimer: 0,
    activePoi: null,
    hoverPoi: null,
    labelsOn: true,
    tour: { active: false, playing: false, index: 0, progress: 0, stay: 0, flying: false },
    pointerDown: null,
    dragging: false,
    moved: 0,
    fps: 60,
    quality: 1
  };

  /* ---------------- 渲染器 / 场景 ---------------- */
  const container = $('canvas-wrap');
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  } catch (e) {
    showFatal('当前浏览器无法创建 WebGL 渲染环境，请使用新版 Chrome / Edge 浏览器。');
    return;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.id = 'scene-canvas';
  container.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x0a1a22);
  const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.6, 7000);

  /* ---------------- 轨道控制 ---------------- */
  class Orbit {
    constructor(cam, dom) {
      this.camera = cam;
      this.dom = dom;
      this.target = new THREE.Vector3(30, 4, 10);
      this.distance = 820;
      this.azimuth = 0.48;
      this.elevation = 0.40;
      this.goal = {
        target: this.target.clone(), distance: this.distance,
        azimuth: this.azimuth, elevation: this.elevation
      };
      this.tween = null;
      this.minDist = 38; this.maxDist = 1900;
      this.minElev = 0.07; this.maxElev = 1.36;
      this.pointers = new Map();
      this.pinchDist = 0;
      this.bind();
    }
    bind() {
      const dom = this.dom;
      dom.style.touchAction = 'none';
      dom.addEventListener('contextmenu', (e) => e.preventDefault());
      dom.addEventListener('pointerdown', (e) => {
        dom.setPointerCapture && dom.setPointerCapture(e.pointerId);
        this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY, button: e.button });
        if (this.pointers.size === 1) {
          state.pointerDown = { x: e.clientX, y: e.clientY, t: performance.now(), moved: 0 };
          state.moved = 0;
          state.dragging = true;
          if (state.tour.active && state.tour.playing) pauseTour();
        }
        if (this.pointers.size === 2) {
          const pts = Array.from(this.pointers.values());
          this.pinchDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
        }
        this.tween = null;
      });
      dom.addEventListener('pointermove', (e) => {
        if (!this.pointers.has(e.pointerId)) {
          onHover(e);
          return;
        }
        const prev = this.pointers.get(e.pointerId);
        const dx = e.clientX - prev.x;
        const dy = e.clientY - prev.y;
        prev.x = e.clientX; prev.y = e.clientY;
        if (state.pointerDown) {
          state.moved = Math.max(state.moved,
            Math.hypot(e.clientX - state.pointerDown.x, e.clientY - state.pointerDown.y));
        }
        if (this.pointers.size === 2) {
          const pts = Array.from(this.pointers.values());
          const nd = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
          if (this.pinchDist > 0) this.zoom((this.pinchDist - nd) * 2.4);
          this.pinchDist = nd;
          return;
        }
        const btn = prev.button;
        if (btn === 2 || btn === 1) {
          this.pan(dx, dy);
        } else {
          this.rotate(dx, dy);
        }
      });
      const end = (e) => {
        const wasDown = this.pointers.has(e.pointerId);
        this.pointers.delete(e.pointerId);
        if (this.pointers.size < 2) this.pinchDist = 0;
        if (!wasDown) return;
        if (state.pointerDown && state.moved < 7 && performance.now() - state.pointerDown.t < 420) {
          pickAt(e.clientX, e.clientY);
        }
        if (this.pointers.size === 0) {
          state.dragging = false;
          state.pointerDown = null;
        }
      };
      dom.addEventListener('pointerup', end);
      dom.addEventListener('pointercancel', end);
      dom.addEventListener('pointerleave', (e) => { if (!this.pointers.size) hideTooltip(); });
      dom.addEventListener('wheel', (e) => {
        e.preventDefault();
        this.zoom(e.deltaY * 0.55);
        if (state.tour.active && state.tour.playing) pauseTour();
      }, { passive: false });
    }
    rotate(dx, dy) {
      this.goal.azimuth -= dx * 0.0042;
      this.goal.elevation = clamp(this.goal.elevation + dy * 0.0032, this.minElev, this.maxElev);
    }
    pan(dx, dy) {
      const factor = this.goal.distance * 0.0016;
      const az = this.goal.azimuth;
      const right = new THREE.Vector3(Math.cos(az), 0, -Math.sin(az));
      const fwd = new THREE.Vector3(Math.sin(az), 0, Math.cos(az));
      this.goal.target.addScaledVector(right, -dx * factor);
      this.goal.target.addScaledVector(fwd, dy * factor);
      this.goal.target.x = clamp(this.goal.target.x, -760, 760);
      this.goal.target.z = clamp(this.goal.target.z, -660, 660);
      this.goal.target.y = clamp(this.goal.target.y, 0, 160);
    }
    zoom(delta) {
      this.goal.distance = clamp(this.goal.distance * Math.exp(delta * 0.0012), this.minDist, this.maxDist);
    }
    flyTo(opts, duration) {
      const from = {
        target: this.target.clone(), distance: this.distance,
        azimuth: this.azimuth, elevation: this.elevation
      };
      const to = {
        target: opts.target ? opts.target.clone() : this.target.clone(),
        distance: opts.distance !== undefined ? opts.distance : this.distance,
        azimuth: opts.azimuth !== undefined ? opts.azimuth : this.azimuth,
        elevation: opts.elevation !== undefined ? opts.elevation : this.elevation
      };
      if (opts.azimuth === undefined) {
        // choose the shorter rotation path
      } else {
        while (to.azimuth - this.azimuth > Math.PI) to.azimuth -= TAU;
        while (to.azimuth - this.azimuth < -Math.PI) to.azimuth += TAU;
      }
      this.tween = { from, to, t: 0, dur: duration || 2.2 };
      this.goal.target.copy(to.target);
      this.goal.distance = to.distance;
      this.goal.azimuth = to.azimuth;
      this.goal.elevation = to.elevation;
    }
    update(dt) {
      if (this.tween) {
        this.tween.t += dt;
        const k = easeInOutCubic(clamp(this.tween.t / this.tween.dur, 0, 1));
        const f = this.tween.from, t = this.tween.to;
        this.target.lerpVectors(f.target, t.target, k);
        this.distance = lerp(f.distance, t.distance, k);
        this.azimuth = lerp(f.azimuth, t.azimuth, k);
        this.elevation = lerp(f.elevation, t.elevation, k);
        if (this.tween.t >= this.tween.dur) {
          this.tween = null;
          if (state.tour.active && !state.tour.flying) { /* noop */ }
        }
      } else {
        const damp = 1 - Math.exp(-dt * 9);
        this.target.lerp(this.goal.target, damp);
        this.distance += (this.goal.distance - this.distance) * damp;
        this.azimuth += (this.goal.azimuth - this.azimuth) * damp;
        this.elevation += (this.goal.elevation - this.elevation) * damp;
      }
      const ce = Math.cos(this.elevation), se = Math.sin(this.elevation);
      const pos = new THREE.Vector3(
        this.target.x + Math.sin(this.azimuth) * ce * this.distance,
        this.target.y + se * this.distance,
        this.target.z + Math.cos(this.azimuth) * ce * this.distance
      );
      this.camera.position.copy(pos);
      this.camera.lookAt(this.target);
    }
  }
  const controls = new Orbit(camera, renderer.domElement);

  /* ---------------- 相机预设 ---------------- */
  const VIEWS = {
    overview: { target: new THREE.Vector3(25, 2, 30), distance: 660, azimuth: 0.55, elevation: 0.34 },
    gate: { target: new THREE.Vector3(190, 14, -18), distance: 165, azimuth: 1.25, elevation: 0.24 },
    library: { target: new THREE.Vector3(178, 26, -21), distance: 150, azimuth: 1.05, elevation: 0.30 },
    axis: { target: new THREE.Vector3(65, 8, 5), distance: 200, azimuth: 0.85, elevation: 0.34 },
    sports: { target: new THREE.Vector3(-175, 6, 55), distance: 230, azimuth: 0.55, elevation: 0.36 },
    dorm: { target: new THREE.Vector3(-85, 8, -180), distance: 185, azimuth: 0.15, elevation: 0.36 },
    river: { target: new THREE.Vector3(105, 2, 255), distance: 280, azimuth: 0.95, elevation: 0.30 },
    top: { target: new THREE.Vector3(10, 0, 10), distance: 1250, azimuth: 0, elevation: 1.15 },
    night: { target: new THREE.Vector3(160, 8, 90), distance: 300, azimuth: 0.9, elevation: 0.28 }
  };

  /* ---------------- 世界 ---------------- */
  let world = null;
  let markers = [];
  let raycaster = new THREE.Raycaster();
  const pointerNDC = new THREE.Vector2();
  let hoverThrottle = 0;
  let lastTime = performance.now();
  let elapsed = 0;

  /* ---------------- 辅助 ---------------- */
  function showFatal(msg) {
    const loader = $('loader');
    if (!loader) return;
    loader.classList.remove('done');
    const inner = loader.querySelector('.loader-inner');
    if (inner) {
      inner.innerHTML = '<div style="color:#e0846c;font-size:15px;line-height:1.8;letter-spacing:.06em">' +
        msg + '<br><span style="font-size:12px;color:#8fa8a3">建议使用最新版 Chrome / Edge 浏览器并开启硬件加速</span></div>';
    }
    document.body.dataset.error = msg;
  }
  function toast(msg, duration) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), duration || 2200);
  }
  function hideTooltip() { $('tooltip').classList.remove('show'); }

  /* ---------------- 地标标记 ---------------- */
  function poiHeight(id) {
    const map = {
      library: 64, lab: 34, teach: 34, dorm: 27, canteen: 25, bath: 18, gym: 34,
      hall: 23, track: 13, courts: 9, culture: 27, exchange: 34, metasequoia: 16,
      oxidation: 7, river: 4, gate: 17, metro: 26, wetland: 6
    };
    return map[id] || 14;
  }
  function poiWorldPos(poi) {
    if (poi.world) return [poi.world[0], poi.world[1]];
    return p2w(poi.bx, poi.by);
  }
  function buildMarkers() {
    const wrap = $('markers');
    wrap.innerHTML = '';
    markers = [];
    // 距离较远时按重要度收敛标注，避免相互遮挡
    const PRIORITY = ['library', 'gate', 'gym', 'dorm', 'track', 'canteen', 'exchange', 'metro',
      'river', 'hall', 'teach', 'lab', 'culture', 'courts', 'bath', 'metasequoia', 'oxidation', 'wetland'];
    for (const poi of DATA.pois) {
      const el = document.createElement('div');
      el.className = 'poi-marker';
      el.dataset.id = poi.id;
      el.innerHTML =
        '<div class="pm-pill"><span class="pm-ico">' + poi.icon + '</span>' +
        '<span class="pm-name">' + poi.name + '</span></div>' +
        '<div class="pm-stem"></div><div class="pm-dot"></div>';
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        openPoi(poi.id, true);
      });
      wrap.appendChild(el);
      const wp = poiWorldPos(poi);
      const rank = PRIORITY.indexOf(poi.id);
      markers.push({
        id: poi.id, el, poi, rank: rank < 0 ? 99 : rank,
        pos: new THREE.Vector3(wp[0], poiHeight(poi.id), wp[1])
      });
    }
    markers.sort((a, b) => a.rank - b.rank);
  }
  function updateMarkers() {
    const w = window.innerWidth, h = window.innerHeight;
    const labelsOn = state.labelsOn;
    $('markers').classList.toggle('labels-off', !labelsOn);
    if (!labelsOn) return;
    const camPos = camera.position;
    const dist = controls.distance;
    let maxVisible = markers.length;
    if (dist > 1000) maxVisible = 6;
    else if (dist > 720) maxVisible = 9;
    else if (dist > 500) maxVisible = 12;
    else if (dist > 340) maxVisible = 15;
    let shown = 0;
    for (const m of markers) {
      const allowed = shown < maxVisible || m.id === state.activePoi;
      const v = m.pos.clone();
      const dcam = v.distanceTo(camPos);
      v.project(camera);
      let visible = allowed && v.z < 1 && v.x > -1.15 && v.x < 1.15 && v.y > -1.15 && v.y < 1.15;
      if (dcam > 1650) visible = false;
      m.el.style.display = visible ? '' : 'none';
      if (!visible) continue;
      shown++;
      m.el.style.left = ((v.x * 0.5 + 0.5) * w) + 'px';
      m.el.style.top = ((-v.y * 0.5 + 0.5) * h) + 'px';
      const near = clamp(1.2 - dcam / 1800, 0.45, 1);
      m.el.style.opacity = near;
      m.el.classList.toggle('dim', dcam > 900 && state.activePoi !== m.id);
      m.el.classList.toggle('active', state.activePoi === m.id);
    }
  }

  /* ---------------- 信息卡 ---------------- */
  function openPoi(id, fly) {
    const poi = DATA.pois.find(p => p.id === id);
    if (!poi) return;
    state.activePoi = id;
    if (world) world.highlight(poi.id);
    $('card-cat').textContent = poi.cat;
    $('card-title').textContent = poi.name;
    $('card-desc').textContent = poi.desc;
    const ul = $('card-facts');
    ul.innerHTML = '';
    (poi.facts || []).forEach(f => {
      const li = document.createElement('li');
      li.textContent = f;
      ul.appendChild(li);
    });
    $('info-card').classList.add('show');
    document.querySelectorAll('.poi-item').forEach(el => {
      el.classList.toggle('active', el.dataset.id === id);
    });
    if (fly) flyToPoi(poi);
  }
  function closeCard() {
    $('info-card').classList.remove('show');
    state.activePoi = null;
    if (world) world.highlight(null);
    document.querySelectorAll('.poi-item').forEach(el => el.classList.remove('active'));
  }
  function flyToPoi(poi) {
    const wp = poiWorldPos(poi);
    const f = poi.focus || { dist: 150, pitch: 25 };
    const target = new THREE.Vector3(wp[0], Math.min(poiHeight(poi.id) * 0.55, 30), wp[1]);
    const curAz = controls.goal.azimuth;
    // 优先从当前视角方向靠近，让镜头运动自然
    controls.flyTo({
      target,
      distance: f.dist,
      elevation: clamp((f.pitch || 25) * Math.PI / 180, 0.12, 1.0),
      azimuth: curAz + 0.15
    }, 1.8);
    if (state.tour.active) exitTour();
    pauseTour();
  }

  /* ---------------- 点击拾取 ---------------- */
  function pickAt(clientX, clientY) {
    if (!world) return;
    pointerNDC.x = (clientX / window.innerWidth) * 2 - 1;
    pointerNDC.y = -(clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(pointerNDC, camera);
    const hits = raycaster.intersectObjects(world.pickMeshes, false);
    if (hits.length) {
      let o = hits[0].object;
      let poiId = o.userData.poiId;
      while (!poiId && o.parent) { o = o.parent; poiId = o.userData && o.userData.poiId; }
      if (poiId) {
        openPoi(poiId, true);
        return;
      }
    }
    // 点空白：关闭卡片
    closeCard();
  }
  function onHover(e) {
    const now = performance.now();
    if (now - hoverThrottle < 110) return;
    hoverThrottle = now;
    if (!world) return;
    pointerNDC.x = (e.clientX / window.innerWidth) * 2 - 1;
    pointerNDC.y = -(e.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(pointerNDC, camera);
    const hits = raycaster.intersectObjects(world.pickMeshes, false);
    if (hits.length) {
      let o = hits[0].object;
      let poiId = o.userData.poiId;
      while (!poiId && o.parent) { o = o.parent; poiId = o.userData && o.userData.poiId; }
      const poi = DATA.pois.find(p => p.id === poiId);
      if (poi) {
        const tt = $('tooltip');
        tt.textContent = poi.name + ' · ' + poi.cat;
        tt.style.left = e.clientX + 'px';
        tt.style.top = e.clientY + 'px';
        tt.classList.add('show');
        renderer.domElement.style.cursor = 'pointer';
        state.hoverPoi = poiId;
        return;
      }
    }
    hideTooltip();
    renderer.domElement.style.cursor = 'grab';
    state.hoverPoi = null;
  }

  /* ---------------- 导览 ---------------- */
  const TOUR_STAY = 8.5;
  function startTour(index) {
    state.tour.active = true;
    state.tour.playing = true;
    state.tour.index = index || 0;
    state.tour.flying = true;
    $('tour-bar').classList.add('show');
    $('btn-tour').classList.add('active');
    loadTourStop(state.tour.index);
  }
  function loadTourStop(i) {
    const stop = DATA.tour[i];
    if (!stop) return;
    state.tour.stay = 0;
    state.tour.progress = 0;
    state.tour.flying = true;
    $('tour-step').textContent = String(i + 1).padStart(2, '0') + ' / ' + String(DATA.tour.length).padStart(2, '0');
    $('tour-name').textContent = stop.name;
    $('tour-caption').textContent = stop.caption;
    const nightTarget = stop.night ? 1 : 0;
    state.nightTarget = nightTarget;
    const target = new THREE.Vector3(stop.target.x, stop.target.y, stop.target.z);
    const cam = stop.cam;
    const dx = cam.x - target.x, dy = cam.y - target.y, dz = cam.z - target.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    const az = Math.atan2(dx, dz);
    const elev = Math.asin(clamp(dy / dist, -1, 1));
    controls.flyTo({
      target, distance: dist,
      azimuth: az, elevation: clamp(elev, 0.05, 1.35)
    }, 2.6);
    setTimeout(() => { state.tour.flying = false; }, 2700);
    // 高亮对应的 POI
    const poiMap = { gate: 'gate', library: 'library', axis: 'teach', sports: 'gym', dorm: 'dorm', river: 'river', night: 'library', overview: null };
    const pid = poiMap[stop.id];
    if (pid) {
      state.activePoi = pid;
      if (world) world.highlight(pid);
    } else {
      state.activePoi = null;
      if (world) world.highlight(null);
    }
  }
  function nextTour() {
    state.tour.index = (state.tour.index + 1) % DATA.tour.length;
    loadTourStop(state.tour.index);
  }
  function prevTour() {
    state.tour.index = (state.tour.index - 1 + DATA.tour.length) % DATA.tour.length;
    loadTourStop(state.tour.index);
  }
  function pauseTour() {
    if (!state.tour.active) return;
    state.tour.playing = false;
    $('tour-play').textContent = '▶';
  }
  function resumeTour() {
    if (!state.tour.active) return;
    state.tour.playing = true;
    $('tour-play').textContent = '❚❚';
  }
  function exitTour() {
    state.tour.active = false;
    state.tour.playing = false;
    $('tour-bar').classList.remove('show');
    $('btn-tour').classList.remove('active');
    $('tour-play').textContent = '❚❚';
  }
  function updateTour(dt) {
    if (!state.tour.active) return;
    if (state.tour.playing) {
      state.tour.stay += dt;
      const p = clamp(state.tour.stay / TOUR_STAY, 0, 1);
      $('tour-progress-fill').style.width = (p * 100) + '%';
      if (state.tour.stay >= TOUR_STAY) {
        if (state.tour.index >= DATA.tour.length - 1) {
          exitTour();
          toast('导览结束 · 可自由探索校园');
        } else {
          nextTour();
        }
      }
    }
  }

  /* ---------------- 昼夜 ---------------- */
  function setNightTarget(v, silent) {
    state.nightTarget = v;
    const btn = $('btn-daynight');
    btn.classList.toggle('active', v > 0.5);
    $('ico-daynight').textContent = v > 0.5 ? '☾' : '☀';
    $('txt-daynight').textContent = v > 0.5 ? '夜晚' : '白昼';
    if (!silent) toast(v > 0.5 ? '夜幕降临 · 校园灯光亮起' : '晨光熹微 · 校园苏醒');
  }

  /* ---------------- 侧栏 ---------------- */
  function buildSidebar() {
    const cats = ['全部'];
    for (const p of DATA.pois) if (cats.indexOf(p.cat) < 0) cats.push(p.cat);
    const filter = $('poi-filter');
    filter.innerHTML = '';
    cats.forEach((c, i) => {
      const b = document.createElement('button');
      b.className = 'chip' + (i === 0 ? ' active' : '');
      b.textContent = c;
      b.dataset.cat = c;
      b.addEventListener('click', () => {
        filter.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
        b.classList.add('active');
        renderPoiList(c);
      });
      filter.appendChild(b);
    });
    renderPoiList('全部');
    buildInfoTab();
  }
  function renderPoiList(cat) {
    const list = $('poi-list');
    list.innerHTML = '';
    for (const poi of DATA.pois) {
      if (cat !== '全部' && poi.cat !== cat) continue;
      const el = document.createElement('div');
      el.className = 'poi-item';
      el.dataset.id = poi.id;
      el.innerHTML =
        '<div class="pi-ico">' + poi.icon + '</div>' +
        '<div class="pi-body"><div class="pi-name">' + poi.name +
        '<span class="pi-cat">' + poi.cat + '</span></div>' +
        '<div class="pi-desc">' + poi.desc + '</div></div>';
      el.addEventListener('click', () => openPoi(poi.id, true));
      list.appendChild(el);
    }
    if (state.activePoi) {
      list.querySelectorAll('.poi-item').forEach(x => {
        x.classList.toggle('active', x.dataset.id === state.activePoi);
      });
    }
  }
  function buildInfoTab() {
    const meta = DATA.meta;
    const el = $('info-scroll');
    let html = '<div class="istat-grid">';
    for (const s of meta.stats) {
      html += '<div class="istat"><b>' + s.value + '</b><i>' + s.unit + '</i><p>' + s.label + '</p></div>';
    }
    html += '</div>';
    html += '<div class="motto-line">' + meta.motto + '</div>';
    html += '<div class="isec"><h3>学校概况</h3><p>' + meta.intro + '</p></div>';
    html += '<div class="isec"><h3>办学坐标</h3><p>' + meta.address + '<br>坐标 ' + meta.coords + '<br>地铁16号线湾湖站 · 紧邻校园北侧</p></div>';
    html += '<div class="isec"><h3>办学亮点</h3><ul>';
    for (const f of meta.facts) html += '<li>' + f + '</li>';
    html += '</ul></div>';
    html += '<div class="isec"><h3>校园地标</h3><p>校园以中央环形教学区为核心：北侧为实验大楼，南侧为教学大楼，东侧为图文信息中心；西部是体育馆、多功能厅和田径场，西北部是学生宿舍与食堂，南侧是马影河与坛山岛湿地公园。</p></div>';
    html += '<div class="isec"><h3>校训 · 校风</h3><p>校训：明德、修业、砺志、笃行<br>校风：求实、进取、开拓、创新<br>学校精神：团结奋进、自强不息、精业敬业、追求卓越</p></div>';
    html += '<div class="isec"><h3>说明</h3><p class="src">' + meta.disclaimer + '</p></div>';
    el.innerHTML = html;
  }

  /* ---------------- 关于弹窗 ---------------- */
  function buildAbout() {
    const meta = DATA.meta;
    const body = $('about-body');
    let html = '<h3>关于本校</h3><p>' + meta.intro + '</p>';
    html += '<h3>办学坐标</h3><p>' + meta.address + '<br>' + meta.coords + '</p>';
    html += '<h3>校训 · 明德 修业 砺志 笃行</h3><p>校风：求实、进取、开拓、创新<br>学校精神：团结奋进、自强不息、精业敬业、追求卓越</p>';
    html += '<h3>三维校园说明</h3><p>' + meta.disclaimer + '</p>';
    html += '<h3>资料来源</h3><ul>';
    for (const s of meta.sources) {
      html += '<li><a href="' + s.url + '" target="_blank" rel="noopener">' + s.name + '</a></li>';
    }
    html += '</ul>';
    html += '<p class="about-meta">本页面为校园文化展示用途的三维交互作品；建筑与景观为艺术化表达，具体以学校实际情况为准。three.js r159 · 离线单文件资源 · 无外部依赖。</p>';
    body.innerHTML = html;
  }

  /* ---------------- 加载流程 ---------------- */
  let fakeProgress = 0;
  let tipIndex = 0;
  let fakeTimer = null;
  function startFakeProgress() {
    fakeProgress = 0;
    $('loader-fill').style.width = '0%';
    $('loader-pct').textContent = '0%';
    tipIndex = 0;
    $('loader-tip').textContent = DATA.ui.loadingTips[0];
    fakeTimer = setInterval(() => {
      fakeProgress = Math.min(88, fakeProgress + (fakeProgress < 45 ? 4.2 : fakeProgress < 70 ? 2.1 : 0.9));
      $('loader-fill').style.width = fakeProgress + '%';
      $('loader-pct').textContent = Math.round(fakeProgress) + '%';
      const ti = Math.min(DATA.ui.loadingTips.length - 1,
        Math.floor(fakeProgress / 100 * DATA.ui.loadingTips.length));
      if (ti !== tipIndex) {
        tipIndex = ti;
        const tipEl = $('loader-tip');
        tipEl.style.opacity = 0;
        setTimeout(() => { tipEl.textContent = DATA.ui.loadingTips[ti]; tipEl.style.opacity = 1; }, 220);
      }
    }, 220);
  }
  function finishLoading() {
    clearInterval(fakeTimer);
    $('loader-fill').style.width = '100%';
    $('loader-pct').textContent = '100%';
    state.ready = true;
    document.body.dataset.ready = '1';
    setTimeout(() => {
      $('loader').classList.add('done');
      onEnterScene();
    }, 500);
  }

  /* ---------------- 入场 ---------------- */
  function onEnterScene() {
    if (SHOT) {
      if (HIDE_UI) document.querySelectorAll('.hud').forEach(el => el.style.display = 'none');
      const view = params.get('view') || 'overview';
      const v = VIEWS[view] || VIEWS.overview;
      controls.target.copy(v.target);
      controls.distance = v.distance;
      controls.azimuth = v.azimuth;
      controls.elevation = v.elevation;
      controls.goal.target.copy(v.target);
      controls.goal.distance = v.distance;
      controls.goal.azimuth = v.azimuth;
      controls.goal.elevation = v.elevation;
      if (params.get('night') === '1') { state.night = 1; state.nightTarget = 1; world.setNight(1); setNightTarget(1, true); }
      if (params.get('poi')) openPoi(params.get('poi'), false);
      if (params.get('tour')) startTour(parseInt(params.get('tour'), 10) || 0);
      controls.update(0.016);
      return;
    }
    // 开场：从高空俯冲入画
    controls.target.set(0, 0, 0);
    controls.distance = 1650;
    controls.azimuth = -0.4;
    controls.elevation = 1.05;
    controls.goal.target.copy(controls.target);
    controls.goal.distance = 1650;
    controls.goal.azimuth = -0.4;
    controls.goal.elevation = 1.05;
    controls.update(0.016);
    const v = VIEWS.overview;
    controls.flyTo({
      target: v.target.clone(), distance: v.distance,
      azimuth: v.azimuth, elevation: v.elevation
    }, 5.0);
    setTimeout(() => {
      $('welcome-strip').classList.add('show');
      setTimeout(() => $('welcome-strip').classList.remove('show'), 6000);
    }, 3400);
    setTimeout(() => {
      let visited = false;
      try { visited = !!localStorage.getItem('hblrvc-visited'); } catch (e) { visited = true; }
      if (!visited) {
        try { localStorage.setItem('hblrvc-visited', '1'); } catch (e) {}
        toast('拖动旋转 · 滚轮缩放 · 点击地标查看详情', 3600);
      }
    }, 6200);
  }

  /* ---------------- 事件绑定 ---------------- */
  function bindUI() {
    $('btn-daynight').addEventListener('click', () => {
      setNightTarget(state.nightTarget > 0.5 ? 0 : 1);
      if (state.tour.active) pauseTour();
    });
    $('btn-tour').addEventListener('click', () => {
      if (state.tour.active) exitTour();
      else startTour(0);
    });
    $('btn-reset').addEventListener('click', () => {
      exitTour();
      const v = VIEWS.overview;
      controls.flyTo({ target: v.target.clone(), distance: v.distance, azimuth: v.azimuth, elevation: v.elevation }, 1.8);
      toast('已回到校园全景视角');
    });
    $('btn-about').addEventListener('click', () => $('about-modal').classList.add('show'));
    $('about-close').addEventListener('click', () => $('about-modal').classList.remove('show'));
    $('about-start').addEventListener('click', () => $('about-modal').classList.remove('show'));
    $('about-modal').addEventListener('click', (e) => {
      if (e.target === $('about-modal')) $('about-modal').classList.remove('show');
    });
    $('btn-fullscreen').addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
      } else {
        document.exitFullscreen && document.exitFullscreen();
      }
    });
    $('card-close').addEventListener('click', closeCard);
    $('card-fly').addEventListener('click', () => {
      const poi = DATA.pois.find(p => p.id === state.activePoi);
      if (poi) flyToPoi(poi);
    });
    $('card-tour-start').addEventListener('click', () => {
      const map = {
        library: 'library', lab: 'axis', teach: 'axis', gym: 'sports', track: 'sports',
        courts: 'sports', dorm: 'dorm', canteen: 'dorm', bath: 'dorm', gate: 'gate',
        river: 'river', metasequoia: 'river', wetland: 'river', metro: 'dorm', culture: 'sports',
        exchange: 'river', hall: 'sports', oxidation: 'overview'
      };
      const stopId = map[state.activePoi] || 'overview';
      const idx = DATA.tour.findIndex(s => s.id === stopId);
      startTour(idx >= 0 ? idx : 0);
    });
    $('tour-prev').addEventListener('click', prevTour);
    $('tour-next').addEventListener('click', nextTour);
    $('tour-exit').addEventListener('click', () => exitTour());
    $('tour-play').addEventListener('click', () => {
      if (state.tour.playing) pauseTour(); else resumeTour();
    });
    $('btn-side-collapse').addEventListener('click', () => {
      $('sidebar').classList.add('collapsed');
      $('panel-float').classList.add('show');
    });
    $('panel-float').addEventListener('click', () => {
      $('sidebar').classList.remove('collapsed');
      $('panel-float').classList.remove('show');
    });
    document.querySelectorAll('.side-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.side-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        $('tab-' + tab.dataset.tab).classList.add('active');
      });
    });
    // 图层
    $('lyr-buildings').addEventListener('change', (e) => {
      if (!world) return;
      world.buildingGroups.forEach(g => g.visible = e.target.checked);
    });
    $('lyr-trees').addEventListener('change', (e) => {
      if (!world) return;
      (world.treeMeshes || []).forEach(m => m.visible = e.target.checked);
      if (world.hedge) world.hedge.visible = e.target.checked;
    });
    $('lyr-water').addEventListener('change', (e) => {
      if (world) world.water.visible = e.target.checked;
    });
    $('lyr-actors').addEventListener('change', (e) => {
      if (!world) return;
      const v = e.target.checked;
      world.people.forEach(p => p.visible = v);
      world.cars.forEach(c => c.visible = v);
      world.birds.forEach(b => b.visible = v);
      if (world.train) world.train.visible = v;
    });
    $('lyr-labels').addEventListener('change', (e) => {
      state.labelsOn = e.target.checked;
    });
    $('lyr-autocycle').addEventListener('change', (e) => {
      state.autoCycle = e.target.checked;
      state.autoTimer = 0;
      toast(state.autoCycle ? '自动昼夜循环已开启' : '自动昼夜循环已关闭');
    });
    // 快捷键
    window.addEventListener('keydown', (e) => {
      if (e.target && e.target.tagName === 'INPUT') return;
      const k = e.key.toLowerCase();
      if (k === 'n') setNightTarget(state.nightTarget > 0.5 ? 0 : 1);
      else if (k === 'r') $('btn-reset').click();
      else if (k === 't') $('btn-tour').click();
      else if (k === 'escape') { closeCard(); exitTour(); $('about-modal').classList.remove('show'); }
      else if (k === 'arrowright' && state.tour.active) nextTour();
      else if (k === 'arrowleft' && state.tour.active) prevTour();
    });
    window.addEventListener('resize', onResize);
  }

  function onResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    const pr = Math.min(window.devicePixelRatio || 1, 2) * state.quality;
    renderer.setPixelRatio(clamp(pr, 0.75, 2));
  }

  /* ---------------- 渲染循环 ---------------- */
  function animate(now) {
    requestAnimationFrame(animate);
    const dt = Math.min(0.05, (now - lastTime) / 1000);
    lastTime = now;
    elapsed += dt;

    // 昼夜过渡
    if (Math.abs(state.night - state.nightTarget) > 0.001) {
      state.night += (state.nightTarget - state.night) * Math.min(1, dt * 1.8);
      if (world) world.setNight(state.night);
    }
    if (state.autoCycle) {
      state.autoTimer += dt;
      if (state.autoTimer > 45) {
        state.autoTimer = 0;
        setNightTarget(state.nightTarget > 0.5 ? 0 : 1, true);
      }
    }

    controls.update(dt);
    try {
      if (world) world.update(dt, elapsed);
      updateMarkers();
      updateTour(dt);
      updateCompass();
    } catch (err) {
      if (!state._updateErr) {
        state._updateErr = err;
        document.body.dataset.jsError = String(err && err.stack || err);
        console.error('CAMPUS_UPDATE_ERROR ' + String(err && err.stack || err).replace(/\n/g, ' | '));
      }
    }

    // 帧率自适应（可用 ?noadapt=1 关闭）
    state.fps = state.fps * 0.95 + (1 / Math.max(dt, 0.001)) * 0.05;
    if (!params.has('noadapt') && elapsed > 6 && state.fps < 32 && state.quality > 0.7) {
      state.quality = 0.7;
      onResize();
    }

    try {
      renderer.render(scene, camera);
    } catch (err) {
      if (!state._renderErr) {
        state._renderErr = err;
        const msg = String(err && err.stack || err);
        document.body.dataset.renderError = msg;
        document.title = 'RENDER_ERROR ' + (err && err.message);
        const t = document.getElementById('toast');
        if (t) { t.textContent = msg.slice(0, 2500); t.style.opacity = 1; }
        console.error('CAMPUS_RENDER_ERROR ' + msg.replace(/\n/g, ' | '));
      }
    }
    if (!document.body.dataset.calls) {
      document.body.dataset.calls = String(renderer.info.render.calls);
      document.body.dataset.triangles = String(renderer.info.render.triangles);
    }
  }

  function updateCompass() {
    const deg = (-controls.azimuth * 180 / Math.PI) % 360;
    const el = $('compass-needle');
    if (el) el.style.transform = 'rotate(' + deg + 'deg)';
    // 比例尺按相机距离估计
    const scale = $('scale-label');
    if (scale) {
      const d = controls.distance;
      let m = 500;
      if (d < 120) m = 20;
      else if (d < 260) m = 50;
      else if (d < 520) m = 100;
      else if (d < 900) m = 200;
      else if (d < 1400) m = 500;
      else m = 1000;
      scale.textContent = m + ' m';
    }
  }

  /* ---------------- 启动 ---------------- */
  async function boot() {
    startFakeProgress();
    bindUI();
    buildSidebar();
    buildAbout();
    setNightTarget(0, true);
    // 移动端默认收起侧栏，给三维画面留出空间
    if (window.innerWidth < 900) {
      $('sidebar').classList.add('collapsed');
      $('panel-float').classList.add('show');
    }
    // 初始相机
    controls.target.set(0, 0, 0);
    controls.distance = 1650;
    controls.elevation = 1.05;
    controls.update(0.016);
    try {
      world = await window.CampusScene.create(scene, renderer);
      buildMarkers();
      finishLoading();
      // 首帧
      requestAnimationFrame((t) => { lastTime = t; animate(t); });
      window.__campus = {
        camera, controls, get world() { return world; },
        state, setNight: (v) => { setNightTarget(v, true); state.night = v; if (world) world.setNight(v); },
        setView: (name) => {
          const v = VIEWS[name] || VIEWS.overview;
          controls.target.copy(v.target);
          controls.distance = v.distance; controls.azimuth = v.azimuth; controls.elevation = v.elevation;
          controls.goal.target.copy(v.target); controls.goal.distance = v.distance;
          controls.goal.azimuth = v.azimuth; controls.goal.elevation = v.elevation;
          controls.tween = null;
          controls.update(0.016);
        },
        openPoi: (id) => openPoi(id, false),
        startTour: (i) => startTour(i || 0),
        renderer, scene, THREE
      };
    } catch (err) {
      console.error(err);
      showFatal('三维场景初始化失败：' + (err && err.message ? err.message : err));
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
