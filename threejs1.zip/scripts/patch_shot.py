﻿import re
p = r"C:\Users\32311\Desktop\threejs1\scripts\shot.py"
s = open(p, encoding="utf-8").read()
s = s.replace('    ("night_overview", "shot=1&view=overview&night=1&hideui=1", 1440, 880),\n]',
 '''    ("night_overview", "shot=1&view=overview&night=1&hideui=1", 1440, 880),
    ("ui_card", "shot=1&view=library&poi=library", 1440, 880),
    ("tour", "shot=1&view=overview&tour=1", 1440, 880),
]''')
open(p, "w", encoding="utf-8").write(s)
print("shot.py updated")
