# -*- coding: utf-8 -*-
"""Headless Chrome screenshot harness for the 3D campus page."""
import os
import re
import subprocess
import sys

ROOT = r"C:\Users\32311\Desktop\threejs1"
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
OUT = os.path.join(ROOT, "shots")
os.makedirs(OUT, exist_ok=True)
PROFILE = os.path.join(ROOT, ".chrome-shot-profile")
BASE = "file:///C:/Users/32311/Desktop/threejs1/index.html"

# name, query, width, height, virtual-time-budget-ms
STATES = [
    ("overview", "shot=1&view=overview&hideui=1", 1440, 880, 9000),
    ("overview_ui", "shot=1&view=overview", 1440, 880, 9000),
    ("library", "shot=1&view=library&hideui=1", 1440, 880, 9000),
    ("gate", "shot=1&view=gate&hideui=1", 1440, 880, 9000),
    ("sports", "shot=1&view=sports&hideui=1", 1440, 880, 9000),
    ("river", "shot=1&view=river&hideui=1", 1440, 880, 9000),
    ("night_overview", "shot=1&view=overview&night=1&hideui=1", 1440, 880, 9000),
    ("night", "shot=1&view=night&night=1&hideui=1", 1440, 880, 9000),
    ("ui_card", "shot=1&view=library&poi=library", 1440, 880, 9000),
    ("tour", "shot=1&view=overview&tour=1", 1440, 880, 9000),
    ("mobile", "shot=1&view=overview", 420, 860, 9000),
    ("loader", "", 1440, 880, 900),
    ("intro", "", 1440, 880, 7500),
]

DUMP = ("overview_ui", "night", "night_overview", "mobile")


def run(state):
    name, query, w, h = state[0], state[1], state[2], state[3]
    budget = state[4] if len(state) > 4 else 12000
    shot = os.path.join(OUT, name + ".png")
    if os.path.exists(shot):
        try:
            os.remove(shot)
        except OSError:
            pass
    args = [
        CHROME, "--headless=new", "--no-sandbox", "--disable-gpu-sandbox",
        "--disable-breakpad", "--disable-crash-reporter", "--no-first-run",
        "--no-default-browser-check", "--mute-audio",
        "--user-data-dir=" + PROFILE,
        "--enable-unsafe-swiftshader", "--use-angle=swiftshader",
        "--hide-scrollbars", "--window-size=%d,%d" % (w, h),
        "--force-device-scale-factor=1",
        "--virtual-time-budget=%d" % budget,
        "--enable-logging=stderr", "--log-level=0",
        "--screenshot=" + shot,
    ]
    dump_dom = name in DUMP
    if dump_dom:
        args.append("--dump-dom")
    args.append(BASE + ("?" + query if query else ""))
    try:
        p = subprocess.run(args, capture_output=True, timeout=180)
        err = p.stderr.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        print(name, "TIMEOUT")
        return
    bad = [ln for ln in err.splitlines() if re.search(
        r"CONSOLE.*(CAMPUS_|Uncaught|TypeError|SyntaxError)", ln)]
    print("=" * 18, name, "exit", p.returncode)
    for ln in bad[:6]:
        print("  ", ln.strip()[:900])
    if os.path.exists(shot):
        print("   screenshot", os.path.getsize(shot), "bytes")
    else:
        print("   NO SCREENSHOT")
    if dump_dom:
        dom = p.stdout.decode("utf-8", "replace")
        m = re.search(r'<body[^>]*>', dom)
        print("   body:", m.group(0)[:300] if m else "?")
        if "三维场景初始化失败" in dom:
            print("   FATAL FOUND IN DOM")


if __name__ == "__main__":
    targets = sys.argv[1:] or [s[0] for s in STATES]
    for s in STATES:
        if s[0] in targets:
            run(s)
