﻿import re
p = r"C:\Users\32311\Desktop\threejs1\scripts\shot.py"
s = open(p, encoding="utf-8").read()
if 'overview_noadapt' not in s:
    s = s.replace('    ("ui_card", "shot=1&view=library&poi=library", 1440, 880),',
                  '    ("overview_noadapt", "shot=1&view=overview&hideui=1&noadapt=1", 1440, 880),\n    ("ui_card", "shot=1&view=library&poi=library", 1440, 880),')
    s = s.replace('run(s, dump_dom=(s[0] in ("overview_ui", "night", "night_overview")))',
                  'run(s, dump_dom=(s[0] in ("overview_ui", "overview_noadapt", "night", "night_overview")))')
open(p, "w", encoding="utf-8").write(s)
print("ok")
