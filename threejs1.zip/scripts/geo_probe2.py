﻿import json, urllib.request, urllib.parse, ssl, time
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
def get(url, data=None, hdrs=None, timeout=60):
    h={'User-Agent':UA}
    if hdrs: h.update(hdrs)
    req=urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.status, r.read()
# 1) campus way geometry via OSM API
try:
    st,d=get('https://api.openstreetmap.org/api/0.6/way/1318101933/full.json', hdrs={'Accept':'application/json'})
    print('OSM way OK',st,len(d))
    open('scripts/data/osm_way.json','wb').write(d)
    j=json.loads(d)
    for e in j['elements']:
        print(e['type'], e['id'], e.get('tags'))
    nodes={e['id']:e for e in j['elements'] if e['type']=='node'}
    way=[e for e in j['elements'] if e['type']=='way'][0]
    print('node count', len(way['nodes']))
    print([(round(nodes[n]['lat'],6), round(nodes[n]['lon'],6)) for n in way['nodes'][:8]])
except Exception as e:
    print('OSM way FAIL',repr(e))
# 2) Overpass variants
bbox='30.3140,114.0330,30.3270,114.0490'
q=f'[out:json][timeout:60];(way["building"]({bbox});way["highway"]({bbox});way["waterway"]({bbox});way["natural"="water"]({bbox});way["landuse"]({bbox});way["leisure"]({bbox}););out geom;'
for endpoint in ['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter','https://overpass.private.coffee/api/interpreter']:
    try:
        st,d=get(endpoint, data=urllib.parse.urlencode({'data':q}).encode(), hdrs={'Accept':'*/*','Content-Type':'application/x-www-form-urlencoded'}, timeout=90)
        print(endpoint,'OK',st,len(d))
        open('scripts/data/overpass.json','wb').write(d)
        break
    except Exception as e:
        print(endpoint,'FAIL',repr(e))
