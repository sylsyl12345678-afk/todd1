﻿import urllib.request, ssl, os
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
os.makedirs('assets/ref', exist_ok=True)
tests = {
 'amap_sat.png': 'https://webst01.is.autonavi.com/appmaptile?style=6&x=26768&y=13485&z=15',
 'esri_sat.jpg': 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/15/13485/26768',
 'osm_tile.png': 'https://tile.openstreetmap.org/15/26768/13485.png',
}
for name,url in tests.items():
    try:
        req=urllib.request.Request(url, headers={'User-Agent':UA,'Referer':'https://www.openstreetmap.org/'})
        with urllib.request.urlopen(req, timeout=45, context=ctx) as r:
            d=r.read()
        open('assets/ref/'+name,'wb').write(d)
        print(name,'OK',r.status,len(d),d[:4])
    except Exception as e:
        print(name,'FAIL',repr(e))
