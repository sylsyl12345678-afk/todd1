# -*- coding: utf-8 -*-
"""Extract building footprints from the official campus master plan (white roofs -> OBBs),
and produce a grid overlay for manual road/water digitizing."""
import json
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = r"C:\Users\32311\Desktop\threejs1"
ASSETS = os.path.join(ROOT, "assets")
OUT = os.path.join(ASSETS, "analysis")
os.makedirs(OUT, exist_ok=True)

im = Image.open(os.path.join(ASSETS, "campus-map.jpg")).convert("RGB")
W, H = im.size
arr = np.asarray(im).astype(np.float32) / 255.0
r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
mx = arr.max(axis=2)
mn = arr.min(axis=2)
sat = np.where(mx > 1e-5, (mx - mn) / np.maximum(mx, 1e-5), 0)

# white-ish roof pixels
mask = (mx > 0.80) & (sat < 0.10)
mask = mask.astype(np.uint8)

# morphological open (remove text/lines) then close (fill label bands)
def dilate(m, k):
    out = m.copy()
    for _ in range(k):
        p = np.pad(out, 1, mode="constant")
        out = (p[1:-1, 1:-1] | p[:-2, 1:-1] | p[2:, 1:-1] | p[1:-1, :-2] | p[1:-1, 2:] |
               p[:-2, :-2] | p[:-2, 2:] | p[2:, :-2] | p[2:, 2:])
    return out

def erode(m, k):
    out = m.copy()
    for _ in range(k):
        p = np.pad(out, 1, mode="constant")
        out = (p[1:-1, 1:-1] & p[:-2, 1:-1] & p[2:, 1:-1] & p[1:-1, :-2] & p[1:-1, 2:] &
               p[:-2, :-2] & p[:-2, 2:] & p[2:, :-2] & p[2:, 2:])
    return out

m = erode(dilate(mask, 1), 1)   # open
m = dilate(erode(m, 5), 5)      # close big gaps (labels) -- erode then dilate
m = erode(dilate(m, 3), 3)

# connected components (BFS, numpy assisted)
lab = np.zeros((H, W), dtype=np.int32)
comps = []
visited = np.zeros_like(m)
from collections import deque
cid = 0
for y in range(H):
    xs = np.nonzero(m[y] & ~visited[y])[0]
    for x in xs:
        if visited[y, x]:
            continue
        cid += 1
        q = deque([(y, x)])
        visited[y, x] = 1
        pixels = []
        while q:
            cy, cx = q.popleft()
            pixels.append((cy, cx))
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = cy + dy, cx + dx
                if 0 <= ny < H and 0 <= nx < W and m[ny, nx] and not visited[ny, nx]:
                    visited[ny, nx] = 1
                    q.append((ny, nx))
        if len(pixels) >= 260:  # ~ 260 px, filters small clutter
            ys = np.array([p[0] for p in pixels])
            xs_ = np.array([p[1] for p in pixels])
            comps.append({"cid": cid, "n": len(pixels), "px": xs_, "py": ys})

print("components kept:", len(comps))

def obb(xs, ys):
    cx, cy = xs.mean(), ys.mean()
    pts = np.stack([xs - cx, ys - cy], axis=1).astype(np.float64)
    best = None
    for deg in np.arange(0, 90, 1.0):
        a = np.deg2rad(deg)
        ca, sa = np.cos(a), np.sin(a)
        rot = np.array([[ca, sa], [-sa, ca]])
        p = pts @ rot.T
        w = p[:, 0].max() - p[:, 0].min()
        h = p[:, 1].max() - p[:, 1].min()
        area = w * h
        if best is None or area < best[0]:
            best = (area, deg, w, h)
    return {"cx": float(cx), "cy": float(cy), "angle": float(best[1]),
            "w": float(best[2]), "h": float(best[3]), "area": int(best[0])}

found = []
for c in comps:
    xs, ys = c["px"], c["py"]
    # split wide L-shapes? keep simple: OBB of component
    o = obb(xs, ys)
    o["id"] = len(found)
    o["fill"] = round(c["n"] / max(1, o["w"] * o["h"]), 2)
    o["bbox"] = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]
    found.append(o)

# filter obvious non-buildings: very thin (road lines), low fill, tiny
buildings = []
for o in found:
    if o["w"] < 12 or o["h"] < 12:
        continue
    if o["w"] * o["h"] < 300:
        continue
    if o["fill"] < 0.45:
        continue
    buildings.append(o)

buildings.sort(key=lambda d: -d["area"])
for i, b in enumerate(buildings):
    b["id"] = i
print("buildings:", len(buildings), "areas:", [round(b["w"] * b["h"]) for b in buildings[:10]])

with open(os.path.join(OUT, "buildings_auto.json"), "w", encoding="utf-8") as f:
    json.dump(buildings, f, ensure_ascii=False, indent=1)

# draw overlay
ov = im.copy()
d = ImageDraw.Draw(ov)
import math
try:
    font = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 16)
except Exception:
    font = ImageFont.load_default()

# grid every 50 px
for gx in range(0, W, 50):
    d.line([(gx, 0), (gx, H)], fill=(0, 160, 255) if gx % 100 == 0 else (140, 210, 255), width=1)
for gy in range(0, H, 50):
    d.line([(0, gy), (W, gy)], fill=(0, 160, 255) if gy % 100 == 0 else (140, 210, 255), width=1)
for gx in range(0, W, 100):
    for gy in range(0, H, 100):
        d.text((gx + 2, gy + 1), f"{gx},{gy}", fill=(200, 0, 0), font=font)

for b in buildings:
    a = math.radians(b["angle"])
    cx, cy, w, h = b["cx"], b["cy"], b["w"] / 2, b["h"] / 2
    ca, sa = math.cos(a), math.sin(a)
    corners = []
    for px, py in ((-w, -h), (w, -h), (w, h), (-w, h)):
        corners.append((cx + px * ca - py * sa, cy + px * sa + py * ca))
    d.polygon(corners, outline=(255, 0, 0), width=3)
    d.text((cx - 8, cy - 8), str(b["id"]), fill=(0, 0, 0), font=font)

ov.save(os.path.join(OUT, "plan_grid.png"))
# also plain grid w/o boxes
plain = im.copy()
d2 = ImageDraw.Draw(plain)
for gx in range(0, W, 50):
    d2.line([(gx, 0), (gx, H)], fill=(0, 160, 255) if gx % 100 == 0 else (160, 220, 255), width=1)
for gy in range(0, H, 50):
    d2.line([(0, gy), (W, gy)], fill=(0, 160, 255) if gy % 100 == 0 else (160, 220, 255), width=1)
for gx in range(0, W, 100):
    for gy in range(0, H, 100):
        d2.text((gx + 2, gy + 1), f"{gx},{gy}", fill=(255, 0, 0), font=font)
plain.save(os.path.join(OUT, "plan_plain_grid.png"))
print("saved analysis overlays")
