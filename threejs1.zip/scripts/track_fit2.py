﻿import numpy as np
from PIL import Image, ImageFilter
from collections import deque
im = np.asarray(Image.open(r"C:\Users\32311\Desktop\threejs1\assets\campus-map.jpg").convert("RGB")).astype(int)
r,g,b = im[...,0],im[...,1],im[...,2]
mask = ((r>130)&(r-g>30)&(r-b>25)).astype(np.uint8)*255
mask = np.asarray(Image.fromarray(mask,"L").filter(ImageFilter.MinFilter(5)))>128
mask[:470,:]=False; mask[800:,:]=False; mask[:,:140]=False; mask[:,470:]=False
H,W=mask.shape; lab=np.zeros((H,W),int); comps=[]; cid=0
for y in range(H):
    for x in np.nonzero(mask[y])[0]:
        if lab[y,x] or not mask[y,x]: continue
        cid+=1; q=deque([(y,x)]); lab[y,x]=cid; pix=[]
        while q:
            cy,cx=q.popleft(); pix.append((cy,cx))
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    ny,nx=cy+dy,cx+dx
                    if 0<=ny<H and 0<=nx<W and mask[ny,nx] and not lab[ny,nx]:
                        lab[ny,nx]=cid; q.append((ny,nx))
        comps.append((len(pix),cid))
comps.sort(reverse=True)
print("top comps", comps[:6])
for n,c in comps[:3]:
    ys,xs=np.nonzero(lab==c)
    print("comp",c,"n",n,"center",round(xs.mean(),1),round(ys.mean(),1),"bbox",xs.min(),xs.max(),ys.min(),ys.max())
    if n>300:
        pts=np.stack([xs-xs.mean(),ys-ys.mean()],1).astype(float)
        cov=np.cov(pts.T); evals,evecs=np.linalg.eigh(cov)
        order=np.argsort(evals)[::-1]; major=evecs[:,order[0]]; minor=evecs[:,order[1]]
        projM=pts@major; projm=pts@minor
        print("   major",np.round(major,3),"len",round(projM.max()-projM.min(),1),"minor len",round(projm.max()-projm.min(),1),"angle",round(np.degrees(np.arctan2(major[1],major[0])),1))
