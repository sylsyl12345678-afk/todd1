﻿import json, urllib.request, urllib.parse, ssl
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
def get(url, data=None, hdrs=None):
    h={'User-Agent':UA}
    if hdrs: h.update(hdrs)
    req=urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=45, context=ctx) as r:
        return r.status, r.read()
for name,url in [
  ('photon','https://photon.komoot.io/api/?q='+urllib.parse.quote('湖北国土资源职业学院')+'&limit=3'),
  ('nominatim','https://nominatim.openstreetmap.org/search?format=json&q='+urllib.parse.quote('湖北国土资源职业学院')+'&limit=3'),
]:
    try:
        st,d=get(url, hdrs={'Accept':'application/json','Accept-Language':'zh-CN,zh;q=0.9'})
        print(name,'OK',st,len(d)); print(d.decode('utf-8','replace')[:800])
    except Exception as e:
        print(name,'FAIL',repr(e))
# overpass small query
try:
    q='[out:json][timeout:30];node["name"~"湖北国土资源职业学院"](30.2,114.0,30.4,114.15);out center;'
    st,d=get('https://overpass-api.de/api/interpreter?data='+urllib.parse.quote(q), hdrs={'Accept':'application/json'})
    print('overpass OK',st,len(d)); print(d.decode('utf-8','replace')[:1200])
except Exception as e:
    print('overpass FAIL',repr(e))
