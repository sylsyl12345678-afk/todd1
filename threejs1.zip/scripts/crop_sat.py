# -*- coding: utf-8 -*-
"""Inspect satellite mosaic regions around the campus."""
import os
from PIL import Image, ImageDraw

ROOT = r"C:\Users\32311\Desktop\threejs1"
im = Image.open(os.path.join(ROOT, "assets", "ref", "amap_z17.png")).convert("RGB")
W, H = im.size
print("mosaic", W, H)
out = os.path.join(ROOT, "assets", "ref")

# expected campus center from Photon: tile (107057.46, 53941.93), mosaic origin (107052,53936)
cx = (107057.4615 - 107052) * 256
cy = (53941.9281 - 53936) * 256
print("expected center px", cx, cy)

regions = {
    "crop_center": (int(cx) - 700, int(cy) - 700, int(cx) + 700, int(cy) + 700),
    "crop_sw": (300, 1450, 1500, 2650),
    "crop_se": (1400, 1450, 2700, 2650),
}
for name, box in regions.items():
    box = (max(0, box[0]), max(0, box[1]), min(W, box[2]), min(H, box[3]))
    c = im.crop(box)
    scale = 2 if name == "crop_center" else 1.4
    c = c.resize((int(c.width * scale), int(c.height * scale)), Image.LANCZOS)
    c.save(os.path.join(out, name + ".png"))
    print(name, box, c.size)

# annotated overview with center cross and grid
ov = im.copy()
d = ImageDraw.Draw(ov)
d.line([(cx - 80, cy), (cx + 80, cy)], fill=(255, 0, 0), width=6)
d.line([(cx, cy - 80), (cx, cy + 80)], fill=(255, 0, 0), width=6)
for gx in range(0, W, 256):
    d.line([(gx, 0), (gx, H)], fill=(0, 200, 255), width=2)
for gy in range(0, H, 256):
    d.line([(0, gy), (W, gy)], fill=(0, 200, 255), width=2)
ov = ov.resize((1408, 1408), Image.LANCZOS)
ov.save(os.path.join(out, "sat_overview_grid.png"))
print("overview saved")
