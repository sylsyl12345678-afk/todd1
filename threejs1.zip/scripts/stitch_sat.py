# -*- coding: utf-8 -*-
"""Stitch satellite tiles (Amap + Esri) around the campus for visual reference."""
import math
import os
import ssl
import urllib.request

from PIL import Image

ROOT = r"C:\Users\32311\Desktop\threejs1"
OUT = os.path.join(ROOT, "assets", "ref")
os.makedirs(OUT, exist_ok=True)
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"


def deg2tile(lat, lon, z):
    n = 2 ** z
    x = (lon + 180.0) / 360.0 * n
    y = (1.0 - math.log(math.tan(math.radians(lat)) + 1.0 / math.cos(math.radians(lat))) / math.pi) / 2.0 * n
    return x, y


def fetch(url, timeout=45):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://www.amap.com/"})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()


def stitch(provider, z, x0, y0, cols, rows, name):
    canvas = Image.new("RGB", (256 * cols, 256 * rows), (20, 30, 40))
    for j in range(rows):
        for i in range(cols):
            x = x0 + i
            y = y0 + j
            if provider == "amap":
                url = f"https://webst0{(i + j) % 4 + 1}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}"
            else:
                url = f"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
            try:
                data = fetch(url)
                tile = Image.open(__import__("io").BytesIO(data)).convert("RGB")
                canvas.paste(tile, (i * 256, j * 256))
            except Exception as e:
                print("tile fail", provider, z, x, y, e)
    path = os.path.join(OUT, name)
    canvas.save(path)
    print("saved", path, canvas.size)


# campus approx center (114.0421, 30.3209)
cx, cy = deg2tile(30.3209, 114.0421, 17)
x0 = int(cx) - 5
y0 = int(cy) - 5
print("z17 center tile", cx, cy, "start", x0, y0)
stitch("amap", 17, x0, y0, 11, 11, "amap_z17.png")
stitch("esri", 17, x0, y0, 11, 11, "esri_z17.png")

# wider context z15
cx, cy = deg2tile(30.3209, 114.0421, 15)
x0 = int(cx) - 1
y0 = int(cy) - 1
print("z15 center tile", cx, cy, "start", x0, y0)
stitch("amap", 15, x0, y0, 3, 3, "amap_z15.png")

# metadata for mapping
meta = {
    "center": {"lat": 30.3208749, "lon": 114.0420921},
    "z17": {"x0": int(deg2tile(30.3209, 114.0421, 17)[0]) - 5, "y0": int(deg2tile(30.3209, 114.0421, 17)[1]) - 5, "cols": 11, "rows": 11},
}
import json
with open(os.path.join(OUT, "meta.json"), "w", encoding="utf-8") as f:
    json.dump(meta, f, ensure_ascii=False, indent=1)
print(json.dumps(meta, ensure_ascii=False))
