﻿from PIL import Image, ImageDraw, ImageFont
im = Image.open(r"C:\Users\32311\Desktop\threejs1\assets\campus-map.jpg").convert("RGB")
box=(80,380,480,700)
c=im.crop(box); s=3
c=c.resize((c.width*s,c.height*s), Image.LANCZOS)
d=ImageDraw.Draw(c); f=ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc",20)
for gx in range(box[0]//25*25, box[2]+1,25):
    X=(gx-box[0])*s
    d.line([(X,0),(X,c.height)],fill=(0,150,255) if gx%100==0 else (150,220,255),width=1)
    if gx%50==0: d.text((X+2,2),str(gx),fill=(220,0,0),font=f)
for gy in range(box[1]//25*25, box[3]+1,25):
    Y=(gy-box[1])*s
    d.line([(0,Y),(c.width,Y)],fill=(0,150,255) if gy%100==0 else (150,220,255),width=1)
    if gy%50==0: d.text((2,Y+1),str(gy),fill=(220,0,0),font=f)
c.save(r"C:\Users\32311\Desktop\threejs1\assets\analysis\west_boundary_zoom.png")
print(c.size)
