﻿from PIL import Image
import numpy as np
im = Image.open(r"C:\Users\32311\Desktop\threejs1\assets\logo.png").convert("RGBA")
a = np.asarray(im)[:, :100, :]
mask = (a[:,:,:3].min(axis=2) < 245) & (a[:,:,3] > 10)
ys, xs = np.nonzero(mask)
print("bbox", xs.min(), ys.min(), xs.max(), ys.max())
badge = im.crop((int(xs.min()), int(ys.min()), int(xs.max())+1, int(ys.max())+1))
arr = np.asarray(badge).copy()
white = (arr[:,:,0]>246)&(arr[:,:,1]>246)&(arr[:,:,2]>246)
arr[:,:,3] = np.where(white, 0, arr[:,:,3])
badge = Image.fromarray(arr)
side = max(badge.size)+8
canvas = Image.new("RGBA",(side,side),(0,0,0,0))
canvas.paste(badge, ((side-badge.width)//2,(side-badge.height)//2), badge)
canvas.save(r"C:\Users\32311\Desktop\threejs1\assets\badge.png")
print("badge", canvas.size)
