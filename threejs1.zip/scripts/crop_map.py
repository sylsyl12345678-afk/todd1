# -*- coding: utf-8 -*-
"""Crop the official master plan into readable tiles."""
import os
from PIL import Image

ROOT = r"C:\Users\32311\Desktop\threejs1"
src = os.path.join(ROOT, "assets", "campus-map.jpg")
out = os.path.join(ROOT, "assets", "crops")
os.makedirs(out, exist_ok=True)
im = Image.open(src).convert("RGB")
W, H = im.size
print("size", W, H)

# 3x3 overlapping grid, upscale 2.2x for OCR by eye
cols, rows = 3, 3
overlap = 60
cw = W // cols
ch = H // rows
for r in range(rows):
    for c in range(cols):
        x0 = max(0, c * cw - overlap)
        y0 = max(0, r * ch - overlap)
        x1 = min(W, (c + 1) * cw + overlap)
        y1 = min(H, (r + 1) * ch + overlap)
        crop = im.crop((x0, y0, x1, y1))
        crop = crop.resize((int(crop.width * 2.2), int(crop.height * 2.2)), Image.LANCZOS)
        name = f"r{r}c{c}.png"
        crop.save(os.path.join(out, name))
        print(name, crop.size)
