﻿import re
p = r"C:\Users\32311\Desktop\threejs1\scripts\shot.py"
s = open(p, encoding="utf-8").read()
if 'mobile' not in s:
    s = s.replace('    ("tour", "shot=1&view=overview&tour=1", 1440, 880),',
                  '    ("tour", "shot=1&view=overview&tour=1", 1440, 880),\n    ("mobile", "shot=1&view=overview", 420, 860),')
    s = s.replace('run(s, dump_dom=(s[0] in ("overview_ui", "overview_noadapt", "night", "night_overview")))',
                  'run(s, dump_dom=(s[0] in ("overview_ui", "overview_noadapt", "night", "night_overview", "mobile")))')
open(p,"w",encoding="utf-8").write(s)
print("mobile state added")
