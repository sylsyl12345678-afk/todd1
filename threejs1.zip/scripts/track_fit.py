﻿import numpy as np
from PIL import Image, ImageFilter
im = np.asarray(Image.open(r"C:\Users\32311\Desktop\threejs1\assets\campus-map.jpg").convert("RGB")).astype(int)
r,g,b = im[...,0],im[...,1],im[...,2]
mask = ((r>130)&(r-g>30)&(r-b>25)).astype(np.uint8)*255
mask = np.asarray(Image.fromarray(mask,"L").filter(ImageFilter.MinFilter(5)))>128
mask[:460,:]=False; mask[830:,:]=False; mask[:,:120]=False; mask[:,500:]=False
ys,xs=np.nonzero(mask)
print("pixels",len(xs),"center",round(xs.mean(),1),round(ys.mean(),1))
pts=np.stack([xs-xs.mean(),ys-ys.mean()],1).astype(float)
cov=np.cov(pts.T); evals,evecs=np.linalg.eigh(cov)
order=np.argsort(evals)[::-1]; major=evecs[:,order[0]]; minor=evecs[:,order[1]]
projM=pts@major; projm=pts@minor
print("major",np.round(major,3),"len",round(projM.max()-projM.min(),1))
print("minor",np.round(minor,3),"len",round(projm.max()-projm.min(),1))
print("angle_deg",round(np.degrees(np.arctan2(major[1],major[0])),1))
print("bbox", xs.min(),xs.max(),ys.min(),ys.max())
