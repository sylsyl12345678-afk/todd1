﻿import json, urllib.request, urllib.parse, ssl
ctx = ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
def get(url, timeout=40):
    req=urllib.request.Request(url, headers={'User-Agent':UA,'Accept':'application/json'})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return json.loads(r.read().decode('utf-8','replace'))
def show(label, j):
    print('==',label)
    for f in j.get('features', [])[:6]:
        p=f['properties']; g=f['geometry']
        print(' ', p.get('name'), '|', p.get('osm_value') or p.get('type'), '|', g['type'], str(g['coordinates'])[:80], '|', p.get('street'), p.get('district'), p.get('city'))
for q in ['湖北国土资源职业学院','武汉铁路桥梁职业学院','湾湖站','育才路 汉南','纱帽 汉南 大学','马影河']:
    try:
        j=get('https://photon.komoot.io/api/?q='+urllib.parse.quote(q)+'&limit=8&lang=default')
        show(q, j)
    except Exception as e:
        print(q,'FAIL',repr(e))
# reverse of OSM way center and crop_sw campus
for lat,lon,label in [(30.3209,114.0421,'OSM-way-center'),(30.3093,114.0358,'cropSW-campus'),(30.3170,114.0420,'south-of-way'),(30.3250,114.0400,'north-of-way')]:
    try:
        j=get(f'https://photon.komoot.io/reverse?lat={lat}&lon={lon}&limit=4&lang=default')
        print('== reverse',label,lat,lon)
        for f in j.get('features',[]):
            p=f['properties']; print('  ',p.get('name'),'|',p.get('osm_value'),p.get('street'),p.get('district'),p.get('city'))
    except Exception as e:
        print('reverse FAIL',label,repr(e))
