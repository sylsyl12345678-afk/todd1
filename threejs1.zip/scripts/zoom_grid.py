﻿# -*- coding: utf-8 -*-
import os
from PIL import Image, ImageDraw, ImageFont
ROOT = r"C:\Users\32311\Desktop\threejs1"
im = Image.open(os.path.join(ROOT,"assets","campus-map.jpg")).convert("RGB")
OUT = os.path.join(ROOT,"assets","analysis"); os.makedirs(OUT, exist_ok=True)
font = ImageFont.truetype(r"C:\Windows\Fonts\msyh.ttc", 18)
regions = {
 "zoom_nw": (300, 20, 760, 360),
 "zoom_central": (520, 280, 1010, 640),
 "zoom_south": (120, 600, 780, 972),
 "zoom_east": (820, 150, 1144, 700),
}
for name, box in regions.items():
    c = im.crop(box)
    scale = 2.0
    c = c.resize((int(c.width*scale), int(c.height*scale)), Image.LANCZOS)
    d = ImageDraw.Draw(c)
    x0, y0 = box[0], box[1]
    # grid every 25 plan px, labels every 50
    gx = (x0 // 25) * 25
    while gx <= box[2]:
        X = (gx - x0) * scale
        d.line([(X,0),(X,c.height)], fill=(0,170,255) if gx % 100 == 0 else ((0,120,220) if gx%50==0 else (150,220,255)), width=1)
        if gx % 50 == 0:
            d.text((X+2, 2), str(gx), fill=(220,0,0), font=font)
        gx += 25
    gy = (y0 // 25) * 25
    while gy <= box[3]:
        Y = (gy - y0) * scale
        d.line([(0,Y),(c.width,Y)], fill=(0,170,255) if gy % 100 == 0 else ((0,120,220) if gy%50==0 else (150,220,255)), width=1)
        if gy % 50 == 0:
            d.text((2, Y+1), str(gy), fill=(220,0,0), font=font)
        gy += 25
    c.save(os.path.join(OUT, name+".png"))
    print(name, c.size)
