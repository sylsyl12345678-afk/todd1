﻿# crop south shore region from scene ground to debug river
from PIL import Image
im = Image.open(r"C:\Users\32311\Desktop\threejs1\assets\scene\ground.jpg")
# scene is 1600x1400m, 1.92 px/m ; south campus boundary z~150..280 -> tex y (z+700)*1.92
x0 = int((-450+800)*1.92); x1 = int((450+800)*1.92)
y0 = int((100+700)*1.92); y1 = int((420+700)*1.92)
c = im.crop((x0,y0,x1,y1))
c.resize((1400, int(1400*c.height/c.width))).save(r"C:\Users\32311\Desktop\threejs1\assets\analysis\south_debug.jpg", quality=88)
print(c.size, x0,y0,x1,y1)
