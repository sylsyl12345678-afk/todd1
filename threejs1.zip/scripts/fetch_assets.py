# -*- coding: utf-8 -*-
"""Download assets + geodata for the Hubei Land Resources Vocational College 3D campus."""
import json
import os
import ssl
import urllib.parse
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "assets")
VENDOR = os.path.join(ROOT, "vendor")
DATA = os.path.join(ROOT, "scripts", "data")
for d in (ASSETS, VENDOR, DATA):
    os.makedirs(d, exist_ok=True)

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"


def fetch(url, out_path=None, timeout=90, raw=False):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Referer": "https://www.hbgt.edu.cn/"})
    with urllib.request.urlopen(req, timeout=timeout, context=CTX) as r:
        data = r.read()
    print(f"OK {r.status} {len(data):>9} bytes  {url}")
    if out_path and not raw:
        with open(out_path, "wb") as f:
            f.write(data)
    return data


def main():
    # 1) three.js UMD builds (try newest that still ships UMD, fall back)
    candidates = [
        ("https://cdn.jsdelivr.net/npm/three@0.159.0/build/three.min.js", "three.min.js"),
        ("https://cdn.jsdelivr.net/npm/three@0.147.0/build/three.min.js", "three.min.js"),
    ]
    for url, name in candidates:
        try:
            fetch(url, os.path.join(VENDOR, name))
            break
        except Exception as e:
            print("FAIL", url, e)

    # 2) official campus map + logo + school badge images
    imgs = {
        "campus-map.jpg": "https://www.hbgt.edu.cn/__local/C/E8/77/7D93CF74D5DEB0EE0AE1EB29A66_B8AC3DBB_3AB5F.jpg",
        "logo.png": "https://www.hbgt.edu.cn/img/logo.png",
        "xxbs1.png": "https://www.hbgt.edu.cn/__local/4/DD/72/D36922CD89231C8FB70B271D5ED_CB6B3B5D_8277.png",
        "xxbs2.png": "https://www.hbgt.edu.cn/__local/0/6B/13/60B74D981568E9DA5B73A76384B_B911F112_826A.png",
        "xxbs3.png": "https://www.hbgt.edu.cn/__local/1/EE/1F/29B523DA4C12B420631E121A134_54E86DEE_8203.png",
        "xxbs4.jpg": "https://www.hbgt.edu.cn/__local/A/28/C9/726FE23AA6E4B6D9347A5436F38_4B990850_E0ED.jpg",
        "xxbs5.png": "https://www.hbgt.edu.cn/__local/D/22/5B/A56CD0A9356EC8C37D739B5F2F2_12C0E8AE_19AA4.png",
        "xxbs6.png": "https://www.hbgt.edu.cn/__local/6/81/DB/F729AF8B566F14B0370A7B40946_819815D6_46A53.png",
    }
    for name, url in imgs.items():
        try:
            fetch(url, os.path.join(ASSETS, name))
        except Exception as e:
            print("FAIL", name, e)

    # 3) Nominatim geocode
    q = urllib.parse.quote("湖北国土资源职业学院")
    url = f"https://nominatim.openstreetmap.org/search?q={q}&format=jsonv2&addressdetails=1&limit=5"
    try:
        data = fetch(url)
        with open(os.path.join(DATA, "nominatim.json"), "wb") as f:
            f.write(data)
        print(json.dumps(json.loads(data), ensure_ascii=False, indent=1)[:1500])
    except Exception as e:
        print("Nominatim FAIL", e)

    # 4) Overpass around 汉南育才路 area (approx campus center; refine later from map image)
    #    30.30N, 114.07E is the Hanyang-Hannan area of Wuhan
    bbox = "30.288,114.055,30.320,114.090"
    query = f"""
[out:json][timeout:90];
(
  way["building"]({bbox});
  way["highway"]({bbox});
  way["waterway"]({bbox});
  way["natural"="water"]({bbox});
  relation["natural"="water"]({bbox});
  way["landuse"]({bbox});
  way["leisure"]({bbox});
  node["railway"="station"]({bbox});
  node["amenity"="school"]({bbox});
  way["amenity"="school"]({bbox});
  way["amenity"="university"]({bbox});
);
out geom;
"""
    try:
        req = urllib.request.Request(
            "https://overpass-api.de/api/interpreter",
            data=urllib.parse.urlencode({"data": query}).encode(),
            headers={"User-Agent": UA},
        )
        with urllib.request.urlopen(req, timeout=120, context=CTX) as r:
            data = r.read()
            print("Overpass OK", r.status, len(data), "bytes")
            with open(os.path.join(DATA, "overpass.json"), "wb") as f:
                f.write(data)
    except Exception as e:
        print("Overpass FAIL", e)


if __name__ == "__main__":
    main()
