# -*- coding: utf-8 -*-
"""
Build the stylized ground texture + water mask + tree points for the 3D campus.

Input : assets/campus-map.jpg  (official master plan, 1144x972)
Output: assets/analysis/ground_preview.jpg  (review)
        assets/scene/ground.jpg               (3072x2688 scene map, 1600x1400 m)
        js/ground-tex.js                      (base64 texture string)
        js/ground-data.js                     (water mask URI, tree points)
        assets/analysis/trees_preview.jpg
"""
import base64
import io
import json
import math
import os
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = r"C:\Users\32311\Desktop\threejs1"
PLAN = os.path.join(ROOT, "assets", "campus-map.jpg")
ANA = os.path.join(ROOT, "assets", "analysis")
SCENE = os.path.join(ROOT, "assets", "scene")
os.makedirs(ANA, exist_ok=True)
os.makedirs(SCENE, exist_ok=True)

# ---------------- world mapping ----------------
S = 0.62                       # meters per plan pixel
CX, CZ = 572.0, 486.0          # plan pixel center -> world origin
SCENE_W, SCENE_D = 1600.0, 1400.0   # meters
TW, TH = 3072, 2688            # texture px  (1.92 px/m; fixed by aspect)
PXM = TW / SCENE_W


def plan_to_world(px, py):
    return (px - CX) * S, (py - CZ) * S


def world_to_tex(x, z):
    return (x + SCENE_W / 2) * PXM, (z + SCENE_D / 2) * PXM


# ---------------- palette ----------------
PAL = {
    "water_deep": (34, 82, 104),
    "water": (46, 112, 132),
    "water_shallow": (78, 142, 152),
    "canopy": (46, 78, 42),
    "canopy_light": (62, 96, 52),
    "lawn": (98, 138, 68),
    "lawn_light": (116, 154, 80),
    "sport": (104, 152, 82),
    "track": (176, 98, 78),
    "court": (86, 134, 94),
    "road": (102, 106, 112),
    "road_light": (124, 127, 132),
    "pave": (198, 190, 166),
    "pave_light": (211, 203, 181),
    "building": (213, 208, 194),
    "soil": (184, 176, 138),
    "shadow": (42, 64, 38),
    "sand": (178, 164, 124),
}
CATS = ["water", "canopy", "canopy_light", "lawn", "lawn_light", "sport", "track",
        "court", "road", "road_light", "pave", "pave_light", "building", "soil",
        "shadow", "sand"]
CAT_IDX = {c: i for i, c in enumerate(CATS)}
IDX_TO_RGB = np.array([PAL[c] for c in CATS], dtype=np.uint8)


def classify(im):
    arr = np.asarray(im).astype(np.float32) / 255.0
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    mx = arr.max(2)
    mn = arr.min(2)
    diff = mx - mn
    s = np.where(mx > 1e-6, diff / np.maximum(mx, 1e-6), 0)
    # hue in degrees
    h = np.zeros_like(mx)
    d = np.maximum(diff, 1e-6)
    m = (mx == r)
    h[m] = ((g - b)[m] / d[m]) % 6
    m = (mx == g) & ~(mx == r)
    h[m] = ((b - r)[m] / d[m]) + 2
    m = (mx == b) & ~(mx == r) & ~(mx == g)
    h[m] = ((r - g)[m] / d[m]) + 4
    h = (h * 60) % 360
    v = mx

    idx = np.full(mx.shape, CAT_IDX["soil"], dtype=np.uint8)

    def put(mask, cat):
        idx[mask] = CAT_IDX[cat]

    put((v < 0.30) & (s > 0.18), "shadow")
    put((h >= 175) & (h <= 245) & (s > 0.22) & (v > 0.25), "water")
    put((b > r + 0.05) & (b > g + 0.02) & (b > 0.45) & (s > 0.18) & (v > 0.25), "water")
    put((v > 0.93) & (s < 0.08), "building")
    put((v > 0.80) & (s < 0.13), "pave_light")
    put((v > 0.70) & (s < 0.16), "pave")
    put(((h < 16) | (h > 345)) & (s > 0.33) & (v > 0.38), "track")
    put((h >= 60) & (h < 175) & (s > 0.20) & (v > 0.62), "sport")
    put((h >= 60) & (h < 175) & (s > 0.24) & (v > 0.42) & (v <= 0.62), "lawn")
    put((h >= 60) & (h < 175) & (s > 0.22) & (v > 0.30) & (v <= 0.42), "canopy_light")
    put((h >= 60) & (h < 175) & (s > 0.20) & (v <= 0.30), "canopy")
    put((s < 0.16) & (v > 0.42) & (v <= 0.70), "road")
    put((s < 0.16) & (v > 0.30) & (v <= 0.42), "road_light")
    put((h >= 20) & (h < 60) & (s < 0.30) & (v > 0.55), "pave")
    return idx


def extract_boundary(plan_img):
    """Trace the red property line (用地红线) radially from the plan centroid,
    smooth it and return a simplified polygon in plan pixels."""
    a = np.asarray(plan_img).astype(np.int16)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    red = (r > 120) & (r - g > 40) & (r - b > 40) & (g < 155)
    cx, cy = 572.0, 486.0
    N = 720
    pts = []
    for i in range(N):
        th = i / N * math.tau
        dx, dy = math.cos(th), math.sin(th)
        rr = None
        for step in range(760, 40, -2):
            x = int(cx + dx * step)
            y = int(cy + dy * step)
            if 0 <= x < red.shape[1] and 0 <= y < red.shape[0]:
                found = False
                for oy in (-2, -1, 0, 1, 2):
                    for ox in (-2, -1, 0, 1, 2):
                        xx, yy = x + ox, y + oy
                        if 0 <= xx < red.shape[1] and 0 <= yy < red.shape[0] and red[yy, xx]:
                            found = True
                            break
                    if found:
                        break
                if found:
                    rr = step
                    break
        if rr is None:
            pts.append(None)
        else:
            pts.append((cx + dx * rr, cy + dy * rr))
    # fill missing angles / outliers
    known = [p for p in pts if p is not None]
    med_r = np.median([math.hypot(p[0] - cx, p[1] - cy) for p in known])
    for i, p in enumerate(pts):
        if p is None or abs(math.hypot(p[0] - cx, p[1] - cy) - med_r) > med_r * 0.55:
            # average nearest known neighbors
            prev = next(n for n in range(1, N) if pts[(i - n) % N] is not None)
            nxt = next(n for n in range(1, N) if pts[(i + n) % N] is not None)
            p0, p1 = pts[(i - prev) % N], pts[(i + nxt) % N]
            pts[i] = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
    # circular smoothing
    for _ in range(3):
        sm = []
        for i in range(N):
            xs = [pts[(i + k) % N][0] for k in range(-3, 4)]
            ys = [pts[(i + k) % N][1] for k in range(-3, 4)]
            sm.append((sum(xs) / 7, sum(ys) / 7))
        pts = sm
    poly = pts[::4]

    def rdp(points, eps):
        if len(points) < 3:
            return points
        # closed polygon simplification: split at far point from first
        p0, p1 = np.array(points[0]), np.array(points[len(points) // 2])
        def rec(seq):
            if len(seq) < 3:
                return seq
            a0, a1 = np.array(seq[0]), np.array(seq[-1])
            d = a1 - a0
            ln = np.linalg.norm(d)
            if ln < 1e-6:
                return [seq[0], seq[-1]]
            dists = [abs(np.cross(d, np.array(p) - a0)) / ln for p in seq[1:-1]]
            if not dists:
                return [seq[0], seq[-1]]
            imax = int(np.argmax(dists))
            if dists[imax] > eps:
                left = rec(seq[:imax + 2])
                right = rec(seq[imax + 1:])
                return left[:-1] + right
            return [seq[0], seq[-1]]
        half = len(points) // 2
        left = rec(points[:half + 1])
        right = rec(points[half:] + [points[0]])
        return left[:-1] + right[:-1]
    poly = rdp(poly, 4.0)
    return [(float(x), float(y)) for x, y in poly]


def polygon_world(poly_px):
    return [plan_to_world(x, y) for x, y in poly_px]


def offset_polygon(poly_world, offset):
    """Approximate outward offset by moving each vertex away from the polygon centroid."""
    cx = sum(p[0] for p in poly_world) / len(poly_world)
    cz = sum(p[1] for p in poly_world) / len(poly_world)
    out = []
    for x, z in poly_world:
        dx, dz = x - cx, z - cz
        ln = math.hypot(dx, dz) or 1.0
        out.append((x + dx / ln * offset, z + dz / ln * offset))
    return out


def mode_filter(idx, k=5):
    im = Image.fromarray(idx, mode="L")
    im = im.filter(ImageFilter.ModeFilter(size=k))
    im = im.filter(ImageFilter.ModeFilter(size=3))
    return np.asarray(im, dtype=np.uint8)


# ---------------- surroundings painter ----------------
def paint_surroundings(W, H, rng):
    img = Image.new("RGB", (W, H), (150, 154, 112))
    d = ImageDraw.Draw(img, "RGBA")

    def w2t(x, z):
        return ((x + SCENE_W / 2) * PXM, (z + SCENE_D / 2) * PXM)

    # ---- farmland mosaic around everything ----
    greens = [(122, 140, 88), (138, 152, 96), (108, 130, 82), (150, 158, 104),
              (132, 148, 92), (96, 120, 76), (160, 160, 108), (142, 146, 94)]
    for _ in range(1500):
        cx = rng.uniform(-SCENE_W / 2 - 120, SCENE_W / 2 + 120)
        cz = rng.uniform(-SCENE_D / 2 - 120, SCENE_D / 2 + 120)
        w = rng.uniform(24, 110)
        h = rng.uniform(14, 70)
        ang = rng.uniform(-40, 40)
        col = list(rng.choice(greens)) + [rng.randint(120, 220)]
        px, py = w2t(cx, cz)
        poly = []
        for dx, dy in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)):
            a = math.radians(ang)
            rx = dx * math.cos(a) - dy * math.sin(a)
            ry = dx * math.sin(a) + dy * math.cos(a)
            poly.append((px + rx * PXM, py + ry * PXM))
        d.polygon(poly, fill=tuple(col))

    # hedgerows
    for _ in range(260):
        cx = rng.uniform(-SCENE_W / 2 - 100, SCENE_W / 2 + 100)
        cz = rng.uniform(-SCENE_D / 2 - 100, SCENE_D / 2 + 100)
        px, py = w2t(cx, cz)
        ang = rng.uniform(-40, 40)
        ln = rng.uniform(18, 70) * PXM
        a = math.radians(ang)
        x2, y2 = px + ln * math.cos(a), py + ln * math.sin(a)
        d.line([(px, py), (x2, y2)], fill=(70, 96, 60, 200), width=max(2, int(rng.uniform(2, 5))))

    # ---- 湾湖 lake (north-west) ----
    lake = [w2t(-880, -520), w2t(-700, -480), w2t(-560, -430), w2t(-470, -350),
            w2t(-490, -250), w2t(-600, -200), w2t(-760, -210), w2t(-860, -300)]
    d.polygon(lake, fill=(160, 158, 122))
    lake_in = [w2t(-850, -490), w2t(-700, -455), w2t(-580, -410), w2t(-520, -345),
               w2t(-540, -280), w2t(-620, -240), w2t(-740, -245), w2t(-820, -320)]
    d.polygon(lake_in, fill=(46, 104, 124))
    lake_core = [w2t(-780, -450), w2t(-670, -420), w2t(-590, -380), w2t(-570, -330),
                 w2t(-630, -300), w2t(-720, -310)]
    d.polygon(lake_core, fill=(40, 92, 114))

    # ---- 马影河 river (south) ----
    river_top = [w2t(-900, 330), w2t(-700, 290), w2t(-500, 300), w2t(-320, 300),
                 w2t(-120, 265), w2t(90, 228), w2t(300, 195), w2t(520, 178),
                 w2t(760, 190), w2t(900, 215)]
    river_bot = [w2t(900, 355), w2t(700, 330), w2t(480, 315), w2t(260, 320),
                 w2t(60, 350), w2t(-140, 385), w2t(-340, 405), w2t(-520, 408),
                 w2t(-700, 390), w2t(-900, 420)]
    d.polygon(river_top + river_bot[::-1], fill=(169, 160, 122))
    rt_in = [w2t(-900, 350), w2t(-700, 315), w2t(-500, 322), w2t(-320, 322),
             w2t(-120, 288), w2t(90, 250), w2t(300, 218), w2t(520, 200),
             w2t(760, 214), w2t(900, 238)]
    rb_in = [w2t(900, 330), w2t(700, 305), w2t(480, 292), w2t(260, 296),
             w2t(60, 326), w2t(-140, 358), w2t(-340, 378), w2t(-520, 382),
             w2t(-700, 365), w2t(-900, 395)]
    d.polygon(rt_in + rb_in[::-1], fill=(44, 102, 122))
    rt_c = [w2t(-900, 368), w2t(-700, 332), w2t(-500, 340), w2t(-320, 340),
            w2t(-120, 305), w2t(90, 268), w2t(300, 236), w2t(520, 218),
            w2t(760, 232), w2t(900, 256)]
    rb_c = [w2t(900, 315), w2t(700, 290), w2t(480, 278), w2t(260, 282),
            w2t(60, 310), w2t(-140, 340), w2t(-340, 360), w2t(-520, 365),
            w2t(-700, 348), w2t(-900, 378)]
    d.polygon(rt_c + rb_c[::-1], fill=(37, 88, 108))

    # ---- 坛山岛 wetland (south of river) ----
    for _ in range(90):
        cx = rng.uniform(-300, 800)
        cz = rng.uniform(420, 700)
        px, py = w2t(cx, cz)
        rw = rng.uniform(16, 70) * PXM
        rh = rng.uniform(10, 36) * PXM
        d.ellipse([px - rw, py - rh, px + rw, py + rh],
                  fill=(rng.choice([(58, 112, 118), (74, 126, 126), (92, 138, 128)])) + (rng.randint(150, 230),))
    for _ in range(120):
        cx = rng.uniform(-350, 850)
        cz = rng.uniform(400, 720)
        px, py = w2t(cx, cz)
        d.ellipse([px - rng.uniform(3, 14) * PXM, py - rng.uniform(2, 8) * PXM,
                   px + rng.uniform(3, 14) * PXM, py + rng.uniform(2, 8) * PXM],
                  fill=(rng.choice([(84, 120, 66), (96, 132, 74), (110, 146, 82)])) + (220,))

    # ---- roads (outside campus) ----
    road_col = PAL["road"] + (255,)
    def road(pts, width_m, casing=True):
        p = [w2t(x, z) for x, z in pts]
        wpx = max(2, int(width_m * PXM))
        if casing:
            d.line(p, fill=(168, 162, 142, 255), width=wpx + int(9 * PXM), joint="curve")
        d.line(p, fill=road_col, width=wpx, joint="curve")
        # dashed center line
        for i in range(len(p) - 1):
            x1, y1 = p[i]; x2, y2 = p[i + 1]
            seg = math.hypot(x2 - x1, y2 - y1)
            if seg < 1:
                continue
            n = max(1, int(seg / (14 * PXM)))
            for k in range(n):
                t0 = k / n; t1 = min(1, t0 + 0.42 / n)
                xa, ya = x1 + (x2 - x1) * t0, y1 + (y2 - y1) * t0
                xb, yb = x1 + (x2 - x1) * t1, y1 + (y2 - y1) * t1
                d.line([(xa, ya), (xb, yb)], fill=(226, 220, 196, 235), width=max(1, int(0.28 * PXM)))

    # 育才路 north of campus
    road([(-820, -318), (-500, -300), (-200, -296), (120, -306), (420, -330), (760, -360)], 17)
    # east road (荆山路?)
    road([(408, -720), (398, -420), (392, -180), (388, 120), (380, 420), (360, 650)], 15)
    # west / riverside road
    road([(-840, 250), (-600, 245), (-430, 262), (-330, 285), (-120, 245), (120, 205),
          (340, 172), (560, 160), (800, 180)], 12)
    # north expressway (metro corridor)
    road([(-820, -610), (-420, -600), (0, -596), (420, -598), (820, -606)], 20)

    # ---- metro line 16 corridor hint (elevated) ----
    viaduct = [w2t(x, z) for x, z in [(-900, -566), (-400, -560), (60, -558), (520, -562), (900, -572)]]
    d.line(viaduct, fill=(196, 196, 190, 255), width=max(2, int(6 * PXM)))
    d.line(viaduct, fill=(150, 152, 150, 255), width=max(1, int(2.4 * PXM)))
    return img


def build():
    plan = Image.open(PLAN).convert("RGB")
    idx = classify(plan)
    idx = mode_filter(idx, 5)
    rgb = IDX_TO_RGB[idx].astype(np.uint8)
    col = Image.fromarray(rgb, "RGB")
    # soften slightly
    col = col.filter(ImageFilter.GaussianBlur(0.7))

    rng = random.Random(20241018)
    scene = paint_surroundings(TW, TH, rng)

    # paste campus plan into scene
    px0, py0 = world_to_tex(-CX * S, -CZ * S)
    px1, py1 = world_to_tex((plan.width - CX) * S, (plan.height - CZ) * S)
    dst_box = (int(round(px0)), int(round(py0)), int(round(px1)), int(round(py1)))
    col_resized = col.resize((dst_box[2] - dst_box[0], dst_box[3] - dst_box[1]), Image.LANCZOS)

    # feather mask for smooth blending into surroundings
    mask = Image.new("L", col_resized.size, 255)
    md = ImageDraw.Draw(mask)
    feather = 26
    md.rectangle([0, 0, mask.width, mask.height], fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(0))
    mask = Image.eval(mask, lambda v: v)
    # keep full opacity, but soften outermost 18 px
    arr = np.asarray(mask).astype(np.float32)
    gx = np.linspace(0, 1, arr.shape[1])
    gy = np.linspace(0, 1, arr.shape[0])
    edge = np.minimum.reduce([np.tile(gx, (arr.shape[0], 1)), np.tile(1 - gx, (arr.shape[0], 1)),
                              np.tile(gy[:, None], (1, arr.shape[1])), np.tile(1 - gy[:, None], (1, arr.shape[1]))])
    arr *= np.clip(edge / 0.03, 0, 1)
    mask = Image.fromarray(arr.astype(np.uint8), "L")
    scene.paste(col_resized, dst_box[:2], mask)

    # ---- subtle grain / detail ----
    noise_rng = np.random.default_rng(7)
    small = noise_rng.normal(0, 1, (TH // 3, TW // 3)).astype(np.float32)
    small = np.clip(small, -2.2, 2.2)
    noise = np.array(Image.fromarray(((small + 2.2) / 4.4 * 255).astype(np.uint8), "L").resize((TW, TH), Image.BILINEAR)).astype(np.float32)
    base = np.asarray(scene).astype(np.float32)
    factor = 0.93 + (noise[..., None] / 255.0) * 0.13
    base = np.clip(base * factor, 0, 255).astype(np.uint8)
    scene = Image.fromarray(base, "RGB")

    # ---------------- water mask ----------------
    # water = plan water region + painted river/lake/wetland water tones
    arr = np.asarray(scene).astype(np.float32)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    wat = (b > r + 8) & (b > 70) & (b >= g - 12) & (g > 60) & (b < 190)
    wat = wat.astype(np.uint8) * 255
    wm = Image.fromarray(wat, "L").filter(ImageFilter.ModeFilter(5)).filter(ImageFilter.GaussianBlur(6))
    wm_np = np.asarray(wm).astype(np.float32) / 255.0
    # suppress tiny water blobs (label/glass leftovers) via box blur
    wm_small = np.asarray(Image.fromarray((wm_np * 255).astype(np.uint8), "L").resize((TW // 8, TH // 8), Image.BOX)).astype(np.float32) / 255.0
    wm_small = np.asarray(Image.fromarray(((wm_small > 0.35) * 255).astype(np.uint8), "L").resize((TW, TH), Image.NEAREST)).astype(np.float32) / 255.0
    wm_np = np.minimum(wm_np, wm_small)
    wm_np = np.asarray(Image.fromarray((wm_np * 255).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(4))).astype(np.float32) / 255.0
    water_mask = np.clip(wm_np * 1.6, 0, 1)

    # shallow-water halo: widen water a bit for the shader edge
    water = Image.fromarray((water_mask * 255).astype(np.uint8), "L")
    water.save(os.path.join(SCENE, "water-mask.png"))
    water.save(os.path.join(ANA, "water_mask.png"))

    # ---------------- tree points ----------------
    canopy = (idx == CAT_IDX["canopy"]) | (idx == CAT_IDX["canopy_light"])
    canopy = np.asarray(Image.fromarray(canopy.astype(np.uint8) * 255, "L").filter(ImageFilter.ModeFilter(3))) > 128
    trees = []
    step = 6
    h_, w_ = canopy.shape
    for gy in range(0, h_, step):
        for gx in range(0, w_, step):
            block = canopy[gy:gy + step, gx:gx + step]
            if block.size == 0 or block.mean() < 0.55:
                continue
            px = gx + step / 2 + rng.uniform(-2.2, 2.2)
            py = gy + step / 2 + rng.uniform(-2.2, 2.2)
            x, z = plan_to_world(px, py)
            # tree type: 水杉 (conifer) along south-east grove / near water
            is_metasequoia = (x > 120 and z > 100) or (z > 150 and x > 0 and rng.random() < 0.35)
            if rng.random() < 0.30:
                is_metasequoia = True
            trees.append({"x": round(x, 1), "z": round(z, 1),
                          "t": 1 if is_metasequoia else 0,
                          "s": round(rng.uniform(0.78, 1.35), 2),
                          "r": round(rng.uniform(0, math.tau), 2)})
            if len(trees) > 3000:
                break
        if len(trees) > 3000:
            break

    # surroundings trees (field lines, lake shore, wetland, road sides)
    extra = []
    for _ in range(1100):
        x = rng.uniform(-SCENE_W / 2 + 20, SCENE_W / 2 - 20)
        z = rng.uniform(-SCENE_D / 2 + 20, SCENE_D / 2 - 20)
        # avoid campus rectangle
        if -400 < x < 400 and -330 < z < 340:
            continue
        # river/lake rejection
        u, v = world_to_tex(x, z)
        if 0 <= u < TW and 0 <= v < TH:
            if water_mask[int(v), int(u)] > 0.25:
                continue
        if rng.random() < 0.22:
            extra.append({"x": round(x, 1), "z": round(z, 1), "t": rng.choice([0, 1, 2]),
                          "s": round(rng.uniform(0.9, 1.6), 2), "r": round(rng.uniform(0, math.tau), 2)})
    all_trees = trees + extra
    print("trees:", len(trees), "+", len(extra), "=", len(all_trees))

    # ---------------- outputs ----------------
    scene_path = os.path.join(SCENE, "ground.jpg")
    scene.save(scene_path, quality=88, optimize=True, progressive=True)
    print("ground saved", scene_path, os.path.getsize(scene_path))
    print("water mask saved")

    # previews
    pv = scene.resize((1400, int(1400 * TH / TW)), Image.LANCZOS)
    pv.save(os.path.join(ANA, "ground_preview.jpg"), quality=88)
    # campus-area crop preview
    crop = scene.crop(dst_box).resize((1200, int(1200 * (dst_box[3] - dst_box[1]) / (dst_box[2] - dst_box[0]))), Image.LANCZOS)
    crop.save(os.path.join(ANA, "ground_campus_preview.jpg"), quality=90)

    # trees preview overlay
    tp = scene.copy()
    tdr = ImageDraw.Draw(tp)
    for t in all_trees:
        u, v = world_to_tex(t["x"], t["z"])
        rr = 3 if t["t"] == 1 else 4
        colr = (20, 60, 40) if t["t"] == 1 else (30, 90, 40)
        tdr.ellipse([u - rr, v - rr, u + rr, v + rr], fill=colr)
    tp.resize((1400, int(1400 * TH / TW)), Image.LANCZOS).save(os.path.join(ANA, "trees_preview.jpg"), quality=85)

    # base64 texture js
    with open(scene_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    with open(os.path.join(ROOT, "js", "ground-tex.js"), "w", encoding="utf-8") as f:
        f.write("// auto-generated by scripts/build_ground.py - ground texture (3072x2688)\n")
        f.write("window.GROUND_TEXTURE_URI = 'data:image/jpeg;base64," + b64 + "';\n")

    # water mask base64 (scaled down to 1024 for shader)
    wm_tex = water.resize((1024, 896), Image.LANCZOS)
    buf = io.BytesIO()
    wm_tex.save(buf, format="PNG", optimize=True)
    wm_b64 = base64.b64encode(buf.getvalue()).decode()
    with open(os.path.join(ROOT, "js", "ground-data.js"), "w", encoding="utf-8") as f:
        f.write("// auto-generated by scripts/build_ground.py\n")
        f.write("window.GROUND_DATA = {\n")
        f.write("  S: %s, CX: %s, CZ: %s, SCENE_W: %s, SCENE_D: %s,\n" % (S, CX, CZ, SCENE_W, SCENE_D))
        f.write("  waterMaskURI: 'data:image/png;base64," + wm_b64 + "',\n")
        f.write("  trees: " + json.dumps([[t["x"], t["z"], t["t"], t["s"], t["r"]] for t in all_trees], separators=(",", ":")) + "\n")
        f.write("};\n")
    print("js data saved; tree count", len(all_trees))


if __name__ == "__main__":
    build()
