# -*- coding: utf-8 -*-
"""
Build the stylized ground texture + water mask + tree points + campus boundary
for the 湖北国土资源职业学院 3D campus scene.

Input : assets/campus-map.jpg  (official master plan, 1144x972)
Output: assets/scene/ground.jpg       3072x2688 stylized scene map (1600x1400 m)
        assets/scene/water-mask.png   water alpha map
        js/ground-tex.js              base64 ground texture
        js/ground-data.js             water mask + trees + boundary polygon
        assets/analysis/*.jpg         review previews
"""
import base64
import io
import json
import math
import os
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = r"C:\Users\32311\Desktop\threejs1"
PLAN_PATH = os.path.join(ROOT, "assets", "campus-map.jpg")
ANA = os.path.join(ROOT, "assets", "analysis")
SCENE = os.path.join(ROOT, "assets", "scene")
os.makedirs(ANA, exist_ok=True)
os.makedirs(SCENE, exist_ok=True)

# ---------------- world mapping ----------------
S = 0.62                        # meters per plan pixel
CX, CZ = 572.0, 486.0           # plan pixel center -> world (0,0)
SCENE_W, SCENE_D = 1600.0, 1400.0
TW, TH = 3072, 2688
PXM = TW / SCENE_W


def plan_to_world(px, py):
    return (px - CX) * S, (py - CZ) * S


def world_to_tex(x, z):
    return (x + SCENE_W / 2) * PXM, (z + SCENE_D / 2) * PXM


def w2t(x, z):
    return world_to_tex(x, z)


# ---------------- palette ----------------
PAL = {
    "water_deep": (30, 76, 98),
    "water": (42, 106, 128),
    "water_shallow": (74, 138, 148),
    "canopy": (44, 76, 40),
    "canopy_light": (60, 94, 50),
    "lawn": (96, 136, 66),
    "lawn_light": (114, 152, 78),
    "sport": (102, 150, 80),
    "track": (178, 99, 79),
    "court": (84, 132, 92),
    "road": (100, 104, 110),
    "road_light": (122, 125, 130),
    "pave": (196, 188, 164),
    "pave_light": (210, 202, 180),
    "building": (212, 207, 193),
    "soil": (182, 174, 136),
    "shadow": (40, 62, 36),
    "sand": (176, 162, 122),
}
CATS = ["water", "canopy", "canopy_light", "lawn", "lawn_light", "sport", "track",
        "court", "road", "road_light", "pave", "pave_light", "building", "soil",
        "shadow", "sand"]
CAT_IDX = {c: i for i, c in enumerate(CATS)}
IDX_TO_RGB = np.array([PAL[c] for c in CATS], dtype=np.uint8)


# ---------------- plan classification ----------------
def classify(im):
    arr = np.asarray(im).astype(np.float32) / 255.0
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    mx = arr.max(2)
    mn = arr.min(2)
    diff = mx - mn
    s = np.where(mx > 1e-6, diff / np.maximum(mx, 1e-6), 0)
    h = np.zeros_like(mx)
    d = np.maximum(diff, 1e-6)
    m = (mx == r)
    h[m] = ((g - b)[m] / d[m]) % 6
    m = (mx == g) & ~(mx == r)
    h[m] = ((b - r)[m] / d[m]) + 2
    m = (mx == b) & ~(mx == r) & ~(mx == g)
    h[m] = ((r - g)[m] / d[m]) + 4
    h = (h * 60) % 360
    v = mx

    idx = np.full(mx.shape, CAT_IDX["soil"], dtype=np.uint8)

    def put(mask, cat):
        idx[mask] = CAT_IDX[cat]

    put((v < 0.28) & (s > 0.18), "shadow")
    put((h >= 175) & (h <= 245) & (s > 0.22) & (v > 0.22), "water")
    put((b > r + 0.05) & (b > g + 0.02) & (b > 0.42) & (s > 0.16) & (v > 0.22), "water")
    put((v > 0.92) & (s < 0.08), "building")
    put((v > 0.79) & (s < 0.13), "pave_light")
    put((v > 0.69) & (s < 0.17), "pave")
    put(((h < 18) | (h > 340)) & (s > 0.33) & (v > 0.38), "track")
    put((h >= 60) & (h < 175) & (s > 0.20) & (v > 0.60), "sport")
    put((h >= 60) & (h < 175) & (s > 0.24) & (v > 0.40) & (v <= 0.60), "lawn")
    put((h >= 60) & (h < 175) & (s > 0.22) & (v > 0.28) & (v <= 0.40), "canopy_light")
    put((h >= 60) & (h < 175) & (s > 0.20) & (v <= 0.28), "canopy")
    put((s < 0.17) & (v > 0.40) & (v <= 0.69), "road")
    put((s < 0.17) & (v > 0.28) & (v <= 0.40), "road_light")
    put((h >= 20) & (h < 60) & (s < 0.30) & (v > 0.55), "pave")
    return idx


def mode_filter(idx, k=5):
    im = Image.fromarray(idx, mode="L")
    im = im.filter(ImageFilter.ModeFilter(size=k))
    im = im.filter(ImageFilter.ModeFilter(size=3))
    return np.asarray(im, dtype=np.uint8)


# ---------------- boundary (用地红线) ----------------
def extract_boundary(plan_img):
    a = np.asarray(plan_img).astype(np.int16)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    red = (r > 120) & (r - g > 40) & (r - b > 40) & (g < 155)
    cx, cy = CX, CZ
    N = 720
    pts = []
    for i in range(N):
        th = i / N * math.tau
        dx, dy = math.cos(th), math.sin(th)
        rr = None
        for step in range(760, 40, -2):
            x = int(cx + dx * step)
            y = int(cy + dy * step)
            if not (0 <= x < red.shape[1] and 0 <= y < red.shape[0]):
                continue
            found = False
            for oy in (-2, -1, 0, 1, 2):
                for ox in (-2, -1, 0, 1, 2):
                    xx, yy = x + ox, y + oy
                    if 0 <= xx < red.shape[1] and 0 <= yy < red.shape[0] and red[yy, xx]:
                        found = True
                        break
                if found:
                    break
            if found:
                rr = step
                break
        pts.append(None if rr is None else (cx + dx * rr, cy + dy * rr))
    known = [p for p in pts if p is not None]
    med_r = float(np.median([math.hypot(p[0] - cx, p[1] - cy) for p in known]))
    for i, p in enumerate(pts):
        if p is None or abs(math.hypot(p[0] - cx, p[1] - cy) - med_r) > med_r * 0.6:
            prev = next(n for n in range(1, N) if pts[(i - n) % N] is not None)
            nxt = next(n for n in range(1, N) if pts[(i + n) % N] is not None)
            p0, p1 = pts[(i - prev) % N], pts[(i + nxt) % N]
            pts[i] = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
    for _ in range(3):
        sm = []
        for i in range(N):
            xs = [pts[(i + k) % N][0] for k in range(-3, 4)]
            ys = [pts[(i + k) % N][1] for k in range(-3, 4)]
            sm.append((sum(xs) / 7, sum(ys) / 7))
        pts = sm
    poly = pts[::4]

    def rdp(points, eps):
        def rec(seq):
            if len(seq) < 3:
                return seq
            a0, a1 = np.array(seq[0]), np.array(seq[-1])
            dd = a1 - a0
            ln = np.linalg.norm(dd)
            if ln < 1e-6:
                return [seq[0], seq[-1]]
            dists = [abs(np.cross(dd, np.array(p) - a0)) / ln for p in seq[1:-1]]
            if not dists:
                return [seq[0], seq[-1]]
            imax = int(np.argmax(dists))
            if dists[imax] > eps:
                left = rec(seq[:imax + 2])
                right = rec(seq[imax + 1:])
                return left[:-1] + right
            return [seq[0], seq[-1]]
        half = len(points) // 2
        return rec(points[:half + 1])[:-1] + rec(points[half:] + [points[0]])[:-1]

    poly = rdp(poly, 4.0)
    # drop consecutive duplicates
    out = []
    for p in poly:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > 2:
            out.append((float(p[0]), float(p[1])))
    return out


def offset_from_centroid(poly, offset):
    cx = sum(p[0] for p in poly) / len(poly)
    cz = sum(p[1] for p in poly) / len(poly)
    out = []
    for x, z in poly:
        dx, dz = x - cx, z - cz
        ln = math.hypot(dx, dz) or 1.0
        out.append((x + dx / ln * offset, z + dz / ln * offset))
    return out


def smooth_closed(pts, w=3):
    n = len(pts)
    out = []
    for i in range(n):
        xs = [pts[(i + k) % n][0] for k in range(-w, w + 1)]
        zs = [pts[(i + k) % n][1] for k in range(-w, w + 1)]
        out.append((sum(xs) / len(xs), sum(zs) / len(zs)))
    return out


def boundary_normals(poly):
    """Outward unit normals for each vertex of a closed polygon."""
    n = len(poly)
    ccx = sum(p[0] for p in poly) / n
    ccz = sum(p[1] for p in poly) / n
    out = []
    for i in range(n):
        px, pz = poly[(i - 1) % n]
        cx, cz = poly[i]
        nx, nz = poly[(i + 1) % n]
        e1x, e1z = cx - px, cz - pz
        e2x, e2z = nx - cx, nz - cz
        l1 = math.hypot(e1x, e1z) or 1.0
        l2 = math.hypot(e2x, e2z) or 1.0
        n1x, n1z = e1z / l1, -e1x / l1
        n2x, n2z = e2z / l2, -e2x / l2
        mx, mz = n1x + n2x, n1z + n2z
        ml = math.hypot(mx, mz) or 1.0
        mx, mz = mx / ml, mz / ml
        if (cx - ccx) * mx + (cz - ccz) * mz < 0:
            mx, mz = -mx, -mz
        out.append((mx, mz))
    return out


def offset_closed(poly, dist):
    normals = boundary_normals(poly)
    return [(x + nx * dist, z + nz * dist) for (x, z), (nx, nz) in zip(poly, normals)]


# ---------------- surroundings painter ----------------
def paint_surroundings(W, H, rng, boundary):
    img = Image.new("RGB", (W, H), (146, 150, 108))
    d = ImageDraw.Draw(img, "RGBA")

    # ---- farmland mosaic ----
    greens = [(122, 140, 88), (138, 152, 96), (108, 130, 82), (150, 158, 104),
              (132, 148, 92), (96, 120, 76), (158, 158, 106), (142, 146, 94)]
    for _ in range(1600):
        cx = rng.uniform(-SCENE_W / 2 - 140, SCENE_W / 2 + 140)
        cz = rng.uniform(-SCENE_D / 2 - 140, SCENE_D / 2 + 140)
        w = rng.uniform(22, 120)
        h = rng.uniform(14, 74)
        ang = math.radians(rng.uniform(-42, 42))
        col = list(rng.choice(greens)) + [rng.randint(110, 210)]
        px, py = w2t(cx, cz)
        poly = []
        for dx, dy in ((-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)):
            rx = dx * math.cos(ang) - dy * math.sin(ang)
            ry = dx * math.sin(ang) + dy * math.cos(ang)
            poly.append((px + rx * PXM, py + ry * PXM))
        d.polygon(poly, fill=tuple(col))

    # hedgerows
    for _ in range(300):
        cx = rng.uniform(-SCENE_W / 2 - 100, SCENE_W / 2 + 100)
        cz = rng.uniform(-SCENE_D / 2 - 100, SCENE_D / 2 + 100)
        px, py = w2t(cx, cz)
        ang = math.radians(rng.uniform(-42, 42))
        ln = rng.uniform(18, 70) * PXM
        d.line([(px, py), (px + ln * math.cos(ang), py + ln * math.sin(ang))],
               fill=(66, 92, 56, 190), width=max(2, int(rng.uniform(2, 5))))

    # ---- 湾湖 lake (north-west, outside campus) ----
    lake = [w2t(-940, -560), w2t(-760, -530), w2t(-600, -470), w2t(-500, -380),
            w2t(-520, -270), w2t(-640, -215), w2t(-800, -225), w2t(-920, -320)]
    d.polygon(lake, fill=(164, 158, 118))
    lake2 = [w2t(-900, -525), w2t(-760, -498), w2t(-618, -445), w2t(-550, -370),
             w2t(-566, -295), w2t(-660, -255), w2t(-790, -262), w2t(-872, -330)]
    d.polygon(lake2, fill=(172, 164, 124))
    d.polygon([w2t(-880, -505), w2t(-760, -480), w2t(-640, -430), w2t(-585, -368),
               w2t(-600, -310), w2t(-680, -283), w2t(-780, -290), w2t(-850, -335)],
              fill=(44, 100, 120))
    d.polygon([w2t(-830, -480), w2t(-745, -458), w2t(-660, -418), w2t(-625, -370),
               w2t(-640, -330), w2t(-700, -312), w2t(-770, -318)],
              fill=(36, 86, 108))

    # ---- 马影河 river hugging the south boundary of campus ----
    normals = boundary_normals(boundary)
    south = [(x, z, nx, nz) for (x, z), (nx, nz) in zip(boundary, normals)
             if nz > 0.05 and z > 120]
    south.sort(key=lambda t: t[0])
    print("river arc points:", len(south),
          "x:", round(south[0][0], 1) if south else None,
          "->", round(south[-1][0], 1) if south else None)
    inner, outer = [], []
    m = len(south)
    for i, (x, z, nx, nz) in enumerate(south):
        # river width swells gently mid-stream (马影河约 55-85m 宽)
        wdt = 58 + 24 * math.sin(math.pi * i / max(1, m - 1))
        inner.append((x + nx * 34, z + nz * 34))
        outer.append((x + nx * (34 + wdt), z + nz * (34 + wdt)))
    # extend to the scene edges
    if inner:
        (x0, z0), (x1, z1) = inner[0], inner[-1]
        (ox0, oz0), (ox1, oz1) = outer[0], outer[-1]
        inner = [(-1100, z0 - 15)] + inner + [(1100, z1 + 25)]
        outer = [(-1100, oz0 + 80)] + outer + [(1100, oz1 + 120)]
    sand = inner + [(x, z + 26) for x, z in outer[::-1]]
    d.polygon([w2t(x, z) for x, z in sand], fill=(174, 162, 120))
    water = ([(x + (ox - x) * 0.10, z + (oz - z) * 0.10) for (x, z), (ox, oz) in zip(inner, outer)] +
             [(ox - (ox - ix) * 0.10, oz - (oz - iz) * 0.10)
              for (ix, iz), (ox, oz) in zip(inner[::-1], outer[::-1])])
    d.polygon([w2t(x, z) for x, z in water], fill=(42, 100, 120))
    core = ([(x + (ox - x) * 0.34, z + (oz - z) * 0.34) for (x, z), (ox, oz) in zip(inner, outer)] +
            [(ox - (ox - ix) * 0.30, oz - (oz - iz) * 0.30)
             for (ix, iz), (ox, oz) in zip(inner[::-1], outer[::-1])])
    d.polygon([w2t(x, z) for x, z in core], fill=(33, 82, 102))

    # ---- 坛山岛 wetland (south of river) ----
    for _ in range(80):
        cx = rng.uniform(-250, 780)
        cz = rng.uniform(520, 720)
        px, py = w2t(cx, cz)
        d.ellipse([px - rng.uniform(16, 70) * PXM, py - rng.uniform(10, 34) * PXM,
                   px + rng.uniform(16, 70) * PXM, py + rng.uniform(10, 34) * PXM],
                  fill=(rng.choice([(56, 110, 116), (70, 124, 124), (88, 136, 126)]) + (rng.randint(150, 230),)))
    for _ in range(130):
        cx = rng.uniform(-320, 820)
        cz = rng.uniform(500, 740)
        px, py = w2t(cx, cz)
        d.ellipse([px - rng.uniform(3, 13) * PXM, py - rng.uniform(2, 8) * PXM,
                   px + rng.uniform(3, 13) * PXM, py + rng.uniform(2, 8) * PXM],
                  fill=(rng.choice([(80, 116, 64), (92, 128, 72), (106, 142, 80)]) + (220,)))

    # ---- roads ----
    road_col = PAL["road"] + (255,)

    def road(pts, width_m, dashes=True):
        p = [w2t(x, z) for x, z in pts]
        wpx = max(2, int(width_m * PXM))
        d.line(p, fill=(166, 160, 140, 255), width=wpx + int(8 * PXM), joint="curve")
        d.line(p, fill=road_col, width=wpx, joint="curve")
        if dashes:
            for i in range(len(p) - 1):
                x1, y1 = p[i]; x2, y2 = p[i + 1]
                seg = math.hypot(x2 - x1, y2 - y1)
                if seg < 1:
                    continue
                n = max(1, int(seg / (13 * PXM)))
                for k in range(n):
                    t0 = k / n; t1 = min(1, t0 + 0.40 / n)
                    d.line([(x1 + (x2 - x1) * t0, y1 + (y2 - y1) * t0),
                            (x1 + (x2 - x1) * t1, y1 + (y2 - y1) * t1)],
                           fill=(228, 222, 198, 230), width=max(1, int(0.24 * PXM)))

    # ring road just outside the property line
    ring = smooth_closed(offset_closed(boundary, 27), 2)
    road(ring + [ring[0]], 13)
    # 育才路 (north arterial, roughly parallel to the north-west boundary)
    road([(-1000, -430), (-700, -405), (-420, -382), (-140, -360), (140, -342),
          (360, -332), (560, -352), (1000, -392)], 17)
    # east arterial
    road([(432, -760), (434, -520), (430, -280), (424, -60), (414, 160), (400, 380), (382, 620)], 15)
    # ---- metro line 16 viaduct ----
    via = [w2t(x, z) for x, z in [(-1000, -585), (-500, -580), (0, -577), (500, -582), (1000, -590)]]
    d.line(via, fill=(210, 208, 200, 255), width=max(2, int(7 * PXM)))
    d.line(via, fill=(158, 158, 154, 255), width=max(1, int(2.6 * PXM)))
    # station platform hint at x ~ -55
    sx, sy = w2t(-55, -577)
    d.rounded_rectangle([sx - 42 * PXM, sy - 8 * PXM, sx + 42 * PXM, sy + 8 * PXM], radius=int(2 * PXM),
                        fill=(206, 202, 196, 255))
    # distant industry / town blocks
    for _ in range(70):
        cx = rng.uniform(420, 900)
        cz = rng.uniform(-680, -120)
        px, py = w2t(cx, cz)
        ww, hh = rng.uniform(14, 46) * PXM, rng.uniform(10, 30) * PXM
        d.rectangle([px, py, px + ww, py + hh], fill=(rng.choice([(174, 172, 162), (160, 160, 152), (188, 184, 170)])) + (200,))
    return img


# ---------------- main build ----------------
def build():
    plan = Image.open(PLAN_PATH).convert("RGB")
    idx = classify(plan)

    # red property-line dots outside the running track -> neutralise
    red_mask = (idx == CAT_IDX["track"])
    bbox = np.zeros_like(red_mask)
    bbox[500:800, 130:430] = True   # track area in plan pixels
    stray = red_mask & ~bbox
    # reclassify stray red pixels as lawn
    idx[stray] = CAT_IDX["lawn"]

    idx = mode_filter(idx, 5)
    rgb = IDX_TO_RGB[idx].astype(np.uint8)
    campus_img = Image.fromarray(rgb, "RGB").filter(ImageFilter.GaussianBlur(0.8))

    boundary_px = extract_boundary(plan)
    boundary = polygon_world(boundary_px)
    print("boundary vertices:", len(boundary))

    # debug overlay on the original plan
    from PIL import ImageDraw as _ID
    bchk = plan.copy()
    bd = _ID.Draw(bchk)
    bd.polygon(boundary_px, outline=(255, 0, 255), width=4)
    ring_dbg = smooth_closed(offset_closed(boundary, 27), 2)
    bd.line([w2t(x, z) for x, z in ring_dbg], fill=(0, 200, 255), width=4)
    bchk.save(os.path.join(ANA, "boundary_check.jpg"), quality=88)
    for _ in range(900):  # keep rng deterministic for rest of scene
        pass

    rng = random.Random(20241018)
    scene = paint_surroundings(TW, TH, rng, boundary)
    scene.resize((1400, int(1400 * TH / TW)), Image.LANCZOS).save(
        os.path.join(ANA, "surroundings_preview.jpg"), quality=86)

    # debug: report river reconstruction
    norms = boundary_normals(boundary)
    south_pts = [(x, z, nx, nz) for (x, z), (nx, nz) in zip(boundary, norms) if nz > 0.12]
    print("DEBUG south boundary pts:", len(south_pts))
    if south_pts:
        print("DEBUG south z range:", round(min(p[1] for p in south_pts), 1),
              round(max(p[1] for p in south_pts), 1),
              "x range:", round(min(p[0] for p in south_pts), 1), round(max(p[0] for p in south_pts), 1))
        print("DEBUG first/last:", [(round(p[0]), round(p[1]), round(p[2], 2), round(p[3], 2)) for p in south_pts[:3]],
              [(round(p[0]), round(p[1]), round(p[2], 2), round(p[3], 2)) for p in south_pts[-3:]])

    # ---- paste campus with polygon alpha ----
    px0, py0 = w2t(-CX * S, -CZ * S)
    px1, py1 = w2t((plan.width - CX) * S, (plan.height - CZ) * S)
    box = (int(round(px0)), int(round(py0)), int(round(px1)), int(round(py1)))
    cw, ch = box[2] - box[0], box[3] - box[1]
    campus_rs = campus_img.resize((cw, ch), Image.LANCZOS)

    poly_px = [w2t(x, z) for x, z in boundary]
    alpha = Image.new("L", (cw, ch), 0)
    ad = ImageDraw.Draw(alpha)
    ad.polygon([(x - box[0], y - box[1]) for x, y in poly_px], fill=255)
    alpha = alpha.filter(ImageFilter.GaussianBlur(6))
    # erode slightly so the outside painted ring road is not covered
    alpha_np = np.asarray(alpha).astype(np.float32) / 255.0
    alpha_np = np.clip((alpha_np - 0.25) / 0.6, 0, 1)
    alpha = Image.fromarray((alpha_np * 255).astype(np.uint8), "L")
    scene.paste(campus_rs, box[:2], alpha)

    # ---- subtle grain ----
    nrng = np.random.default_rng(7)
    small = nrng.normal(0, 1, (max(1, TH // 3), max(1, TW // 3))).astype(np.float32)
    small = np.clip(small, -2.2, 2.2)
    noise = np.array(Image.fromarray(((small + 2.2) / 4.4 * 255).astype(np.uint8), "L")
                     .resize((TW, TH), Image.BILINEAR)).astype(np.float32)
    base = np.asarray(scene).astype(np.float32)
    factor = 0.94 + (noise[..., None] / 255.0) * 0.11
    scene = Image.fromarray(np.clip(base * factor, 0, 255).astype(np.uint8), "RGB")

    # ---------------- water mask ----------------
    arr = np.asarray(scene).astype(np.float32)
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    # only genuinely blue water (avoid gray asphalt & pale glass)
    wat = (b > r + 30) & (b > g + 8) & (b > 88) & (r < 105) & (g > 62) & (b < 195)
    wm = Image.fromarray((wat.astype(np.uint8) * 255), "L").filter(ImageFilter.ModeFilter(5))
    wm_np = np.asarray(wm).astype(np.float32) / 255.0
    small_wm = np.asarray(Image.fromarray((wm_np * 255).astype(np.uint8), "L")
                          .resize((TW // 8, TH // 8), Image.BOX)).astype(np.float32) / 255.0
    small_wm = np.asarray(Image.fromarray(((small_wm > 0.30) * 255).astype(np.uint8), "L")
                          .resize((TW, TH), Image.NEAREST)).astype(np.float32) / 255.0
    wm_np = np.minimum(wm_np, small_wm)
    wm_np = np.asarray(Image.fromarray((wm_np * 255).astype(np.uint8), "L")
                       .filter(ImageFilter.GaussianBlur(5))).astype(np.float32) / 255.0
    water_mask = np.clip(wm_np * 1.55, 0, 1)

    # ---------------- tree points ----------------
    canopy = (idx == CAT_IDX["canopy"]) | (idx == CAT_IDX["canopy_light"])
    canopy = np.asarray(Image.fromarray(canopy.astype(np.uint8) * 255, "L")
                        .filter(ImageFilter.ModeFilter(3))) > 128
    trees = []
    step = 6
    h_, w_ = canopy.shape
    for gy in range(0, h_, step):
        for gx in range(0, w_, step):
            block = canopy[gy:gy + step, gx:gx + step]
            if block.size == 0 or block.mean() < 0.55:
                continue
            px = gx + step / 2 + rng.uniform(-2.2, 2.2)
            py = gy + step / 2 + rng.uniform(-2.2, 2.2)
            x, z = plan_to_world(px, py)
            is_meta = (x > 100 and z > 80) or (z > 140 and rng.random() < 0.35)
            if rng.random() < 0.28:
                is_meta = True
            trees.append({"x": round(x, 1), "z": round(z, 1),
                          "t": 1 if is_meta else 0,
                          "s": round(rng.uniform(0.78, 1.3), 2),
                          "r": round(rng.uniform(0, math.tau), 2)})
            if len(trees) > 2600:
                break
        if len(trees) > 2600:
            break

    # ---- surrounding trees: ring road, river banks, lake, wetland, arterials ----
    extra = []
    ring = smooth_closed(offset_closed(boundary, 27), 2)
    for i, (x, z) in enumerate(ring):
        if rng.random() < 0.55:
            extra.append({"x": round(x + rng.uniform(-7, 7), 1), "z": round(z + rng.uniform(-7, 7), 1),
                          "t": 1 if rng.random() < 0.3 else 0, "s": round(rng.uniform(0.85, 1.35), 2),
                          "r": round(rng.uniform(0, math.tau), 2)})
    cenx = sum(p[0] for p in boundary) / len(boundary)
    cenz = sum(p[1] for p in boundary) / len(boundary)
    for x, z in boundary:
        dx, dz = x - cenx, z - cenz
        ln = math.hypot(dx, dz) or 1
        nx, nz = dx / ln, dz / ln
        if nz > 0.10:  # south bank of campus -> riverside promenade trees
            for k in range(2):
                off = 34 + k * 12 + rng.uniform(-3, 3)
                extra.append({"x": round(x + nx * off, 1), "z": round(z + nz * off, 1),
                              "t": 2 if rng.random() < 0.5 else 0, "s": round(rng.uniform(0.8, 1.3), 2),
                              "r": round(rng.uniform(0, math.tau), 2)})
    for _ in range(900):
        x = rng.uniform(-SCENE_W / 2 + 20, SCENE_W / 2 - 20)
        z = rng.uniform(-SCENE_D / 2 + 20, SCENE_D / 2 - 20)
        if -420 < x < 420 and -350 < z < 360:
            continue
        u, v = w2t(x, z)
        if 0 <= u < TW and 0 <= v < TH and water_mask[int(v), int(u)] > 0.3:
            continue
        if rng.random() < 0.55:
            extra.append({"x": round(x, 1), "z": round(z, 1),
                          "t": rng.choice([0, 1, 2]), "s": round(rng.uniform(0.9, 1.55), 2),
                          "r": round(rng.uniform(0, math.tau), 2)})
    all_trees = trees + extra
    print("trees:", len(trees), "+", len(extra), "=", len(all_trees))

    # ---------------- write outputs ----------------
    scene_path = os.path.join(SCENE, "ground.jpg")
    scene.save(scene_path, quality=88, optimize=True, progressive=True)
    water_im = Image.fromarray((water_mask * 255).astype(np.uint8), "L")
    water_im.save(os.path.join(SCENE, "water-mask.png"))
    print("ground:", os.path.getsize(scene_path), "boundary:", len(boundary), "trees:", len(all_trees))

    # previews
    scene.resize((1400, int(1400 * TH / TW)), Image.LANCZOS).save(os.path.join(ANA, "ground_preview.jpg"), quality=88)
    scene.crop(box).resize((1200, int(1200 * (box[3] - box[1]) / (box[2] - box[0]))), Image.LANCZOS)\
        .save(os.path.join(ANA, "ground_campus_preview.jpg"), quality=90)
    tp = scene.copy()
    td = ImageDraw.Draw(tp)
    for t in all_trees:
        u, v = w2t(t["x"], t["z"])
        rr = 3 if t["t"] == 1 else 4
        td.ellipse([u - rr, v - rr, u + rr, v + rr],
                   fill=(20, 60, 40) if t["t"] == 1 else (30, 90, 40))
    tp.resize((1400, int(1400 * TH / TW)), Image.LANCZOS).save(os.path.join(ANA, "trees_preview.jpg"), quality=85)

    with open(scene_path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode()
    with open(os.path.join(ROOT, "js", "ground-tex.js"), "w", encoding="utf-8") as f:
        f.write("// auto-generated by scripts/build_scene.py - 3072x2688 ground texture\n")
        f.write("window.GROUND_TEXTURE_URI = 'data:image/jpeg;base64," + b64 + "';\n")

    wm_tex = water_im.resize((1024, 896), Image.LANCZOS)
    buf = io.BytesIO()
    wm_tex.save(buf, format="PNG", optimize=True)
    wm_b64 = base64.b64encode(buf.getvalue()).decode()
    with open(os.path.join(ROOT, "js", "ground-data.js"), "w", encoding="utf-8") as f:
        f.write("// auto-generated by scripts/build_scene.py\n")
        f.write("window.GROUND_DATA = {\n")
        f.write("  S: %s, CX: %s, CZ: %s, SCENE_W: %s, SCENE_D: %s,\n" % (S, CX, CZ, SCENE_W, SCENE_D))
        f.write("  waterMaskURI: 'data:image/png;base64," + wm_b64 + "',\n")
        f.write("  boundary: " + json.dumps([[round(x, 1), round(z, 1)] for x, z in boundary], separators=(",", ":")) + ",\n")
        f.write("  trees: " + json.dumps([[t["x"], t["z"], t["t"], t["s"], t["r"]] for t in all_trees], separators=(",", ":")) + "\n")
        f.write("};\n")
    print("js files written")


def polygon_world(poly_px):
    return [plan_to_world(x, y) for x, y in poly_px]


def extract_boundary(plan_img):
    """Robust version: isolate the red property-line loop (largest red component
    after closing the dashes), then sample it radially from the plan centroid."""
    a = np.asarray(plan_img).astype(np.int16)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    red = (r > 110) & (r - g > 30) & (r - b > 30) & (g < 165)
    m = Image.fromarray((red.astype(np.uint8) * 255), "L")
    m = m.filter(ImageFilter.MaxFilter(7))
    mask = np.array(m) > 128
    H, W = mask.shape
    ys, xs = np.nonzero(mask)
    print("boundary red px:", len(ys))
    ring = set(zip(ys.tolist(), xs.tolist()))
    cx, cy = CX, CZ
    N = 480
    pts = []
    for i in range(N):
        th = i / N * math.tau
        dx, dy = math.cos(th), math.sin(th)
        hit = None
        for step in range(780, 60, -1):
            x = int(round(cx + dx * step))
            y = int(round(cy + dy * step))
            hit2 = False
            for oy in (0, -1, 1, -2, 2):
                for ox in (0, -1, 1, -2, 2):
                    xx, yy = x + ox, y + oy
                    if 0 <= xx < W and 0 <= yy < H and (yy, xx) in ring:
                        hit2 = True
                        break
                if hit2:
                    break
            if hit2:
                hit = (cx + dx * step, cy + dy * step)
                break
        pts.append(hit)
    known = [p for p in pts if p is not None]
    print("boundary rays hit:", len(known), "/", N)
    med = float(np.median([math.hypot(p[0] - cx, p[1] - cy) for p in known])) if known else 400.0
    # fill missing rays by circular interpolation (no inward snapping)
    for i, p in enumerate(pts):
        if p is None:
            prev = next(n for n in range(1, N) if pts[(i - n) % N] is not None)
            nxt = next(n for n in range(1, N) if pts[(i + n) % N] is not None)
            p0, p1 = pts[(i - prev) % N], pts[(i + nxt) % N]
            pts[i] = ((p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2)
    for i, p in enumerate(pts):
        rad = math.hypot(p[0] - cx, p[1] - cy)
        if rad > med * 1.30 or rad < med * 0.55:
            # smooth out outliers by averaging neighbours
            xs_ = [pts[(i + k) % N][0] for k in range(-2, 3)]
            ys_ = [pts[(i + k) % N][1] for k in range(-2, 3)]
            pts[i] = (sum(xs_) / 5, sum(ys_) / 5)
    for _ in range(4):
        sm = []
        for i in range(N):
            xs_ = [pts[(i + k) % N][0] for k in range(-3, 4)]
            ys_ = [pts[(i + k) % N][1] for k in range(-3, 4)]
            sm.append((sum(xs_) / 7, sum(ys_) / 7))
        pts = sm

    def rdp(points, eps):
        def rec(seq):
            if len(seq) < 3:
                return seq
            a0, a1 = np.array(seq[0]), np.array(seq[-1])
            dd = a1 - a0
            ln = np.linalg.norm(dd)
            if ln < 1e-6:
                return [seq[0], seq[-1]]
            dists = [abs(float(np.cross(dd, np.array(p) - a0))) / ln for p in seq[1:-1]]
            if not dists:
                return [seq[0], seq[-1]]
            imax = int(np.argmax(dists))
            if dists[imax] > eps:
                left = rec(seq[:imax + 2])
                right = rec(seq[imax + 1:])
                return left[:-1] + right
            return [seq[0], seq[-1]]
        half = len(points) // 2
        return rec(points[:half + 1])[:-1] + rec(points[half:] + [points[0]])[:-1]

    poly = rdp(pts[::3], 3.0)
    out = []
    for p in poly:
        if not out or math.hypot(p[0] - out[-1][0], p[1] - out[-1][1]) > 3:
            out.append(p)
    print("boundary simplified vertices:", len(out))
    return [(float(x), float(y)) for x, y in out]


if __name__ == "__main__":
    build()
